/**
 * \class hyperbolic_vertex
 *
 * \brief Provide an example
 *
 * This class is meant as an example.  It is not useful by itself
 * rather its usefulness is only a function of how much it helps
 * the reader.  It is in a sense defined by the person who reads it
 * and otherwise does not exist in any real form. 
 *
 * \note Attempts at zen rarely work.
 *
 * \author $Author: Antoine Allard $
 *
 * \date $Date: 2014/10/08$
 *
 * Contact: antoineallard.github.io
 *
 * Created on: Wed Oct 08 2014
 *
 */


#ifndef HYPERBOLIC_VERTEX_HPP_INCLUDED
#define HYPERBOLIC_VERTEX_HPP_INCLUDED

// standard library
#include <cmath>   // for pow
#include <list>    // for multiset
#include <utility> // for pairs, make_pair


class hyperbolic_vertex
{
  public:
    // typedef
    typedef unsigned int int_t;
    typedef double dbl_t;
    typedef std::list< std::pair<int_t,dbl_t> >::iterator iterator;
  private:
    // Number of dimensions of the metric space.
    int metric_space_dimension = 0;
    // position
    std::vector<double> metric_space_position;
    // radial position
    dbl_t rho = 0;
    // angular position
    dbl_t theta = 0;
    // hidden variable(s)
    std::vector<dbl_t> kappa;
    /// degree of the vertex
    int_t degree = 0;
    // strength of a vertex
    dbl_t strength = 0;
    // disparity of the vertex
    dbl_t disparity = 0;
    // binary average degree of neighbours
    dbl_t binary_average_degree_of_neighbours = 0;
    // weighted average degree of neighbours
    dbl_t weighted_average_degree_of_neighbours = 0;
    // non structural weighted average degree of neighbours
    dbl_t nonstructural_weighted_average_degree_of_neighbours = 0;
    // binary clustering coefficient
    dbl_t binary_clustering_coefficient = 0;
    // weighted clustering coefficient (Serrano et al., Barrat et al., Onnela et al., Zhang et al.)
    std::vector<dbl_t> weighted_clustering_coefficients = {};
    // non structural weighted clustering coefficient
    dbl_t nonstructural_weighted_clustering_coefficient = 0;
    // its neighbours and the type of the stub allowing the connection
    std::list< std::pair<int_t,dbl_t> > neighbours;
  public:
    // constructor
    hyperbolic_vertex() {  }
    // destructor
    ~hyperbolic_vertex() {}
    // accessors
    dbl_t get_radial_pos()                                          { return rho;                                                 } ///< Returns the radial position of the vertex.
    dbl_t get_angular_pos()                                         { return theta;                                               } ///< Returns the angular position of the vertex.
    int_t get_degree()                                              { return degree;                                              } ///< Returns the degree of the vertex.
    dbl_t get_strength()                                            { return strength;                                            } ///< Returns the strength of the vertex.
    double get_metric_space_position(unsigned int _idx)             { return metric_space_position[_idx];                         } ///< Returns the _idx-th coordinate of position of the vertex.
    std::vector<double> get_metric_space_position()                 { return metric_space_position;                               } ///< Returns the coordinates of position of the vertex.
    int_t get_nb_nongeo_hidden_var()                                { return kappa.size();                                        } ///< Returns the number of non-geometrical hidden variables.
    dbl_t get_nongeo_hidden_var(int_t _idx)                         { return kappa[_idx];                                         } ///< Returns the _idx-th non-geometrical hidden variable.
    double get_hidden_variables(int_t _idx)                         { return kappa[_idx];                                         } ///< Returns the _idx-th non-geometrical hidden variable.
    std::vector<double> get_hidden_variables()                      { return kappa;                                               } ///< Returns the hidden variables of the vertex.
    dbl_t get_disparity()                                           { return disparity;                                           } ///< Returns the disparity of the vertex.
    dbl_t get_binary_average_degree_of_neighbours()                 { return binary_average_degree_of_neighbours;                 } ///< Returns the binary average degree of the neighbours of the vertex.
    dbl_t get_weighted_average_degree_of_neighbours()               { return weighted_average_degree_of_neighbours;               } ///< Returns the weighted average degree of the neighbours of the vertex.
    dbl_t get_nonstructural_weighted_average_degree_of_neighbours() { return nonstructural_weighted_average_degree_of_neighbours; } ///< Returns the non structural weighted average degree of the neighbours of the vertex.
    dbl_t get_binary_clustering_coefficient()                       { return binary_clustering_coefficient;                       } ///< Returns the binary clustering coefficient of the vertex.
    std::vector<double> get_weighted_clustering_coefficients()                    { return weighted_clustering_coefficients;                     } ///< Returns the weighted clustering coefficient of the vertex.
    dbl_t get_nonstructural_weighted_clustering_coefficient()       { return nonstructural_weighted_clustering_coefficient;       } ///< Returns the non structural weighted clustering coefficient of the vertex.
    // modifiers
    void set_radial_pos(dbl_t _rho)                                            { rho = _rho;                                                   } ///< Sets the radial position of the vertex.
    void set_angular_pos(dbl_t _theta)                                         { theta = _theta;                                               } ///< Sets the angular position of the vertex.
    // void set_metric_space_dimension(unsigned int _dim)                         { metric_space_dimension = _dim;                                } ///< Sets the number of dimensions of the metric space.
    // void set_metric_space_position(unsigned int _idx, double _value)           { metric_space_position[_idx] = _value;                         } ///< Sets the _idx-th coordinate of position of the vertex.
    void set_metric_space_position(std::vector<double> _position)              { metric_space_position = _position;                            } ///< Sets the position of the vertex in the metric space.
    void set_nb_nongeo_hidden_var(int_t _nb_dim)                               { kappa.resize(_nb_dim);                                        } ///< Sets the number of non-geometrical hidden variables.
    void set_nongeo_hidden_var(int_t _idx, dbl_t _value)                       { kappa[_idx] = _value;                                         } ///< Sets the _idx-th non-geometrical hidden variable.
    void set_hidden_variables(std::vector<double> _hidden_variables)           { kappa = _hidden_variables;                                    } ///< Sets the hidden variables.
    void set_disparity();                                                                                                                        ///< Sets the disparity of the vertex (computed internally).
    void set_binary_average_degree_of_neighbours(dbl_t _value)                 { binary_average_degree_of_neighbours = _value;                 } ///< Sets the binary average degree of the neighbours of the vertex.
    void set_weighted_average_degree_of_neighbours(dbl_t _value)               { weighted_average_degree_of_neighbours = _value;               } ///< Sets the weighted average degree of the neighbours of the vertex.
    void set_nonstructural_weighted_average_degree_of_neighbours(dbl_t _value) { nonstructural_weighted_average_degree_of_neighbours = _value; } ///< Sets the non structural weighted average degree of the neighbours of the vertex.
    void set_binary_clustering_coefficient(dbl_t _value)                       { binary_clustering_coefficient = _value;                       } ///< Sets the binary clustering coefficient of the vertex.
    void set_weighted_clustering_coefficients(std::vector<dbl_t> _values)      { weighted_clustering_coefficients = _values;                   } ///< Sets the weighted clustering coefficient of the vertex.
    void set_nonstructural_weighted_clustering_coefficient(dbl_t _value)       { nonstructural_weighted_clustering_coefficient = _value;       } ///< Sets the non structural weighted clustering coefficient of the vertex.
    // actions on neighbours
    void neighbour_insert(int_t _id, dbl_t _weight); ///< Adds a vertex to the neighbourhood of the vertex.
    void neighbour_erase(iterator _it);
    void neighbour_clear();
    iterator neighbour_begin()                           { return neighbours.begin(); }
    iterator neighbour_end()                             { return neighbours.end(); }
};

void hyperbolic_vertex::set_disparity()
{
  // sets the iterators to browse the neighbours
  iterator it  = neighbours.begin();
  iterator end = neighbours.end();
  // computes the disparity
  disparity = 0;
  for(; it !=end; ++it)
    disparity += std::pow(it->second,2);
  if( strength > 0 )
    disparity /= std::pow(strength,2);
}

void hyperbolic_vertex::neighbour_insert(int_t _id, dbl_t _weight)
{
  degree += 1;
  strength += _weight;
  neighbours.push_back(std::make_pair(_id,_weight));
}

void hyperbolic_vertex::neighbour_erase(iterator _it)
{
  degree -= 1;
  strength -= _it->second;
  neighbours.erase(_it);
}

void hyperbolic_vertex::neighbour_clear()
{
  degree = 0;
  strength = 0;
  neighbours.clear();
}


#endif // HYPERBOLIC_VERTEX_HPP_INCLUDED