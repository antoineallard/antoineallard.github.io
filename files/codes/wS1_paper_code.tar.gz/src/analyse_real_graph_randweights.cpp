// ================================================================================================
//
// author:  Antoine Allard
// email:   antoine.allard.1@gmail.com 
// www:     antoineallard.info
//
// last updated: Jul. 30th, 2015
//
// To compile: g++ -O3 -std=c++11 analyse_real_graph.cpp -o analyse_real_graph -lgsl -lgslcblas
//
// ================================================================================================


#include <ctime>
#include "hyperbolic_graph.hpp"

int main(int argc, char* argv[])
{

  // ==============================================================================================
  // Parameters of the model.

  // *** Root of the name of the input/output files.
  std::string rootname = argv[1];
  std::string ext      = argv[2];
  std::string name     = "networks/" + rootname + "/original_graph/" + rootname + "_" + ext;
  std::string edgelist = name + ".edge";

  // ==============================================================================================
  // Calculations.

  // *** Creates a graph from a given edgelist.
  hyperbolic_graph graph;
  graph.import_graph(edgelist,"undirected","weighted");

  // *** Computes graph's properties.
  graph.analyse_graph("complete");

  // *** Exports the graph into a file.
  graph.export_graph_properties(name);
  graph.export_vertices_properties(name);
  graph.export_triangles(name);
  graph.export_edge_list(name);
  // graph.export_extended_edge_list(name);

  // Writes the degree sequence into a file.
  std::ofstream output_file(name + "_degree_sequence.dat");
  for(unsigned int n(0); n<graph.get_nb_vertices(); ++n)
    if(graph(n)->get_degree() > 0)
      output_file << graph(n)->get_degree() << std::endl;
  output_file.close();

  // Writes the strength sequence into a file.
  output_file.open(name + "_strength_sequence.dat");
  for(unsigned int n(0); n<graph.get_nb_vertices(); ++n)
    if(graph(n)->get_degree() > 0)
      output_file << graph(n)->get_strength() << std::endl;
  output_file.close();

  // ==============================================================================================
  // Exits the program successfully.
  return 0;

}
