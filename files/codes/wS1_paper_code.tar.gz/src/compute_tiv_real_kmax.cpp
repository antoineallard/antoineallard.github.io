// ================================================================================================
//
// author:  Antoine Allard
// email:   antoine.allard.1@gmail.com 
// www:     antoineallard.info
//
// last updated: Mar. 3rd, 2015
//
// To compile: g++ -O3 -std=c++11 fit_topology.cpp -o fit_topology -lgsl -lgslcblas
//
// ================================================================================================


#include <ctime>
#include "../../src/hyperbolic_graph.hpp"

int main(int argc, char* argv[])
{


  // // ==============================================================================================
  // // Parameters for WAN2005BB
  // // *** Root of the name of the output file.
  // std::string name = "networks/WAN2005BB/net01_WAN2005BB";
  // // *** Number of nodes.
  // unsigned int nb_vertices = 3368;
  // // *** The type of metric space used.
  // std::string geometry = "S1";
  // // *** Coupling between the weights and the metric distance.
  // double alpha = 0.25;
  // // double alpha = 0.0;
  // // *** Density of the vertices in the metric space.
  // double delta = 1.0;
  // // *** The pdf used for the hidden variable kappa, and its parameters.
  // std::string pdf_kappa_type = "pdf_powerlaw_hardcutoff";                    // power-law between a lower and an upper bound
  // double gamma     = 2.05;                                                   // exponent
  // double kappa_min = 0.797060651271;                                         // lower bound
  // double kappa_max = 150;                                                    // upper bound
  // std::vector<double> pdf_kappa_param = {gamma, kappa_min, kappa_max};
  // // *** The pdf used for the hidden variable sigma, and its parameters.
  // std::string pdf_sigma_type = "deterministic_scaling";         // scaling of the form: sigma = kappa^eta
  // double eta               = 1.3;
  // double prop_constant     = 83199.62;
  // std::vector<double> pdf_sigma_param = {eta, prop_constant};
  // // *** The function used for the connection probability, and its parameters.
  // std::string prob_connection_type = "prob_FermiDirac";
  // double beta = 1.8;
  // std::vector<double> prob_connection_param = {beta};
  // // *** The pdf used for the weights, and its parameters.
  // std::string pdf_weights_type = "pdf_gamma";
  // double weights_gamma_scale = 1.0;
  // std::vector<double> pdf_weights_param = {1./weights_gamma_scale, weights_gamma_scale};


  // // ==============================================================================================
  // // Parameters for WAN2005
  // // *** Root of the name of the output file.
  // std::string name = "networks/WAN2005/net01_WAN2005";
  // // *** Number of nodes.
  // unsigned int nb_vertices = 4000;
  // // *** The type of metric space used.
  // std::string geometry = "S1";
  // // *** Coupling between the weights and the metric distance.
  // double alpha = 0.60;
  // // double alpha = 0.0;
  // // *** Density of the vertices in the metric space.
  // double delta = 1.0;
  // // *** The pdf used for the hidden variable kappa, and its parameters.
  // std::string pdf_kappa_type = "pdf_powerlaw_hardcutoff";                    // power-law between a lower and an upper bound
  // double gamma     = 1.9;                                                   // exponent
  // double kappa_min = 1.2;                                         // lower bound
  // double kappa_max = 400;                                                    // upper bound
  // std::vector<double> pdf_kappa_param = {gamma, kappa_min, kappa_max};
  // // *** The pdf used for the hidden variable sigma, and its parameters.
  // std::string pdf_sigma_type = "deterministic_scaling";         // scaling of the form: sigma = kappa^eta
  // double eta               = 1.43;
  // double prop_constant     = 15313.0;
  // std::vector<double> pdf_sigma_param = {eta, prop_constant};
  // // *** The function used for the connection probability, and its parameters.
  // std::string prob_connection_type = "prob_FermiDirac";
  // double beta = 2.5;
  // std::vector<double> prob_connection_param = {beta};
  // // *** The pdf used for the weights, and its parameters.
  // std::string pdf_weights_type = "pdf_gamma";
  // double weights_gamma_scale = 1.0;
  // std::vector<double> pdf_weights_param = {1./weights_gamma_scale, weights_gamma_scale};




  // // ==============================================================================================
  // // Parameters for JDKDep
  // // *** Root of the name of the output file.
  // std::string name = "networks/JDKDep/net01_JDKDep";
  // // *** Number of nodes.
  // unsigned int nb_vertices = 6500;
  // // *** The type of metric space used.
  // std::string geometry = "S1";
  // // *** Coupling between the weights and the metric distance.
  // double alpha = 0.60;
  // // double alpha = 0.0;
  // // *** Density of the vertices in the metric space.
  // double delta = 1.0;
  // // *** The pdf used for the hidden variable kappa, and its parameters.
  // std::string pdf_kappa_type = "pdf_powerlaw_hardcutoff";                    // power-law between a lower and an upper bound
  // double gamma     = 2.26;                                                   // exponent
  // double kappa_min = 5.03475298547;                                         // lower bound
  // double kappa_max = 6000;                                                    // upper bound
  // std::vector<double> pdf_kappa_param = {gamma, kappa_min, kappa_max};
  // // *** The pdf used for the hidden variable sigma, and its parameters.
  // std::string pdf_sigma_type = "deterministic_scaling";         // scaling of the form: sigma = kappa^eta
  // double eta               = 1.00;
  // double prop_constant     = 2.37;
  // std::vector<double> pdf_sigma_param = {eta, prop_constant};
  // // *** The function used for the connection probability, and its parameters.
  // std::string prob_connection_type = "prob_FermiDirac";
  // double beta = 2.5;
  // std::vector<double> prob_connection_param = {beta};
  // // *** The pdf used for the weights, and its parameters.
  // std::string pdf_weights_type = "pdf_gamma";
  // double weights_gamma_scale = 1.0;
  // std::vector<double> pdf_weights_param = {1./weights_gamma_scale, weights_gamma_scale};


  // // ==============================================================================================
  // // Parameters for USAirports_flight
  // // *** Root of the name of the output file.
  // std::string name = "networks/USAirports_flights/net01_USAirports_flights";
  // // *** Number of nodes.
  // unsigned int nb_vertices = 1750;
  // // *** The type of metric space used.
  // std::string geometry = "S1";
  // // *** Coupling between the weights and the metric distance.
  // double alpha = 0.60;
  // // double alpha = 0.0;
  // // *** Density of the vertices in the metric space.
  // double delta = 1.0;
  // // *** The pdf used for the hidden variable kappa, and its parameters.
  // std::string pdf_kappa_type = "pdf_powerlaw_hardcutoff";                    // power-law between a lower and an upper bound
  // double gamma     = 1.5;                                                   // exponent
  // double kappa_min = 1.00;                                         // lower bound
  // double kappa_max = 1500;                                                    // upper bound
  // std::vector<double> pdf_kappa_param = {gamma, kappa_min, kappa_max};
  // // *** The pdf used for the hidden variable sigma, and its parameters.
  // std::string pdf_sigma_type = "deterministic_scaling";         // scaling of the form: sigma = kappa^eta
  // double eta               = 1.51;
  // double prop_constant     = 3474.0;
  // std::vector<double> pdf_sigma_param = {eta, prop_constant};
  // // *** The function used for the connection probability, and its parameters.
  // std::string prob_connection_type = "prob_FermiDirac";
  // double beta = 1.4;
  // std::vector<double> prob_connection_param = {beta};
  // // *** The pdf used for the weights, and its parameters.
  // std::string pdf_weights_type = "pdf_gamma";
  // double weights_gamma_scale = 1.0;
  // std::vector<double> pdf_weights_param = {1./weights_gamma_scale, weights_gamma_scale};


  // // ==============================================================================================
  // // Parameters for KingJames
  // // *** Root of the name of the output file.
  // std::string name = "networks/KingJames/net01_KingJames";
  // // *** Number of nodes.
  // unsigned int nb_vertices = 2000;
  // // *** The type of metric space used.
  // std::string geometry = "S1";
  // // *** Coupling between the weights and the metric distance.
  // double alpha = 0.25;
  // // double alpha = 0.0;
  // // *** Density of the vertices in the metric space.
  // double delta = 1.0;
  // // *** The pdf used for the hidden variable kappa, and its parameters.
  // std::string pdf_kappa_type = "pdf_powerlaw_hardcutoff";                    // power-law between a lower and an upper bound
  // double gamma     = 2.42;                                                   // exponent
  // double kappa_min = 2.50;                                         // lower bound
  // double kappa_max = 800;                                                    // upper bound
  // std::vector<double> pdf_kappa_param = {gamma, kappa_min, kappa_max};
  // // *** The pdf used for the hidden variable sigma, and its parameters.
  // std::string pdf_sigma_type = "deterministic_scaling";         // scaling of the form: sigma = kappa^eta
  // double eta               = 1.62;
  // double prop_constant     = 3738.0;
  // std::vector<double> pdf_sigma_param = {eta, prop_constant};
  // // *** The function used for the connection probability, and its parameters.
  // std::string prob_connection_type = "prob_FermiDirac";
  // double beta = 2.5;
  // std::vector<double> prob_connection_param = {beta};
  // // *** The pdf used for the weights, and its parameters.
  // std::string pdf_weights_type = "pdf_gamma";
  // double weights_gamma_scale = 1.0;
  // std::vector<double> pdf_weights_param = {1./weights_gamma_scale, weights_gamma_scale};

  // // ==============================================================================================
  // // Parameters for Enron
  // // *** Root of the name of the output file.
  // std::string name = "networks/Enron/net01_Enron";
  // // *** Number of nodes.
  // unsigned int nb_vertices = 80000;
  // // *** The type of metric space used.
  // std::string geometry = "S1";
  // // *** Coupling between the weights and the metric distance.
  // double alpha = 0.25;
  // // double alpha = 0.0;
  // // *** Density of the vertices in the metric space.
  // double delta = 1.0;
  // // *** The pdf used for the hidden variable kappa, and its parameters.
  // std::string pdf_kappa_type = "pdf_exponential";                           // exponential
  // double kappa_scale = 15;                                                 // scale parameter
  // std::vector<double> pdf_kappa_param = {kappa_scale};
  // // *** The pdf used for the hidden variable sigma, and its parameters.
  // std::string pdf_sigma_type = "deterministic_scaling";         // scaling of the form: sigma = kappa^eta
  // double eta               = 1.14;
  // double prop_constant     = 2.0;
  // std::vector<double> pdf_sigma_param = {eta, prop_constant};
  // // *** The function used for the connection probability, and its parameters.
  // std::string prob_connection_type = "prob_FermiDirac";
  // double beta = 2.5;
  // std::vector<double> prob_connection_param = {beta};
  // // *** The pdf used for the weights, and its parameters.
  // std::string pdf_weights_type = "pdf_gamma";
  // double weights_gamma_scale = 1.0;
  // std::vector<double> pdf_weights_param = {1./weights_gamma_scale, weights_gamma_scale};


  // // ==============================================================================================
  // // Parameters for UCIrvine
  // // *** Root of the name of the output file.
  // std::string name = "networks/UCIrvine/net01_UCIrvine";
  // // *** Number of nodes.
  // unsigned int nb_vertices = 2000;
  // // *** The type of metric space used.
  // std::string geometry = "S1";
  // // *** Coupling between the weights and the metric distance.
  // double alpha = 0.25;
  // // double alpha = 0.0;
  // // *** Density of the vertices in the metric space.
  // double delta = 1.0;
  // // *** The pdf used for the hidden variable kappa, and its parameters.
  // std::string pdf_kappa_type = "pdf_powerlaw_expocutoff";                    // power-law between a lower and an upper bound
  // double gamma     = 2.10;                                                   // exponent
  // double kappa_min = 4.91277632342;                                         // lower bound
  // double cutoff    = 350;
  // std::vector<double> pdf_kappa_param = {gamma, kappa_min, cutoff};
  // // *** The pdf used for the hidden variable sigma, and its parameters.
  // std::string pdf_sigma_type = "deterministic_scaling";         // scaling of the form: sigma = kappa^eta
  // double eta               = 1.19;
  // double prop_constant     = 1.0;
  // std::vector<double> pdf_sigma_param = {eta, prop_constant};
  // // *** The function used for the connection probability, and its parameters.
  // std::string prob_connection_type = "prob_FermiDirac";
  // double beta = 1.2;
  // std::vector<double> prob_connection_param = {beta};
  // // *** The pdf used for the weights, and its parameters.
  // std::string pdf_weights_type = "pdf_gamma";
  // double weights_gamma_scale = 1.0;
  // std::vector<double> pdf_weights_param = {1./weights_gamma_scale, weights_gamma_scale};


  // ==============================================================================================
  // Parameters for wtw2013BB
  // *** Root of the name of the output file.
  std::string name = "networks/wtw2013BB/net01_wtw2013BB";
  // *** Number of nodes.
  unsigned int nb_vertices = 200;
  // *** The type of metric space used.
  std::string geometry = "S1";
  // *** Coupling between the weights and the metric distance.
  double alpha = 0.25;
  // double alpha = 0.0;
  // *** Density of the vertices in the metric space.
  double delta = 1.0;
  // *** The pdf used for the hidden variable kappa, and its parameters.
  std::string pdf_kappa_type = "pdf_powerlaw_hardcutoff";                    // power-law between a lower and an upper bound
  double gamma     = 2.42;                                                   // exponent
  double kappa_min = 2.50;                                         // lower bound
  double kappa_max = 800;                                                    // upper bound
  std::vector<double> pdf_kappa_param = {gamma, kappa_min, kappa_max};
  // *** The pdf used for the hidden variable sigma, and its parameters.
  std::string pdf_sigma_type = "deterministic_scaling";         // scaling of the form: sigma = kappa^eta
  double eta               = 1.62;
  double prop_constant     = 3738.0;
  std::vector<double> pdf_sigma_param = {eta, prop_constant};
  // *** The function used for the connection probability, and its parameters.
  std::string prob_connection_type = "prob_FermiDirac";
  double beta = 2.5;
  std::vector<double> prob_connection_param = {beta};
  // *** The pdf used for the weights, and its parameters.
  std::string pdf_weights_type = "pdf_gamma";
  double weights_gamma_scale = 1.0;
  std::vector<double> pdf_weights_param = {1./weights_gamma_scale, weights_gamma_scale};

  // // ==============================================================================================
  // // Parameters for wanusa2013PassengersBB
  // // *** Root of the name of the output file.
  // // std::string name = "networks/wanusa2013PassengersBB/net01_wanusa2013PassengersBB";
  // // *** Number of nodes.
  // unsigned int nb_vertices = 1175;
  // // *** The type of metric space used.
  // std::string geometry = "S1";
  // // *** Coupling between the weights and the metric distance.
  // double alpha = std::atof(argv[1]);
  // // double alpha = 0.0;
  // // *** Density of the vertices in the metric space.
  // double delta = 1.0;
  // // *** The pdf used for the hidden variable kappa, and its parameters.
  // std::string pdf_kappa_type = "pdf_powerlaw_hardcutoff";                    // power-law between a lower and an upper bound
  // double gamma     = 1.6;                                                   // exponent
  // double kappa_min = 0.45;                                         // lower bound
  // double kappa_max = 400;                                                    // upper bound
  // std::vector<double> pdf_kappa_param = {gamma, kappa_min, kappa_max};
  // // *** The pdf used for the hidden variable sigma, and its parameters.
  // std::string pdf_sigma_type = "deterministic_scaling";         // scaling of the form: sigma = kappa^eta
  // double eta               = 1.72;
  // double prop_constant     = 10000.0;
  // std::vector<double> pdf_sigma_param = {eta, prop_constant};
  // // *** The function used for the connection probability, and its parameters.
  // std::string prob_connection_type = "prob_FermiDirac";
  // double beta = 1.65;
  // std::vector<double> prob_connection_param = {beta};
  // // *** The pdf used for the weights, and its parameters.
  // std::string pdf_weights_type = "pdf_gamma";
  // double weights_gamma_scale = std::atof(argv[2]);
  // std::vector<double> pdf_weights_param = {1./weights_gamma_scale, weights_gamma_scale};


  // // ==============================================================================================
  // // Parameters for hep-th
  // // *** Root of the name of the output file.
  // std::string name = "networks/hep-th/net01_hep-th";
  // // *** Number of nodes.
  // unsigned int nb_vertices = 10000;
  // // *** The type of metric space used.
  // std::string geometry = "S1";
  // // *** Coupling between the weights and the metric distance.
  // double alpha = 0.25;
  // // double alpha = 0.0;
  // // *** Density of the vertices in the metric space.
  // double delta = 1.0;
  // // *** The pdf used for the hidden variable kappa, and its parameters.
  // std::string pdf_kappa_type = "pdf_exponential";                           // exponential
  // double kappa_scale = 4.5;                                                 // scale parameter
  // std::vector<double> pdf_kappa_param = {kappa_scale};
  // // *** The pdf used for the hidden variable sigma, and its parameters.
  // std::string pdf_sigma_type = "deterministic_scaling";         // scaling of the form: sigma = kappa^eta
  // double eta               = 1.0;
  // double prop_constant     = 1.0;
  // std::vector<double> pdf_sigma_param = {eta, prop_constant};
  // // *** The function used for the connection probability, and its parameters.
  // std::string prob_connection_type = "prob_FermiDirac";
  // double beta = 4.0;
  // std::vector<double> prob_connection_param = {beta};
  // // *** The pdf used for the weights, and its parameters.
  // std::string pdf_weights_type = "pdf_gamma";
  // double weights_gamma_scale = 0.5;
  // std::vector<double> pdf_weights_param = {1./weights_gamma_scale, weights_gamma_scale};


  // ==============================================================================================
  // Simulations.

  // *** Initializes the random number generator.
  std::mt19937 engine(std::time(NULL));
  // std::mt19937 engine(std::atoi(argv[3]));

  // *** Creates a graph.
  hyperbolic_graph graph;
  graph.make_graph(nb_vertices, geometry, delta, alpha, pdf_kappa_type, pdf_kappa_param, pdf_sigma_type, pdf_sigma_param, prob_connection_type, prob_connection_param, pdf_weights_type, pdf_weights_param, engine);

  // *** Computes graph's properties.
  graph.analyse_graph("complete");

  // *** Exports the graph into a file.
  graph.export_graph_properties(name);
  graph.export_vertices_properties(name);
  graph.export_edge_list(name);
  graph.export_triangles(name);
  // graph.export_extended_edge_list(name);


  // ==============================================================================================
  // Exits the program successfully.
  return 0;

}
