/**
 * \class hyperbolic_vertex
 *
 * \brief Provide an example
 *
 * This class is meant as an example.  It is not useful by itself
 * rather its usefulness is only a function of how much it helps
 * the reader.  It is in a sense defined by the person who reads it
 * and otherwise does not exist in any real form. 
 *
 * \note Attempts at zen rarely work.
 *
 * \author $Author: Antoine Allard $
 *
 * \date $Date: 2014/10/08$
 *
 * Contact: antoineallard.github.io
 *
 * Created on: Wed Oct 08 2014
 *
 */

#ifndef HYPERBOLIC_GRAPH_HPP_INCLUDED
#define HYPERBOLIC_GRAPH_HPP_INCLUDED

// Standard Library
#include <cmath>
#include <ctime>
#include <fstream>
#include <iostream>
#include <limits>
#include <random>
#include <string>
#include <vector>
// // GSL
// #include "gsl/gsl_sf_gamma.h"
// Hidden Metric Spaces
#include "hyperbolic_vertex.hpp"


class hyperbolic_graph
{
  private:
    // typedef
    typedef unsigned int int_t;
    typedef double dbl_t;
    // Pi
    const dbl_t Pi = 3.1415926535897932384626433832795;
    // Vector that contains the hyperbolic vertices.
    std::vector< hyperbolic_vertex > the_graph;
    // probability of 
  private: // information about the graph
    // The number of vertices in the graph
    int_t nb_vertices = 0;
    int_t nb_vertices_zerodegree = 0;
    // // The radius of the hyperbolic circle ($S^1$) / disk ($H^2$)
    // dbl_t R = 0;
    // the type of graph
    std::string type_of_graph = "None";
    // // parameters of the hidden variables distributions
    // dbl_t gamma_kappa  = 0;
    // dbl_t gamma_lambda = 0;
    // dbl_t kappa_zero   = 0;
    // dbl_t kappa_coff   = 0;
    // dbl_t lambda_zero  = 0;
    // // other parameters
    // dbl_t mu = 0;
    // dbl_t nu = 0;
    // double alpha = 0;
    // dbl_t beta = 0;
    // properties of the graph
    double delta = 0;
    int    k_min = 0;
    int    k_max = 0;
    double s_min = 0;
    double s_max = 0;
    // double s_var = 0;
    double w_min = 0;
    double w_max = 0;
    double w_avg = 0;
    double kappa_min = 0;
    double kappa_max = 0;
    double sigma_min = 0;
    double sigma_max = 0;
    double sigma_avg = 0;
    std::vector<dbl_t> degree_distribution;
    std::vector<dbl_t> average_strength_per_degree;
    std::vector<dbl_t> average_squared_strength_times_one_minus_disparity_per_degree;
  public:
    int_t degree_zero_vertices = 0;
    double k_avg = 0;
    double s_avg = 0;
    double s_var = 0;
    double s_2mt = 0;
    double s_2etaminus1 = 0;
    double kappa_avg = 0;
  private:
    // *** Input parameters.
    // The type of metric space used.
    std::string geometry = "None";
    // Coupling between the metric distance and w_c
    double alpha = 0;
    // The pdf used for the hidden variable kappa, and its parameters.
    std::string pdf_kappa_type = "None";
    std::vector<double> pdf_kappa_param;
    // The pdf used for the hidden variable sigma, and its parameters.
    std::string pdf_sigma_type = "None";
    std::vector<double> pdf_sigma_param;
    // The function used for the connection probability, and its parameters.
    std::string prob_connection_type = "None";
    std::vector<double> prob_connection_param;
    // The pdf used for the weights, and its parameters.
    std::string pdf_weights_type = "None";
    std::vector<double> pdf_weights_param;
  private:
    // *** Theoretical values computed from the input parameters.
    double mu = 0;
    double nu = 0;
    double mean_kappa = 0;
    double mean_sigma = 0;
  private:
    // *** Random number generators.
    // Uniform (0,1) distribution.
    std::uniform_real_distribution<dbl_t> uniform_01;
    // Normal (0,1) distribution.
    // std::normal_distribution<double> normal_01(0.0,1.0);
    // Power-law with hard cutoff.
    double pdf_powerlaw_hardcutoff(std::vector<double> &param, std::mt19937& _engine);
    // Power-law with exponential cutoff.
    double pdf_powerlaw_expocutoff(std::vector<double> &param, std::mt19937& _engine);
    // Exponential distribution.
    double pdf_exponential(double param, std::mt19937& _engine);
    // Exponential distribution with lower bound.
    double pdf_exponential_lowerbounded(std::vector<double> param, std::mt19937& _engine);
    // Exponential distribution with lower and upper bounds.
    double pdf_exponential_bounded(std::vector<double> param, std::mt19937& _engine);
    // Gamma distribution.
    double pdf_gamma(std::vector<double> param, std::mt19937& _engine);
  private:
    // *** Metric distance calculator.
    // S1.
    double distance_S1(double R, double phi1, double phi2);
    // S2.
    double distance_S2(double R, double phi1, double lambda1, double phi2, double lambda2);
    // double metric_distance(std::string geometry, std::vector<double> x1, std::vector<double> x2);
  public:
    // Analyses the vertices properties.
    void analyse_graph(std::string option);
    // *** Exporting tools.
    // Writes the vertices' properties into a file.
    void export_vertices_properties(std::string _name, std::string type_ios_base);
    // Writes the graph's prperties into a file.
    void export_graph_properties(std::string _name);
    // Writes the edge list into a file.
    void export_edge_list(std::string _name, std::string type_ios_base);
    // Writes the extended edge list into a file (full info about each edge)
    void export_extended_edge_list(std::string _name);
    // Writes a list of the triangles.
    void export_triangles(std::string _name);
  private:
    // // Generates a continuous variable distributed according to a power law distribution.
    // dbl_t gen_cont_powerlaw_var(dbl_t _gamma, dbl_t _kappa_zero, std::mt19937& _engine);
    // // Generates a continuous variable distributed according to a power law distribution.
    // dbl_t gen_cont_powerlaw_var_with_hard_cutoff(dbl_t _gamma, dbl_t _kappa_zero, dbl_t _kappa_max, std::mt19937& _engine);
    // // Generates a continuous variable distributed according to an exponential distribution.
    // dbl_t gen_cont_expo_var(dbl_t _w_c, std::mt19937& _engine);
    // Finds the value of the highest degree.
    void find_highest_degree_value();
    // Finds the value of the highest strength.
    void find_highest_strength_value();
    // Computes the average degree.
    void compute_average_degree();
    // Computes the average strength.
    void compute_average_strength();
    // Computes the degree distribution.
    void compute_degree_distribution();
    // Computes the average strength per degree class.
    void compute_average_strength_per_degree();
    // Computes the average of $s^2(1-Y)$ per degree class.
    void compute_average_squared_strength_times_one_minus_disparity_per_degree();
  public:
    /// Constructor
    hyperbolic_graph() {}
    /// Destructor
    ~hyperbolic_graph() {}
    //
    hyperbolic_vertex* operator()(int_t _id) {return &the_graph[_id];}
    /// Returns the number of vertices
    int_t get_nb_vertices() {return nb_vertices;}
    //
    void make_graph(int _nb_vertices, std::string _geometry, double delta, double alpha, std::string _pdf_kappa_type, std::vector<double> _pdf_kappa_param, std::string _pdf_sigma_type, std::vector<double> _pdf_sigma_param, std::string _prob_connection_type, std::vector<double> _prob_connection_param, std::string _pdf_weights_type, std::vector<double> _pdf_weights_param, std::mt19937& _engine);
    void make_graph_fixed_kappa_sequence(int _nb_vertices, std::string _geometry, double _delta, double _alpha, std::string _pdf_kappa_type, std::vector<double> _pdf_kappa_param,std::vector<double> kappa_sequence, std::string _pdf_sigma_type, std::vector<double> _pdf_sigma_param, std::string _prob_connection_type, std::vector<double> _prob_connection_param, std::string _pdf_weights_type, std::vector<double> _pdf_weights_param, std::mt19937& _engine);
    void make_graph_fixed_kappa_sigma_sequences(int _nb_vertices, std::string _geometry, double _delta, double _alpha, std::string _pdf_kappa_type, std::vector<double> _pdf_kappa_param, std::vector<double> kappa_sequence, std::string _pdf_sigma_type, std::vector<double> _pdf_sigma_param, std::vector<double> sigma_sequence, std::string _prob_connection_type, std::vector<double> _prob_connection_param, std::string _pdf_weights_type, std::vector<double> _pdf_weights_param, std::mt19937& _engine);
    // //
    // void build_S1(int_t _nb_vertices, dbl_t _gamma, dbl_t _kappa_zero, dbl_t _mu, dbl_t _alpha, std::mt19937& _engine);
    // //
    // void build_S1_BE(int_t nb_vertices, dbl_t gamma, dbl_t kappa_zero, dbl_t mu, dbl_t alpha, dbl_t beta, std::mt19937& _engine);
    // //
    // void build_wS1_two_hidden_variables(int_t _nb_vertices, dbl_t _gamma_k, dbl_t _kappa_zero, dbl_t kappa_coff, dbl_t _mu, dbl_t _nu, dbl_t _alpha, dbl_t _beta, std::mt19937& _engine);
    //
    void compute_disparity();
    //
    void compute_average_degree_of_neighbours();
    //
    void compute_clustering_coefficients();
    //
    void compute_nonstructural_correlation_coefficients();
    // //
    // void export_graph(std::string _name);
    // Imports a weighted graph from an edgelist.
    void import_graph(std::string _name, std::string _directed, std::string _weigthed);
    //
    void clear();
};

void hyperbolic_graph::clear()
{
  // ***Clears everything that has been initialized by the constructor.
  the_graph.clear();
  nb_vertices = 0;
  nb_vertices_zerodegree = 0;
  type_of_graph = "None";
  degree_zero_vertices = 0;
  delta = 0;
  k_min = 0;
  k_max = 0;
  k_avg = 0;
  s_min = 0;
  s_max = 0;
  s_avg = 0;
  s_2mt = 0;
  s_2etaminus1 = 0;
  s_var = 0;
  w_min = 0;
  w_max = 0;
  w_avg = 0;
  kappa_min = 0;
  kappa_max = 0;
  kappa_avg = 0;
  sigma_min = 0;
  sigma_max = 0;
  sigma_avg = 0;
  degree_distribution.clear();
  average_strength_per_degree.clear();
  average_squared_strength_times_one_minus_disparity_per_degree.clear();
  geometry = "None";
  alpha = 0;
  pdf_kappa_type = "None";
  pdf_kappa_param.clear();
  pdf_sigma_type = "None";
  pdf_sigma_param.clear();
  prob_connection_type = "None";
  prob_connection_param.clear();
  pdf_weights_type = "None";
  pdf_weights_param.clear();
  mu = 0;
  nu = 0;
  mean_kappa = 0;
  mean_sigma = 0;
}


void hyperbolic_graph::import_graph(std::string _name, std::string _directed, std::string _weighted)
{
  // Strings and streams.
  // std::string full_line, value;
  std::ifstream input_file;
  // std::stringstream one_line;
  std::string n1_str, n2_str, w_str;
  bool directed;
  bool weighted;

  // Variables.
  int_t n_min, n_max, n1, n2;
  dbl_t w;

  // Determines the type of edgelist.
  if(_directed == "undirected")
    directed = false;
  else if(_directed == "directed")
    directed = true;
  else
    std::cout<<"Unknown type of edgelist."<<std::endl;
  if(_weighted == "unweighted")
    weighted = false;
  else if(_weighted == "weighted")
    weighted = true;
  else
    std::cout<<"Unknown type of edgelist."<<std::endl;

  // *** Finds the range of the ids of vertices.
  // Opens the stream.
  input_file.open(_name.c_str(), std::ios_base::in);
  // Reads the first line of edgelist to set the initial values of "n_min" and "n_max"
  input_file >> n1_str >> std::ws;
  n1 = std::atoi(n1_str.c_str());
  input_file >> n2_str >> std::ws;
  n2 = std::atoi(n2_str.c_str());
  if(weighted)
    input_file >> w_str  >> std::ws;
  if(n1 < n2)
  {
    n_min = n1;
    n_max = n2;
  }
  else
  {
    n_min = n2;
    n_max = n1;
  }
  // Reads the rest of the edgelist.
  while( !input_file.eof() )
  {
    // Finds the vertices' identity.
    input_file >> n1_str >> std::ws;
    n1 = std::atoi(n1_str.c_str());
    input_file >> n2_str >> std::ws;
    n2 = std::atoi(n2_str.c_str());
    // Finds the weight of the edge.
    if(weighted)
      input_file >> w_str  >> std::ws;
    // Finds the values of "n_min" and "n_max"
    if(n1 < n_min)
      n_min = n1;
    if(n1 > n_max)
      n_max = n1;
    if(n2 < n_min)
      n_min = n2;
    if(n2 > n_max)
      n_max = n2;
  }
  // Closes the stream.
  input_file.close();

  // Sets the number of vertices.
  nb_vertices = n_max - n_min + 1;
  // Resizes the graph.
  the_graph.resize(nb_vertices);
  // Sets the type of the graph.
  type_of_graph = "Real";

  // *** Populates the graph.
  // Opens the stream.
  input_file.open(_name.c_str(), std::ios_base::in);
  // Reads the edgelist.
  while( !input_file.eof() )
  {
    // Finds the vertices' identity.
    input_file >> n1_str >> std::ws;
    n1 = std::atoi(n1_str.c_str()) - n_min;
    input_file >> n2_str >> std::ws;
    n2 = std::atoi(n2_str.c_str()) - n_min;
    // Finds the weight of the edge.
    w = 1;
    if(weighted)
    {
      input_file >> w_str  >> std::ws;
      w = std::atof(w_str.c_str());
    }
    the_graph[n1].neighbour_insert(n2,w);
    if(!directed)
      the_graph[n2].neighbour_insert(n1,w);    
  }
  // Closes the stream.
  input_file.close();

  // // Computes properties.
  // find_highest_degree_value();
  // find_highest_strength_value();
  // compute_disparity();
  // compute_average_degree();
  // compute_average_strength();
  // compute_degree_distribution();
}

void hyperbolic_graph::compute_average_degree_of_neighbours()
{
  // Iterators browsing the neighbours.
  hyperbolic_vertex::iterator it, end;
  // Temprary variable.
  dbl_t badn, wadn;
  // Computes the average degree of neighbours for every vertices.
  for(int_t n(0); n<nb_vertices; ++n)
  {
    // Gets iterators browsing the neighbours of vertex "n".
    it  = the_graph[n].neighbour_begin();
    end = the_graph[n].neighbour_end();
    // Resets the values.
    badn = 0;
    wadn = 0;
    // Browses all neighbours of vertex "n".
    for(; it != end; ++it)
    {
      badn += the_graph[it->first].get_degree();
      wadn += it->second * the_graph[it->first].get_degree();
    }
    // Normalisation (binary).
    if(the_graph[n].get_degree() > 0)
      badn /= the_graph[n].get_degree();
    // Normalisation (weighted).
    if(the_graph[n].get_strength() > 0)
      wadn /= the_graph[n].get_strength();
    // Sets the values.
    the_graph[n].set_binary_average_degree_of_neighbours(badn);
    the_graph[n].set_weighted_average_degree_of_neighbours(wadn);
  }
}


void hyperbolic_graph::export_triangles(std::string _name)
{
  // filename and stream
  std::ofstream output_file;
  std::string filename = _name + "_triangles.dat";
  output_file.open(filename.c_str(), std::ios_base::out);
  output_file.precision(8);

  // Iterators browsing the neighbours.
  hyperbolic_vertex::iterator it1, it2, it3, end1, end3;
  // Temporary variables.
  int_t n1, n2, d1, d2, d;
  double w1, w2, w3;
  bool triangle;
  // Calculation done for each vertex.
  for(int_t n(0); n<nb_vertices; ++n)
  {
    // Gets the degree of vertex "n"
    d = the_graph[n].get_degree();
    // Performs the calculation only if d>1
    if( d > 1 )
    {
      // Gets iterators browsing the neighbours of vertex "n".
      it1  = the_graph[n].neighbour_begin();
      end1 = the_graph[n].neighbour_end();
      // Browses the neighbours, determines if there is a triangle, and if so computes the contribution.
      for(; it1 != end1; ++it1)
      {
        // ID and degree of the first vertex.
        n1 = it1->first;
        w1 = it1->second;
        d1 = the_graph[n1].get_degree();
        // Setting up the calculation.
        it2 = it1;
        for(++it2; it2 != end1; ++it2)
        {
          // ID and degree of the second vertex.
          n2 = it2->first;
          w2 = it2->second;
          d2 = the_graph[n2].get_degree();
          triangle = false;
          // Browses the neighbourhood of the vertex with the smallest degree.
          if( d1>1 && d2>1 )
          {
            if( d1 < d2 )
            {
              // Iterators browsing the neighbourhood of the first vertex.
              it3  = the_graph[n1].neighbour_begin();
              end3 = the_graph[n1].neighbour_end();
              // Verifies if the second vertex is in the neighbourhood of the first vertex.
              for(; it3!=end3 && !triangle; ++it3)
                if( it3->first == n2 )
                {
                  w3 = it3->second;
                  triangle = true;
                }
            }
            else
            {
              // Iterators browsing the neighbourhood of the first vertex.
              it3  = the_graph[n2].neighbour_begin();
              end3 = the_graph[n2].neighbour_end();
              // Verifies if the second vertex is in the neighbourhood of the first vertex.
              for(; it3!=end3 && !triangle; ++it3)
                if( it3->first == n1 )
                {
                  w3 = it3->second;
                  triangle = true;
                }
            }

            // If "n1" and "n2" are connected.
            if( triangle )
            {
              if(n < n1 && n < n2)
              {
                output_file << n << "  " << n1 << "  " << n2 << "  " << w1 << "  " << w2 << "  " << w3 << std::endl;
              }
            }
          }
        }
      }
    }
  }
  // Closes the stream.
  output_file.close();
}



void hyperbolic_graph::compute_clustering_coefficients()
{
  // Iterators browsing the neighbours.
  hyperbolic_vertex::iterator it1, it2, it3, end1, end3;
  // Temporary variables.
  dbl_t bci, wci_serrano, s, y, wci_barrat, wci_onnela, wci_zhang/*, wci_zhangn*/;
  int_t n1, n2, d1, d2, d;
  bool triangle;
  // Calculation done for each vertex.
  for(int_t n(0); n<nb_vertices; ++n)
  {
    // Gets the degree of vertex "n"
    d = the_graph[n].get_degree();
    // Performs the calculation only if d>1
    if( d > 1 )
    {
      // Resets the coefficients.
      bci = 0;
      wci_serrano = 0;
      wci_barrat  = 0;
      wci_onnela  = 0;
      wci_zhang   = 0;
      // wci_zhangn  = 0;
      // Gets iterators browsing the neighbours of vertex "n".
      it1  = the_graph[n].neighbour_begin();
      end1 = the_graph[n].neighbour_end();
      // Browses the neighbours, determines if there is a triangle, and if so computes the contribution.
      for(; it1 != end1; ++it1)
      {
        // ID and degree of the first vertex.
        n1 = it1->first;
        d1 = the_graph[n1].get_degree();
        // Setting up the calculation.
        it2 = it1;
        for(++it2; it2 != end1; ++it2)
        {
          // ID and degree of the second vertex.
          n2 = it2->first;
          d2 = the_graph[n2].get_degree();
          triangle = false;
          // Browses the neighbourhood of the vertex with the smallest degree.
          if( d1>1 && d2>1 )
          {
            if( d1 < d2 )
            {
              // Iterators browsing the neighbourhood of the first vertex.
              it3  = the_graph[n1].neighbour_begin();
              end3 = the_graph[n1].neighbour_end();
              // Verifies if the second vertex is in the neighbourhood of the first vertex.
              for(; it3!=end3 && !triangle; ++it3)
                if( it3->first == n2 )
                  triangle = true;
            }
            else
            {
              // Iterators browsing the neighbourhood of the first vertex.
              it3  = the_graph[n2].neighbour_begin();
              end3 = the_graph[n2].neighbour_end();
              // Verifies if the second vertex is in the neighbourhood of the first vertex.
              for(; it3!=end3 && !triangle; ++it3)
                if( it3->first == n1 )
                  triangle = true;
            }

            // If "n1" and "n2" are connected.
            if( triangle )
            {
              // Binary clustering coefficient.
              bci += 1;
              // Weighted clustering coefficient (Serrano et al.).
              wci_serrano += 2. * it1->second * it2->second;
              // Weighted clustering coefficient (Barrat et al.).
              wci_barrat  += (it1->second + it2->second);
              // Weighted clustering coefficient (Onnela et al.).
              --it3;
              wci_onnela  += 2 * std::pow( it1->second * it2->second * it3->second , 1./3.);
              // Weighted clustering coefficient (Zhang et al.).
              wci_zhang   += 2. * it1->second * it2->second * it3->second;
              // wci_zhangn  += it1->second * it2->second;
            }
          }
        }
      }
      // Normalisation of the binary clustering coeffcient.
      bci /= ( d * (d-1) ) / 2.;
      // Normalisation of the weighted clustering coefficient.
      y = the_graph[n].get_disparity();
      s = the_graph[n].get_strength();
      wci_serrano /= std::pow(s,2) * (1. - y);
      wci_barrat  /= s * (d-1);
      wci_onnela  /= d * (d-1) * w_max;
      wci_zhang   /= std::pow(s,2) * (1. - y) * w_max;
      // Sets the values.
      the_graph[n].set_binary_clustering_coefficient(bci);
      the_graph[n].set_weighted_clustering_coefficients({wci_serrano,wci_barrat,wci_onnela,wci_zhang});
    }
    else // degree 0 or 1.
    {
      the_graph[n].set_binary_clustering_coefficient(0);
      the_graph[n].set_weighted_clustering_coefficients({0,0,0,0});
    }
  }
}


void hyperbolic_graph::compute_disparity()
{
  // Browses each vertex and computes its disparity.
  for(int_t n(0); n<nb_vertices; ++n)
    the_graph[n].set_disparity();
}

void hyperbolic_graph::analyse_graph(std::string option)
{
  // Initializes the variables.
  k_min = nb_vertices - 1;
  k_max = 0;
  k_avg = 0;
  nb_vertices_zerodegree = 0;
  s_min = std::numeric_limits<double>::max();
  s_max = 0;
  s_avg = 0;
  s_2mt = 0;
  s_2etaminus1 = 0;
  s_var = 0;
  w_min = std::numeric_limits<double>::max();
  w_max = 0;
  w_avg = 0;
  kappa_min = std::numeric_limits<double>::max();
  kappa_max = 0;
  kappa_avg = 0;
  sigma_min = std::numeric_limits<double>::max();
  sigma_max = 0;
  sigma_avg = 0;
  int int_tmp;
  double dbl_tmp;
  hyperbolic_vertex::iterator it, end;
  // Loops over avery vertex.
  for(int n(0); n<nb_vertices; ++n)
  {
    // Statistics about the degree.
    int_tmp = the_graph[n].get_degree();
    if( int_tmp > k_max )
      k_max = int_tmp;
    if( int_tmp > 0 )
      if( int_tmp < k_min )
        k_min = int_tmp;
    if( int_tmp == 0)
      ++nb_vertices_zerodegree;
    k_avg += int_tmp;
    // Statictics about the strength.
    dbl_tmp = the_graph[n].get_strength();
    if( dbl_tmp > s_max )
      s_max = dbl_tmp;
    if( int_tmp > 0 )
      if( dbl_tmp < s_min )
        s_min = dbl_tmp;
    s_avg += dbl_tmp;
    s_2mt += std::pow(dbl_tmp,2);
    // s_2etaminus1 += std::pow(dbl_tmp,2.0*pdf_sigma_param[0]-1.0);
    // Statistics about the weights.
    it  = the_graph[n].neighbour_begin();
    end = the_graph[n].neighbour_end();
    for(; it != end; ++it)
    {
      dbl_tmp = it->second;
      if( dbl_tmp > w_max )
        w_max = dbl_tmp;
      if( dbl_tmp < w_min )
        w_min = dbl_tmp;
      w_avg += dbl_tmp;
    }
    if(type_of_graph == "synthetic graph")
    {
      // Statictics about kappa
      dbl_tmp = the_graph[n].get_hidden_variables(0);
      if( dbl_tmp > kappa_max )
        kappa_max = dbl_tmp;
      if( dbl_tmp < kappa_min )
        kappa_min = dbl_tmp;
      kappa_avg += dbl_tmp;
      // Statictics about sigma
      dbl_tmp = the_graph[n].get_hidden_variables(1);
      if( dbl_tmp > sigma_max )
        sigma_max = dbl_tmp;
      if( dbl_tmp < sigma_min )
        sigma_min = dbl_tmp;
      sigma_avg += dbl_tmp;
    }
  }
  // Finalizes the calculations of average values.
  k_avg     /= nb_vertices;
  s_avg     /= nb_vertices;
  s_2mt     /= nb_vertices;
  s_2etaminus1 /= nb_vertices;
  s_var      = s_2mt - std::pow(s_avg,2);
  w_avg     /= k_avg * nb_vertices;
  kappa_avg /= nb_vertices;
  sigma_avg /= nb_vertices;

  // // Computes other properties.
  compute_degree_distribution();
  if(option == "complete")
  {
    compute_disparity();
    compute_average_degree_of_neighbours();
    compute_clustering_coefficients();
    compute_nonstructural_correlation_coefficients();
  }
}


// void hyperbolic_graph::find_highest_strength_value()
// {
//   // Browses each vertex and finds the highest degree.
//   s_max = 0;
//   for(int_t n(0); n<nb_vertices; ++n)
//     if( the_graph[n].get_strength() > s_max )
//       s_max = the_graph[n].get_strength();
// }


// void hyperbolic_graph::find_highest_degree_value()
// {
//   // Browses each vertex and finds the highest degree.
//   k_max = 0;
//   for(int_t n(0); n<nb_vertices; ++n)
//     if( the_graph[n].get_degree() > k_max )
//       k_max = the_graph[n].get_degree();
// }


void hyperbolic_graph::compute_degree_distribution()
{
  // Resizes "degree_distribution".
  degree_distribution.clear();
  degree_distribution.resize(k_max+1,0);
  // Browses each vertex and populates "degree_distribution".
  for(int_t n(0); n<nb_vertices; ++n)
    degree_distribution[the_graph[n].get_degree()] += 1;
  // Sets the number of vertices whose degree is zero.
  nb_vertices_zerodegree = degree_distribution[0];
  degree_zero_vertices   = degree_distribution[0];
  // Normalizes "degree_distribution".
  for(int_t k(0); k<=k_max; ++k)
    degree_distribution[k] /= nb_vertices;
}


// void hyperbolic_graph::compute_average_degree()
// {
//   // Browses each vertex and sums their degree.
//   k_avg = 0;
//   for(int_t n(0); n<nb_vertices; ++n)
//     if(the_graph[n].get_degree() > 0)
//       k_avg += the_graph[n].get_degree();
//   k_avg /= nb_vertices;
//   // if( nb_vertices_zerodegree < nb_vertices)
//   //   k_avg /= nb_vertices - nb_vertices_zerodegree;
// }

// void hyperbolic_graph::compute_average_strength()
// {
//   // Browses each vertex and sums their degree.
//   s_avg = 0;
//   for(int_t n(0); n<nb_vertices; ++n)
//     if(the_graph[n].get_degree() > 0)
//       s_avg += the_graph[n].get_strength();
//   s_avg /= nb_vertices;
//   // if( nb_vertices_zerodegree < nb_vertices)
//   //   s_avg /= nb_vertices - nb_vertices_zerodegree;
// }


void hyperbolic_graph::compute_average_strength_per_degree()
{
  // Resizes "average_strength_per_degree".
  average_strength_per_degree.clear();
  average_strength_per_degree.resize(k_max+1,0);
  // Browses each vertex and populates "average_strength_per_degree".
  for(int_t n(0); n<nb_vertices; ++n)
    average_strength_per_degree[the_graph[n].get_degree()] += the_graph[n].get_strength();
  // Normalizes "degree_distribution".
  for(int_t k(0); k<=k_max; ++k)
    average_strength_per_degree[k] /= nb_vertices * degree_distribution[k];
}


void hyperbolic_graph::compute_average_squared_strength_times_one_minus_disparity_per_degree()
{
  // Resizes "average_strength_per_degree".
  average_squared_strength_times_one_minus_disparity_per_degree.clear();
  average_squared_strength_times_one_minus_disparity_per_degree.resize(k_max+1,0);
  // Browses each vertex and populates "average_strength_per_degree".
  for(int_t n(0); n<nb_vertices; ++n)
    average_squared_strength_times_one_minus_disparity_per_degree[the_graph[n].get_degree()] += std::pow(the_graph[n].get_strength(),2) * (1 - the_graph[n].get_disparity());
  // Normalizes "degree_distribution".
  for(int_t k(0); k<=k_max; ++k)
    if(degree_distribution[k] > 0)
      average_squared_strength_times_one_minus_disparity_per_degree[k] /= nb_vertices * degree_distribution[k];
}


void hyperbolic_graph::compute_nonstructural_correlation_coefficients()
{
  // Computes quantities prior to the main calculations.
  // find_highest_degree_value();
  // compute_degree_distribution();
  compute_average_strength_per_degree();
  compute_average_squared_strength_times_one_minus_disparity_per_degree();
  // Computes the adjusted correlation coefficients.
  int_t tmp_degree;
  dbl_t tmp_value;
  for(int_t n(0); n<nb_vertices; ++n)
  {
    // Degree of the vertex.
    tmp_degree = the_graph[n].get_degree();
    // Non structural weighted average degree of the neighbours.
    if(tmp_degree > 0)
    {
      tmp_value  = the_graph[n].get_weighted_average_degree_of_neighbours();
      tmp_value *= the_graph[n].get_strength();
      tmp_value /= average_strength_per_degree[the_graph[n].get_degree()];
      the_graph[n].set_nonstructural_weighted_average_degree_of_neighbours(tmp_value);
    }
    else
    {
      the_graph[n].set_nonstructural_weighted_average_degree_of_neighbours(0);
    }
    // Non structural weighted clustering coefficient.
    if(tmp_degree > 1)
    {
      tmp_value  = the_graph[n].get_weighted_clustering_coefficients()[0];
      tmp_value *= std::pow(the_graph[n].get_strength(),2) * (1 - the_graph[n].get_disparity());
      tmp_value /= average_squared_strength_times_one_minus_disparity_per_degree[tmp_degree];
      the_graph[n].set_nonstructural_weighted_clustering_coefficient(tmp_value);
    }
    else
    {
      the_graph[n].set_nonstructural_weighted_clustering_coefficient(0);
    }
  }
}


void hyperbolic_graph::make_graph(int _nb_vertices, std::string _geometry, double _delta, double _alpha, std::string _pdf_kappa_type, std::vector<double> _pdf_kappa_param, std::string _pdf_sigma_type, std::vector<double> _pdf_sigma_param, std::string _prob_connection_type, std::vector<double> _prob_connection_param, std::string _pdf_weights_type, std::vector<double> _pdf_weights_param, std::mt19937& _engine)
{
  // ==============================================================================================
  // *** Indicates the information on the graph.
  type_of_graph         = "synthetic graph";
  nb_vertices           = _nb_vertices;
  geometry              = _geometry;
  alpha                 = _alpha;
  pdf_kappa_type        = _pdf_kappa_type;
  pdf_kappa_param       = _pdf_kappa_param;
  pdf_sigma_type        = _pdf_sigma_type;
  pdf_sigma_param       = _pdf_sigma_param;
  prob_connection_type  = _prob_connection_type;
  prob_connection_param = _prob_connection_param;
  pdf_weights_type      = _pdf_weights_type;
  pdf_weights_param     = _pdf_weights_param;
  delta                 = _delta;

  // ==============================================================================================
  // *** Declares variables.
  double tmp_phi, tmp_theta, tmp_kappa, tmp_sigma, tmp_dist, tmp_chi, tmp_w_c, tmp_r, tmp_w;
  double radius, dim, I_1, I_2, I_3;
  std::vector<double> x1, x2, k1, k2;

  // ==============================================================================================
  // *** Sets values related to the geometry.
  if( geometry == "S1" )
  {
    dim = 1.0;                                   // Sets the dimension of the metric space.
    radius = nb_vertices / (2 * Pi * delta); // Computes the radius of the sphere.
  }
  if( geometry == "S2" ) // Computes the radius of the sphere.
  {
    dim = 2.0;                                                // Sets the dimension of the metric space.
    radius = std::sqrt( nb_vertices / (4 * Pi * delta) ); // Computes the radius of the sphere.
  }

  // ==============================================================================================
  // *** Computes the moments of $\rho(\kappa,\sigma)$.
  // Computes the average value of kappa.
  if( pdf_kappa_type == "pdf_powerlaw_hardcutoff" )
  {
    // mean_kappa = ( ( pdf_kappa_param[0]-1 ) * pdf_kappa_param[1] ) / ( ( pdf_kappa_param[0]-2 ) );
    mean_kappa = ( ( pdf_kappa_param[0]-1 ) * pdf_kappa_param[1] * ( 1 - std::pow(pdf_kappa_param[2]/pdf_kappa_param[1],2-pdf_kappa_param[0]) ) ) / ( ( pdf_kappa_param[0]-2 ) * ( 1 - std::pow(pdf_kappa_param[2]/pdf_kappa_param[1],1-pdf_kappa_param[0]) ) );
  }
  // if( pdf_kappa_type == "pdf_powerlaw_expocutoff" )
  // {
  //   mean_kappa = pdf_kappa_param[2] * gsl_sf_gamma_inc(2.0-pdf_kappa_param[0], pdf_kappa_param[1]/pdf_kappa_param[2]) / gsl_sf_gamma_inc(1.0-pdf_kappa_param[0], pdf_kappa_param[1]/pdf_kappa_param[2]);
  // }
  if( pdf_kappa_type == "pdf_exponential" )
  {
    mean_kappa = pdf_kappa_param[0];
  }
  // if( pdf_kappa_type == "pdf_exponential_bounded" ) IL MANQUERA QUELQUE AJOUT DANS LES AUTRES VARIABLES POUR POUVOIR UTILISER CETTE OPTION
  // {
  //   mean_kappa = pdf_kappa_param[0] + pdf_kappa_param[1] + ( (pdf_kappa_param[2]-pdf_kappa_param[1]) / (1.0 - std::exp((pdf_kappa_param[2]-pdf_kappa_param[1])/pdf_kappa_param[0])) );
  // }
  // Computes the average value of sigma.
  if( pdf_sigma_type == "deterministic_scaling" || pdf_sigma_type == "deterministic_scaling_noised_gamma" )
  {
    if( pdf_kappa_type == "pdf_powerlaw_hardcutoff" )
    {
      // mean_sigma = ( pdf_sigma_param[1] * ( pdf_kappa_param[0]-1 ) * std::pow(pdf_kappa_param[1],pdf_sigma_param[0]) ) / ( ( pdf_kappa_param[0]-pdf_sigma_param[0]-1 ) );
      mean_sigma = ( pdf_sigma_param[1] * ( pdf_kappa_param[0]-1 ) * std::pow(pdf_kappa_param[1],pdf_sigma_param[0]) * ( 1 - std::pow(pdf_kappa_param[2]/pdf_kappa_param[1],1+pdf_sigma_param[0]-pdf_kappa_param[0]) ) ) / ( ( pdf_kappa_param[0]-pdf_sigma_param[0]-1 ) * ( 1 - std::pow(pdf_kappa_param[2]/pdf_kappa_param[1],1-pdf_kappa_param[0]) ) );
    }
    // if( pdf_kappa_type == "pdf_powerlaw_expocutoff" )
    // {
    //   mean_sigma = pdf_sigma_param[1] * std::pow(pdf_kappa_param[2], pdf_sigma_param[0] ) * gsl_sf_gamma_inc(pdf_sigma_param[0]+1.0-pdf_kappa_param[0], pdf_kappa_param[2]/pdf_kappa_param[1]) / gsl_sf_gamma_inc(1.0-pdf_kappa_param[0], pdf_kappa_param[2]/pdf_kappa_param[1]);
    // }
    if( pdf_kappa_type == "pdf_exponential" )
    {
      mean_sigma = pdf_sigma_param[1] * std::pow(pdf_kappa_param[0],pdf_sigma_param[0]) * std::tgamma(pdf_sigma_param[0]+1.0);
    }
  }

  // ==============================================================================================
  // *** Computes the integral.
  // Computes the integrals I_1 and I_3.
  if( prob_connection_type == "prob_FermiDirac" )
  {
    if( prob_connection_param[0] > dim )
      I_1 = (Pi/prob_connection_param[0]) / std::sin(dim * Pi / prob_connection_param[0]);
    if( std::fabs(dim-alpha) < 1e-12 )
      I_3 = std::log(nb_vertices);  // PEUT-ÊTRE AJOUTER DES FACTEURS DE PROPORTIONALITÉ QUAND LE CALCUL EXACT SERA FAIT.
    else if( prob_connection_param[0] > dim-alpha )
      I_3 = (Pi/prob_connection_param[0]) / std::sin( (dim-alpha) * Pi / prob_connection_param[0]);
  }
// std::cout<<I_3<<std::endl;
  // Computes the integral I_2.
  if( pdf_weights_type == "pdf_exponential" )
    I_2 = pdf_weights_param[0];
  if( pdf_weights_type == "pdf_exponential_bounded" )
    I_2 = pdf_weights_param[0] + pdf_weights_param[1] + ((pdf_weights_param[2]-pdf_weights_param[1])/(1.0 - std::exp((pdf_weights_param[2]-pdf_weights_param[1])/pdf_weights_param[0])));
  if( pdf_weights_type == "pdf_exponential_lowerbounded" )
    I_2 = pdf_weights_param[0] + pdf_weights_param[1];
  if( pdf_weights_type == "pdf_gamma" )
    I_2 = pdf_weights_param[0] * pdf_weights_param[1];
  if( pdf_weights_type == "pdf_delta" )
    I_2 = 1.0;
  // if( pdf_weights_type == "pdf_powerlaw_expocutoff" )
  //   I_2 = pdf_weights_param[3] * ( gsl_sf_gamma_inc(2.-pdf_weights_param[0], pdf_weights_param[1]/pdf_weights_param[3]) - gsl_sf_gamma_inc(2.-pdf_weights_param[0], pdf_weights_param[2]/pdf_weights_param[3]) ) / ( gsl_sf_gamma_inc(1.-pdf_weights_param[0], pdf_weights_param[1]/pdf_weights_param[3]) - gsl_sf_gamma_inc(1.-pdf_weights_param[0], pdf_weights_param[2]/pdf_weights_param[3]) );

  // ==============================================================================================
  // *** Computes the proportionality factors.
  // Computes the factor mu.
  mu = std::pow( ( std::tgamma(dim/2.) ) / ( 2 * std::pow(Pi,dim/2.) * delta * mean_kappa * I_1 ) , 1./dim);
  // Computes the factor nu.
  nu = ( std::tgamma(dim/2.) ) / ( 2 * std::pow(Pi,dim/2.) * delta * std::pow(mu,dim-alpha) * I_2 * mean_sigma * I_3 );
  // nu = 0.05;

  // ==============================================================================================
  // *** Creates the graph and its vertices.
  the_graph.resize( nb_vertices );

  // ==============================================================================================
  // *** Sets the position and the hidden variables of the vertices.
  for(int n(0); n<nb_vertices; ++n)
  {
    // Sets the position of the vertex in the metric space.
    if( geometry == "S1" )
    {
      // Computes the angular position.
      tmp_phi = 2 * Pi * uniform_01(_engine);
      // Sets the position.
      the_graph[n].set_metric_space_position( {radius,tmp_phi} );
    }
    if( geometry == "S2" )
    {
      // Computes the azimuthal angle.
      tmp_phi   = 2 * Pi * uniform_01(_engine);
      tmp_theta = std::acos( 2 * uniform_01(_engine) - 1 );
      // Sets the position.
      the_graph[n].set_metric_space_position( {radius,tmp_phi, tmp_theta} );
    }

    // Sets the value of the hidden variable kappa.
    if( pdf_kappa_type == "pdf_powerlaw_hardcutoff" )
      tmp_kappa = pdf_powerlaw_hardcutoff(pdf_kappa_param, _engine);
    if( pdf_kappa_type == "pdf_powerlaw_expocutoff" )
      tmp_kappa = pdf_powerlaw_expocutoff(pdf_kappa_param, _engine);
    if( pdf_kappa_type == "pdf_exponential" )
      tmp_kappa = pdf_exponential(pdf_kappa_param[0], _engine);
    // Sets the value of the hidden variable sigma.
    if( pdf_sigma_type == "deterministic_scaling" )
      tmp_sigma = pdf_sigma_param[1] * std::pow(tmp_kappa,pdf_sigma_param[0]);
    if( pdf_sigma_type == "deterministic_scaling_noised_gamma" )
      tmp_sigma = pdf_gamma({pdf_sigma_param[1]*std::pow(tmp_kappa,pdf_sigma_param[0])/pdf_sigma_param[2],pdf_sigma_param[2]}, _engine);
    the_graph[n].set_hidden_variables( {tmp_kappa,tmp_sigma} );
  }

  // ==============================================================================================
  // *** Sets the connections between the vertices.
  for(int_t n1(0); n1<nb_vertices; ++n1)
  {
    // // Prints on screen the value of n1 (if the graph is large enough).
    // if(nb_vertices > 19999)
    //   std::cout << "\r"<< n1;
    // Gets the position of the first vertex.
    x1 = the_graph[n1].get_metric_space_position();
    //Gets the hidden variables of the first vertex.
    k1 = the_graph[n1].get_hidden_variables();

    for(int_t n2(n1+1); n2<nb_vertices; ++n2)
    {
      // Gets the position of the first vertex.
      x2 = the_graph[n2].get_metric_space_position();
      //Gets the hidden variables of the first vertex.
      k2 = the_graph[n2].get_hidden_variables();
      // Computes the distance between the two vertices.
      if(geometry == "S1")
        tmp_dist = distance_S1(radius,x1[1],x2[1]);
      if(geometry == "S2")
        tmp_dist = distance_S2(radius,x1[1],x1[2],x2[1],x2[2]);
      // Computes the "chi" factor.
      tmp_chi = tmp_dist / (mu * std::pow(k1[0] * k2[0],1./dim));
      // Computes the "w_c" factor.
      // tmp_w_c = (nu * k1[1] * k2[1]) / (std::pow(k1[0]*k2[0],1.-alpha/dim) * std::pow(tmp_dist,alpha));
      tmp_w_c = (nu * k1[1] * k2[1]);
      if(std::fabs(alpha-dim) < 1e-12)
        tmp_w_c /= std::pow(tmp_dist,alpha);
      else if(std::fabs(alpha) < 1e-12)
        tmp_w_c /= (k1[0]*k2[0]);
      else
        tmp_w_c = (nu * k1[1] * k2[1]) / (std::pow(k1[0]*k2[0],1.-alpha/dim) * std::pow(tmp_dist,alpha));
      // Computes the probability of connection.
      if( prob_connection_type == "prob_FermiDirac" )
        tmp_r = 1. / (std::pow(tmp_chi,prob_connection_param[0]) + 1);
      // Creates the edge, if any.
      if( uniform_01(_engine) < tmp_r )
      {
        // Computes the weight of the edge.
        if( pdf_weights_type == "pdf_exponential" )
          tmp_w = tmp_w_c * pdf_exponential(pdf_weights_param[0], _engine);
        if( pdf_weights_type == "pdf_exponential_bounded" )
          tmp_w = tmp_w_c * pdf_exponential_bounded(pdf_weights_param, _engine);
        if( pdf_weights_type == "pdf_exponential_lowerbounded" )
          tmp_w = tmp_w_c * (pdf_exponential(pdf_weights_param[0], _engine)) + pdf_weights_param[1];
        if( pdf_weights_type == "pdf_gamma" )
          tmp_w = tmp_w_c * pdf_gamma(pdf_weights_param, _engine);
        if( pdf_weights_type == "pdf_delta" )
          tmp_w = tmp_w_c;
        // if( pdf_weights_type == "pdf_powerlaw_expocutoff")
        //   tmp_w = tmp_w_c * pdf_powerlaw_expocutoff(pdf_weights_param, _engine);
        // Creates the edge
        the_graph[n1].neighbour_insert(n2,tmp_w);
        the_graph[n2].neighbour_insert(n1,tmp_w);
      }
// std::cout<<n1<<"  "<<n2<<std::endl;
    }
  }
  // // Prints on screen the value of n1 (if the graph is large enough).
  // if(nb_vertices > 19999)
  //   std::cout<<std::endl;
  // // Computes properties.
  // find_highest_degree_value();
  // find_highest_strength_value();
  // compute_disparity();
  // compute_average_degree();
  // compute_average_strength();
  // compute_degree_distribution();
}

void hyperbolic_graph::make_graph_fixed_kappa_sequence(int _nb_vertices, std::string _geometry, double _delta, double _alpha, std::string _pdf_kappa_type, std::vector<double> _pdf_kappa_param,std::vector<double> kappa_sequence, std::string _pdf_sigma_type, std::vector<double> _pdf_sigma_param, std::string _prob_connection_type, std::vector<double> _prob_connection_param, std::string _pdf_weights_type, std::vector<double> _pdf_weights_param, std::mt19937& _engine)
{
  // ==============================================================================================
  // *** Indicates the information on the graph.
  type_of_graph         = "synthetic graph";
  nb_vertices           = _nb_vertices;
  geometry              = _geometry;
  alpha                 = _alpha;
  pdf_kappa_type        = _pdf_kappa_type;
  pdf_kappa_param       = _pdf_kappa_param;
  pdf_sigma_type        = _pdf_sigma_type;
  pdf_sigma_param       = _pdf_sigma_param;
  prob_connection_type  = _prob_connection_type;
  prob_connection_param = _prob_connection_param;
  pdf_weights_type      = _pdf_weights_type;
  pdf_weights_param     = _pdf_weights_param;
  delta                 = _delta;

  // ==============================================================================================
  // *** Declares variables.
  double tmp_phi, tmp_theta, tmp_kappa, tmp_sigma, tmp_dist, tmp_chi, tmp_w_c, tmp_r, tmp_w;
  double radius, dim, I_1, I_2, I_3;
  std::vector<double> x1, x2, k1, k2;

  // ==============================================================================================
  // *** Sets values related to the geometry.
  if( geometry == "S1" )
  {
    dim = 1.0;                                   // Sets the dimension of the metric space.
    radius = nb_vertices / (2 * Pi * delta); // Computes the radius of the sphere.
  }
  if( geometry == "S2" ) // Computes the radius of the sphere.
  {
    dim = 2.0;                                                // Sets the dimension of the metric space.
    radius = std::sqrt( nb_vertices / (4 * Pi * delta) ); // Computes the radius of the sphere.
  }

  // ==============================================================================================
  // *** Computes the moments of $\rho(\kappa,\sigma)$.
  mean_kappa = 0;
  mean_sigma = 0;
  for(unsigned int n(0); n<nb_vertices; ++n)
  {
    mean_kappa += kappa_sequence[n];
    mean_sigma += pdf_sigma_param[1] * std::pow(kappa_sequence[n], pdf_sigma_param[0]);
  }
  mean_kappa /= nb_vertices;
  mean_sigma /= nb_vertices;

  // // Computes the average value of kappa.
  // if( pdf_kappa_type == "pdf_powerlaw_hardcutoff" )
  // {
  //   // mean_kappa = ( ( pdf_kappa_param[0]-1 ) * pdf_kappa_param[1] ) / ( ( pdf_kappa_param[0]-2 ) );
  //   mean_kappa = ( ( pdf_kappa_param[0]-1 ) * pdf_kappa_param[1] * ( 1 - std::pow(pdf_kappa_param[2]/pdf_kappa_param[1],2-pdf_kappa_param[0]) ) ) / ( ( pdf_kappa_param[0]-2 ) * ( 1 - std::pow(pdf_kappa_param[2]/pdf_kappa_param[1],1-pdf_kappa_param[0]) ) );
  // }
  // // if( pdf_kappa_type == "pdf_powerlaw_expocutoff" )
  // // {
  // //   mean_kappa = pdf_kappa_param[2] * gsl_sf_gamma_inc(2.0-pdf_kappa_param[0], pdf_kappa_param[1]/pdf_kappa_param[2]) / gsl_sf_gamma_inc(1.0-pdf_kappa_param[0], pdf_kappa_param[1]/pdf_kappa_param[2]);
  // // }
  // if( pdf_kappa_type == "pdf_exponential" )
  // {
  //   mean_kappa = pdf_kappa_param[0];
  // }
  // // if( pdf_kappa_type == "pdf_exponential_bounded" ) IL MANQUERA QUELQUE AJOUT DANS LES AUTRES VARIABLES POUR POUVOIR UTILISER CETTE OPTION
  // // {
  // //   mean_kappa = pdf_kappa_param[0] + pdf_kappa_param[1] + ( (pdf_kappa_param[2]-pdf_kappa_param[1]) / (1.0 - std::exp((pdf_kappa_param[2]-pdf_kappa_param[1])/pdf_kappa_param[0])) );
  // // }
  // // Computes the average value of sigma.
  // if( pdf_sigma_type == "deterministic_scaling" || pdf_sigma_type == "deterministic_scaling_noised_gamma" )
  // {
  //   if( pdf_kappa_type == "pdf_powerlaw_hardcutoff" )
  //   {
  //     // mean_sigma = ( pdf_sigma_param[1] * ( pdf_kappa_param[0]-1 ) * std::pow(pdf_kappa_param[1],pdf_sigma_param[0]) ) / ( ( pdf_kappa_param[0]-pdf_sigma_param[0]-1 ) );
  //     mean_sigma = ( pdf_sigma_param[1] * ( pdf_kappa_param[0]-1 ) * std::pow(pdf_kappa_param[1],pdf_sigma_param[0]) * ( 1 - std::pow(pdf_kappa_param[2]/pdf_kappa_param[1],1+pdf_sigma_param[0]-pdf_kappa_param[0]) ) ) / ( ( pdf_kappa_param[0]-pdf_sigma_param[0]-1 ) * ( 1 - std::pow(pdf_kappa_param[2]/pdf_kappa_param[1],1-pdf_kappa_param[0]) ) );
  //   }
  //   // if( pdf_kappa_type == "pdf_powerlaw_expocutoff" )
  //   // {
  //   //   mean_sigma = pdf_sigma_param[1] * std::pow(pdf_kappa_param[2], pdf_sigma_param[0] ) * gsl_sf_gamma_inc(pdf_sigma_param[0]+1.0-pdf_kappa_param[0], pdf_kappa_param[2]/pdf_kappa_param[1]) / gsl_sf_gamma_inc(1.0-pdf_kappa_param[0], pdf_kappa_param[2]/pdf_kappa_param[1]);
  //   // }
  //   if( pdf_kappa_type == "pdf_exponential" )
  //   {
  //     mean_sigma = pdf_sigma_param[1] * std::pow(pdf_kappa_param[0],pdf_sigma_param[0]) * std::tgamma(pdf_sigma_param[0]+1.0);
  //   }
  // }

  // ==============================================================================================
  // *** Computes the integral.
  // Computes the integrals I_1 and I_3.
  if( prob_connection_type == "prob_FermiDirac" )
  {
    if( prob_connection_param[0] > dim )
      I_1 = (Pi/prob_connection_param[0]) / std::sin(dim * Pi / prob_connection_param[0]);
    if( std::fabs(dim-alpha) < 1e-12 )
      I_3 = std::log(nb_vertices);  // PEUT-ÊTRE AJOUTER DES FACTEURS DE PROPORTIONALITÉ QUAND LE CALCUL EXACT SERA FAIT.
    else if( prob_connection_param[0] > dim-alpha )
      I_3 = (Pi/prob_connection_param[0]) / std::sin( (dim-alpha) * Pi / prob_connection_param[0]);
  }
// std::cout<<I_3<<std::endl;
  // Computes the integral I_2.
  if( pdf_weights_type == "pdf_exponential" )
    I_2 = pdf_weights_param[0];
  if( pdf_weights_type == "pdf_exponential_bounded" )
    I_2 = pdf_weights_param[0] + pdf_weights_param[1] + ((pdf_weights_param[2]-pdf_weights_param[1])/(1.0 - std::exp((pdf_weights_param[2]-pdf_weights_param[1])/pdf_weights_param[0])));
  if( pdf_weights_type == "pdf_exponential_lowerbounded" )
    I_2 = pdf_weights_param[0] + pdf_weights_param[1];
  if( pdf_weights_type == "pdf_gamma" )
    I_2 = pdf_weights_param[0] * pdf_weights_param[1];
  if( pdf_weights_type == "pdf_delta" )
    I_2 = 1.0;
  // if( pdf_weights_type == "pdf_powerlaw_expocutoff" )
  //   I_2 = pdf_weights_param[3] * ( gsl_sf_gamma_inc(2.-pdf_weights_param[0], pdf_weights_param[1]/pdf_weights_param[3]) - gsl_sf_gamma_inc(2.-pdf_weights_param[0], pdf_weights_param[2]/pdf_weights_param[3]) ) / ( gsl_sf_gamma_inc(1.-pdf_weights_param[0], pdf_weights_param[1]/pdf_weights_param[3]) - gsl_sf_gamma_inc(1.-pdf_weights_param[0], pdf_weights_param[2]/pdf_weights_param[3]) );

  // ==============================================================================================
  // *** Computes the proportionality factors.
  // Computes the factor mu.
  mu = std::pow( ( std::tgamma(dim/2.) ) / ( 2 * std::pow(Pi,dim/2.) * delta * mean_kappa * I_1 ) , 1./dim);
  // Computes the factor nu.
  nu = ( std::tgamma(dim/2.) ) / ( 2 * std::pow(Pi,dim/2.) * delta * std::pow(mu,dim-alpha) * I_2 * mean_sigma * I_3 );
  // nu = 0.05;

  // ==============================================================================================
  // *** Creates the graph and its vertices.
  the_graph.resize( nb_vertices );

  // ==============================================================================================
  // *** Sets the position and the hidden variables of the vertices.
  for(int n(0); n<nb_vertices; ++n)
  {
    // Sets the position of the vertex in the metric space.
    if( geometry == "S1" )
    {
      // Computes the angular position.
      tmp_phi = 2 * Pi * uniform_01(_engine);
      // Sets the position.
      the_graph[n].set_metric_space_position( {radius,tmp_phi} );
    }
    if( geometry == "S2" )
    {
      // Computes the azimuthal angle.
      tmp_phi   = 2 * Pi * uniform_01(_engine);
      tmp_theta = std::acos( 2 * uniform_01(_engine) - 1 );
      // Sets the position.
      the_graph[n].set_metric_space_position( {radius,tmp_phi, tmp_theta} );
    }

    // Sets the value of the hidden variable kappa.
    tmp_kappa = kappa_sequence[n];
    // if( pdf_kappa_type == "pdf_powerlaw_hardcutoff" )
    //   tmp_kappa = pdf_powerlaw_hardcutoff(pdf_kappa_param, _engine);
    // if( pdf_kappa_type == "pdf_powerlaw_expocutoff" )
    //   tmp_kappa = pdf_powerlaw_expocutoff(pdf_kappa_param, _engine);
    // if( pdf_kappa_type == "pdf_exponential" )
    //   tmp_kappa = pdf_exponential(pdf_kappa_param[0], _engine);

    // Sets the value of the hidden variable sigma.
    if( pdf_sigma_type == "deterministic_scaling" )
      tmp_sigma = pdf_sigma_param[1] * std::pow(tmp_kappa,pdf_sigma_param[0]);
    if( pdf_sigma_type == "deterministic_scaling_noised_gamma" )
      tmp_sigma = pdf_gamma({pdf_sigma_param[1]*std::pow(tmp_kappa,pdf_sigma_param[0])/pdf_sigma_param[2],pdf_sigma_param[2]}, _engine);
    the_graph[n].set_hidden_variables( {tmp_kappa,tmp_sigma} );
  }

  // ==============================================================================================
  // *** Sets the connections between the vertices.
  for(int_t n1(0); n1<nb_vertices; ++n1)
  {
    // // Prints on screen the value of n1 (if the graph is large enough).
    // if(nb_vertices > 19999)
    //   std::cout << "\r"<< n1;
    // Gets the position of the first vertex.
    x1 = the_graph[n1].get_metric_space_position();
    //Gets the hidden variables of the first vertex.
    k1 = the_graph[n1].get_hidden_variables();

    for(int_t n2(n1+1); n2<nb_vertices; ++n2)
    {
      // Gets the position of the first vertex.
      x2 = the_graph[n2].get_metric_space_position();
      //Gets the hidden variables of the first vertex.
      k2 = the_graph[n2].get_hidden_variables();
      // Computes the distance between the two vertices.
      if(geometry == "S1")
        tmp_dist = distance_S1(radius,x1[1],x2[1]);
      if(geometry == "S2")
        tmp_dist = distance_S2(radius,x1[1],x1[2],x2[1],x2[2]);
      // Computes the "chi" factor.
      tmp_chi = tmp_dist / (mu * std::pow(k1[0] * k2[0],1./dim));
      // Computes the "w_c" factor.
      // tmp_w_c = (nu * k1[1] * k2[1]) / (std::pow(k1[0]*k2[0],1.-alpha/dim) * std::pow(tmp_dist,alpha));
      tmp_w_c = (nu * k1[1] * k2[1]);
      if(std::fabs(alpha-dim) < 1e-12)
        tmp_w_c /= std::pow(tmp_dist,alpha);
      else if(std::fabs(alpha) < 1e-12)
        tmp_w_c /= (k1[0]*k2[0]);
      else
        tmp_w_c = (nu * k1[1] * k2[1]) / (std::pow(k1[0]*k2[0],1.-alpha/dim) * std::pow(tmp_dist,alpha));
      // Computes the probability of connection.
      if( prob_connection_type == "prob_FermiDirac" )
        tmp_r = 1. / (std::pow(tmp_chi,prob_connection_param[0]) + 1);
      // Creates the edge, if any.
      if( uniform_01(_engine) < tmp_r )
      {
        // Computes the weight of the edge.
        if( pdf_weights_type == "pdf_exponential" )
          tmp_w = tmp_w_c * pdf_exponential(pdf_weights_param[0], _engine);
        if( pdf_weights_type == "pdf_exponential_bounded" )
          tmp_w = tmp_w_c * pdf_exponential_bounded(pdf_weights_param, _engine);
        if( pdf_weights_type == "pdf_exponential_lowerbounded" )
          tmp_w = tmp_w_c * (pdf_exponential(pdf_weights_param[0], _engine)) + pdf_weights_param[1];
        if( pdf_weights_type == "pdf_gamma" )
          tmp_w = tmp_w_c * pdf_gamma(pdf_weights_param, _engine);
        if( pdf_weights_type == "pdf_delta" )
          tmp_w = tmp_w_c;
        // if( pdf_weights_type == "pdf_powerlaw_expocutoff")
        //   tmp_w = tmp_w_c * pdf_powerlaw_expocutoff(pdf_weights_param, _engine);
        // Creates the edge
        the_graph[n1].neighbour_insert(n2,tmp_w);
        the_graph[n2].neighbour_insert(n1,tmp_w);
      }
// std::cout<<n1<<"  "<<n2<<std::endl;
    }
  }
  // // Prints on screen the value of n1 (if the graph is large enough).
  // if(nb_vertices > 19999)
  //   std::cout<<std::endl;
  // // Computes properties.
  // find_highest_degree_value();
  // find_highest_strength_value();
  // compute_disparity();
  // compute_average_degree();
  // compute_average_strength();
  // compute_degree_distribution();
}


void hyperbolic_graph::make_graph_fixed_kappa_sigma_sequences(int _nb_vertices, std::string _geometry, double _delta, double _alpha, std::string _pdf_kappa_type, std::vector<double> _pdf_kappa_param, std::vector<double> kappa_sequence, std::string _pdf_sigma_type, std::vector<double> _pdf_sigma_param, std::vector<double> sigma_sequence, std::string _prob_connection_type, std::vector<double> _prob_connection_param, std::string _pdf_weights_type, std::vector<double> _pdf_weights_param, std::mt19937& _engine)
{
  // ==============================================================================================
  // *** Indicates the information on the graph.
  type_of_graph         = "synthetic graph";
  nb_vertices           = _nb_vertices;
  geometry              = _geometry;
  alpha                 = _alpha;
  pdf_kappa_type        = _pdf_kappa_type;
  pdf_kappa_param       = _pdf_kappa_param;
  pdf_sigma_type        = _pdf_sigma_type;
  pdf_sigma_param       = _pdf_sigma_param;
  prob_connection_type  = _prob_connection_type;
  prob_connection_param = _prob_connection_param;
  pdf_weights_type      = _pdf_weights_type;
  pdf_weights_param     = _pdf_weights_param;
  delta                 = _delta;

  // ==============================================================================================
  // *** Declares variables.
  double tmp_phi, tmp_theta, tmp_kappa, tmp_sigma, tmp_dist, tmp_chi, tmp_w_c, tmp_r, tmp_w;
  double radius, dim, I_1, I_2, I_3;
  std::vector<double> x1, x2, k1, k2;

  // ==============================================================================================
  // *** Sets values related to the geometry.
  if( geometry == "S1" )
  {
    dim = 1.0;                                   // Sets the dimension of the metric space.
    radius = nb_vertices / (2 * Pi * delta); // Computes the radius of the sphere.
  }
  if( geometry == "S2" ) // Computes the radius of the sphere.
  {
    dim = 2.0;                                                // Sets the dimension of the metric space.
    radius = std::sqrt( nb_vertices / (4 * Pi * delta) ); // Computes the radius of the sphere.
  }

  // ==============================================================================================
  // *** Computes the moments of $\rho(\kappa,\sigma)$.
  mean_kappa = 0;
  mean_sigma = 0;
  for(unsigned int n(0); n<nb_vertices; ++n)
  {
    mean_kappa += kappa_sequence[n];
    mean_sigma += sigma_sequence[n];
    // mean_sigma += pdf_sigma_param[1] * std::pow(kappa_sequence[n], pdf_sigma_param[0]);
  }
  mean_kappa /= nb_vertices;
  mean_sigma /= nb_vertices;

  // // Computes the average value of kappa.
  // if( pdf_kappa_type == "pdf_powerlaw_hardcutoff" )
  // {
  //   // mean_kappa = ( ( pdf_kappa_param[0]-1 ) * pdf_kappa_param[1] ) / ( ( pdf_kappa_param[0]-2 ) );
  //   mean_kappa = ( ( pdf_kappa_param[0]-1 ) * pdf_kappa_param[1] * ( 1 - std::pow(pdf_kappa_param[2]/pdf_kappa_param[1],2-pdf_kappa_param[0]) ) ) / ( ( pdf_kappa_param[0]-2 ) * ( 1 - std::pow(pdf_kappa_param[2]/pdf_kappa_param[1],1-pdf_kappa_param[0]) ) );
  // }
  // // if( pdf_kappa_type == "pdf_powerlaw_expocutoff" )
  // // {
  // //   mean_kappa = pdf_kappa_param[2] * gsl_sf_gamma_inc(2.0-pdf_kappa_param[0], pdf_kappa_param[1]/pdf_kappa_param[2]) / gsl_sf_gamma_inc(1.0-pdf_kappa_param[0], pdf_kappa_param[1]/pdf_kappa_param[2]);
  // // }
  // if( pdf_kappa_type == "pdf_exponential" )
  // {
  //   mean_kappa = pdf_kappa_param[0];
  // }
  // // if( pdf_kappa_type == "pdf_exponential_bounded" ) IL MANQUERA QUELQUE AJOUT DANS LES AUTRES VARIABLES POUR POUVOIR UTILISER CETTE OPTION
  // // {
  // //   mean_kappa = pdf_kappa_param[0] + pdf_kappa_param[1] + ( (pdf_kappa_param[2]-pdf_kappa_param[1]) / (1.0 - std::exp((pdf_kappa_param[2]-pdf_kappa_param[1])/pdf_kappa_param[0])) );
  // // }
  // // Computes the average value of sigma.
  // if( pdf_sigma_type == "deterministic_scaling" || pdf_sigma_type == "deterministic_scaling_noised_gamma" )
  // {
  //   if( pdf_kappa_type == "pdf_powerlaw_hardcutoff" )
  //   {
  //     // mean_sigma = ( pdf_sigma_param[1] * ( pdf_kappa_param[0]-1 ) * std::pow(pdf_kappa_param[1],pdf_sigma_param[0]) ) / ( ( pdf_kappa_param[0]-pdf_sigma_param[0]-1 ) );
  //     mean_sigma = ( pdf_sigma_param[1] * ( pdf_kappa_param[0]-1 ) * std::pow(pdf_kappa_param[1],pdf_sigma_param[0]) * ( 1 - std::pow(pdf_kappa_param[2]/pdf_kappa_param[1],1+pdf_sigma_param[0]-pdf_kappa_param[0]) ) ) / ( ( pdf_kappa_param[0]-pdf_sigma_param[0]-1 ) * ( 1 - std::pow(pdf_kappa_param[2]/pdf_kappa_param[1],1-pdf_kappa_param[0]) ) );
  //   }
  //   // if( pdf_kappa_type == "pdf_powerlaw_expocutoff" )
  //   // {
  //   //   mean_sigma = pdf_sigma_param[1] * std::pow(pdf_kappa_param[2], pdf_sigma_param[0] ) * gsl_sf_gamma_inc(pdf_sigma_param[0]+1.0-pdf_kappa_param[0], pdf_kappa_param[2]/pdf_kappa_param[1]) / gsl_sf_gamma_inc(1.0-pdf_kappa_param[0], pdf_kappa_param[2]/pdf_kappa_param[1]);
  //   // }
  //   if( pdf_kappa_type == "pdf_exponential" )
  //   {
  //     mean_sigma = pdf_sigma_param[1] * std::pow(pdf_kappa_param[0],pdf_sigma_param[0]) * std::tgamma(pdf_sigma_param[0]+1.0);
  //   }
  // }

  // ==============================================================================================
  // *** Computes the integral.
  // Computes the integrals I_1 and I_3.
  if( prob_connection_type == "prob_FermiDirac" )
  {
    if( prob_connection_param[0] > dim )
      I_1 = (Pi/prob_connection_param[0]) / std::sin(dim * Pi / prob_connection_param[0]);
    if( std::fabs(dim-alpha) < 1e-12 )
      I_3 = std::log(nb_vertices);  // PEUT-ÊTRE AJOUTER DES FACTEURS DE PROPORTIONALITÉ QUAND LE CALCUL EXACT SERA FAIT.
    else if( prob_connection_param[0] > dim-alpha )
      I_3 = (Pi/prob_connection_param[0]) / std::sin( (dim-alpha) * Pi / prob_connection_param[0]);
  }
// std::cout<<I_3<<std::endl;
  // Computes the integral I_2.
  if( pdf_weights_type == "pdf_exponential" )
    I_2 = pdf_weights_param[0];
  if( pdf_weights_type == "pdf_exponential_bounded" )
    I_2 = pdf_weights_param[0] + pdf_weights_param[1] + ((pdf_weights_param[2]-pdf_weights_param[1])/(1.0 - std::exp((pdf_weights_param[2]-pdf_weights_param[1])/pdf_weights_param[0])));
  if( pdf_weights_type == "pdf_exponential_lowerbounded" )
    I_2 = pdf_weights_param[0] + pdf_weights_param[1];
  if( pdf_weights_type == "pdf_gamma" )
    I_2 = pdf_weights_param[0] * pdf_weights_param[1];
  if( pdf_weights_type == "pdf_delta" )
    I_2 = 1.0;
  // if( pdf_weights_type == "pdf_powerlaw_expocutoff" )
  //   I_2 = pdf_weights_param[3] * ( gsl_sf_gamma_inc(2.-pdf_weights_param[0], pdf_weights_param[1]/pdf_weights_param[3]) - gsl_sf_gamma_inc(2.-pdf_weights_param[0], pdf_weights_param[2]/pdf_weights_param[3]) ) / ( gsl_sf_gamma_inc(1.-pdf_weights_param[0], pdf_weights_param[1]/pdf_weights_param[3]) - gsl_sf_gamma_inc(1.-pdf_weights_param[0], pdf_weights_param[2]/pdf_weights_param[3]) );

  // ==============================================================================================
  // *** Computes the proportionality factors.
  // Computes the factor mu.
  mu = std::pow( ( std::tgamma(dim/2.) ) / ( 2 * std::pow(Pi,dim/2.) * delta * mean_kappa * I_1 ) , 1./dim);
  // Computes the factor nu.
  nu = ( std::tgamma(dim/2.) ) / ( 2 * std::pow(Pi,dim/2.) * delta * std::pow(mu,dim-alpha) * I_2 * mean_sigma * I_3 );
  // nu = 0.05;

  // ==============================================================================================
  // *** Creates the graph and its vertices.
  the_graph.resize( nb_vertices );

  // ==============================================================================================
  // *** Sets the position and the hidden variables of the vertices.
  for(int n(0); n<nb_vertices; ++n)
  {
    // Sets the position of the vertex in the metric space.
    if( geometry == "S1" )
    {
      // Computes the angular position.
      tmp_phi = 2 * Pi * uniform_01(_engine);
      // Sets the position.
      the_graph[n].set_metric_space_position( {radius,tmp_phi} );
    }
    if( geometry == "S2" )
    {
      // Computes the azimuthal angle.
      tmp_phi   = 2 * Pi * uniform_01(_engine);
      tmp_theta = std::acos( 2 * uniform_01(_engine) - 1 );
      // Sets the position.
      the_graph[n].set_metric_space_position( {radius,tmp_phi, tmp_theta} );
    }

    // Sets the value of the hidden variable kappa.
    tmp_kappa = kappa_sequence[n];
    // if( pdf_kappa_type == "pdf_powerlaw_hardcutoff" )
    //   tmp_kappa = pdf_powerlaw_hardcutoff(pdf_kappa_param, _engine);
    // if( pdf_kappa_type == "pdf_powerlaw_expocutoff" )
    //   tmp_kappa = pdf_powerlaw_expocutoff(pdf_kappa_param, _engine);
    // if( pdf_kappa_type == "pdf_exponential" )
    //   tmp_kappa = pdf_exponential(pdf_kappa_param[0], _engine);

    // Sets the value of the hidden variable sigma.
    tmp_sigma = sigma_sequence[n];
    // if( pdf_sigma_type == "deterministic_scaling" )
    //   tmp_sigma = pdf_sigma_param[1] * std::pow(tmp_kappa,pdf_sigma_param[0]);
    // if( pdf_sigma_type == "deterministic_scaling_noised_gamma" )
    //   tmp_sigma = pdf_gamma({pdf_sigma_param[1]*std::pow(tmp_kappa,pdf_sigma_param[0])/pdf_sigma_param[2],pdf_sigma_param[2]}, _engine);

    the_graph[n].set_hidden_variables( {tmp_kappa,tmp_sigma} );
  }

  // ==============================================================================================
  // *** Sets the connections between the vertices.
  for(int_t n1(0); n1<nb_vertices; ++n1)
  {
    // // Prints on screen the value of n1 (if the graph is large enough).
    // if(nb_vertices > 19999)
    //   std::cout << "\r"<< n1;
    // Gets the position of the first vertex.
    x1 = the_graph[n1].get_metric_space_position();
    //Gets the hidden variables of the first vertex.
    k1 = the_graph[n1].get_hidden_variables();

    for(int_t n2(n1+1); n2<nb_vertices; ++n2)
    {
      // Gets the position of the first vertex.
      x2 = the_graph[n2].get_metric_space_position();
      //Gets the hidden variables of the first vertex.
      k2 = the_graph[n2].get_hidden_variables();
      // Computes the distance between the two vertices.
      if(geometry == "S1")
        tmp_dist = distance_S1(radius,x1[1],x2[1]);
      if(geometry == "S2")
        tmp_dist = distance_S2(radius,x1[1],x1[2],x2[1],x2[2]);
      // Computes the "chi" factor.
      tmp_chi = tmp_dist / (mu * std::pow(k1[0] * k2[0],1./dim));
      // Computes the "w_c" factor.
      // tmp_w_c = (nu * k1[1] * k2[1]) / (std::pow(k1[0]*k2[0],1.-alpha/dim) * std::pow(tmp_dist,alpha));
      tmp_w_c = (nu * k1[1] * k2[1]);
      if(std::fabs(alpha-dim) < 1e-12)
        tmp_w_c /= std::pow(tmp_dist,alpha);
      else if(std::fabs(alpha) < 1e-12)
        tmp_w_c /= (k1[0]*k2[0]);
      else
        tmp_w_c = (nu * k1[1] * k2[1]) / (std::pow(k1[0]*k2[0],1.-alpha/dim) * std::pow(tmp_dist,alpha));
      // Computes the probability of connection.
      if( prob_connection_type == "prob_FermiDirac" )
        tmp_r = 1. / (std::pow(tmp_chi,prob_connection_param[0]) + 1);
      // Creates the edge, if any.
      if( uniform_01(_engine) < tmp_r )
      {
        // Computes the weight of the edge.
        if( pdf_weights_type == "pdf_exponential" )
          tmp_w = tmp_w_c * pdf_exponential(pdf_weights_param[0], _engine);
        if( pdf_weights_type == "pdf_exponential_bounded" )
          tmp_w = tmp_w_c * pdf_exponential_bounded(pdf_weights_param, _engine);
        if( pdf_weights_type == "pdf_exponential_lowerbounded" )
          tmp_w = tmp_w_c * (pdf_exponential(pdf_weights_param[0], _engine)) + pdf_weights_param[1];
        if( pdf_weights_type == "pdf_gamma" )
          tmp_w = tmp_w_c * pdf_gamma(pdf_weights_param, _engine);
        if( pdf_weights_type == "pdf_delta" )
          tmp_w = tmp_w_c;
        // if( pdf_weights_type == "pdf_powerlaw_expocutoff")
        //   tmp_w = tmp_w_c * pdf_powerlaw_expocutoff(pdf_weights_param, _engine);
        // Creates the edge
        the_graph[n1].neighbour_insert(n2,tmp_w);
        the_graph[n2].neighbour_insert(n1,tmp_w);
      }
// std::cout<<n1<<"  "<<n2<<std::endl;
    }
  }
  // // Prints on screen the value of n1 (if the graph is large enough).
  // if(nb_vertices > 19999)
  //   std::cout<<std::endl;
  // // Computes properties.
  // find_highest_degree_value();
  // find_highest_strength_value();
  // compute_disparity();
  // compute_average_degree();
  // compute_average_strength();
  // compute_degree_distribution();
}


double hyperbolic_graph::pdf_powerlaw_hardcutoff(std::vector<double> &param, std::mt19937& _engine)
{
  return param[1] * std::pow(1-( uniform_01(_engine) * (1-std::pow(param[2]/param[1],(1.-param[0])))),-1./(param[0]-1));
}

double hyperbolic_graph::pdf_powerlaw_expocutoff(std::vector<double> &param, std::mt19937& _engine)
{
  double value = param[1] * std::pow( (1.0-uniform_01(_engine)), (-1.0/(param[0]-1.0)) );
  while(uniform_01(_engine) > std::exp((param[1]-value)/param[2]))
    value = param[1] * std::pow( (1.0-uniform_01(_engine)), (-1.0/(param[0]-1.0)) );
  return value;
  // double value = pdf_exponential(param[2], _engine);
  // while( uniform_01(_engine) > std::pow(value, param[0]) )
  //   value = pdf_exponential(param[2], _engine);
  // return value;
  // double value = pdf_powerlaw_hardcutoff(param, _engine);
  // while( uniform_01(_engine) > std::exp(-1.0*value / param[3]) )
  //   value = pdf_powerlaw_hardcutoff(param, _engine);
  // return value;
}


double hyperbolic_graph::pdf_exponential(double param, std::mt19937& _engine)
{
  return -param * std::log(1-uniform_01(_engine));
}


double hyperbolic_graph::pdf_exponential_lowerbounded(std::vector<double> param, std::mt19937& _engine)
{
  return -param[0] * std::log(1-uniform_01(_engine)) + param[1];
}

double hyperbolic_graph::pdf_exponential_bounded(std::vector<double> param, std::mt19937& _engine)
{
  return -param[0] * std::log(1.0-uniform_01(_engine)*(1.0-std::exp(-(param[2]-param[1])/param[0]))) + param[1];
}

double hyperbolic_graph::pdf_gamma(std::vector<double> param, std::mt19937& _engine)
{
  std::gamma_distribution<double> gamma(param[0],param[1]);
  return gamma(_engine);
}

// double hyperbolic_graph::pdf_gamma(std::vector<double> param, std::mt19937& _engine)
// {
//   std::normal_distribution<double> normal_01(0.0,1.0);
//   double d = param[0] - 1./3.;
//   double lhs = 5.;
//   double rhs = 1.;
//   double x,v;
//   while( lhs > rhs )
//   {
//     lhs = std::log( uniform_01(_engine) );
//     x = normal_01(_engine);
//     v = std::pow(1+x/(std::sqrt(9.*d)),3);
//     rhs = std::pow(x,2)/2. + d - d*v + d*std::log(v);
//   }
//   return param[1]*d*v;
// }


double hyperbolic_graph::distance_S1(double R, double phi1, double phi2)
{
  return R * ( Pi - std::fabs( Pi - std::fabs( phi1 - phi2 ) ) );
}


double hyperbolic_graph::distance_S2(double R, double lambda1, double phi1, double lambda2, double phi2)
{
  return R * std::acos( ( std::cos(phi1) * std::cos(phi2) ) + ( std::sin(phi1) * std::sin(phi2) * std::cos(lambda1 - lambda2) ) );
}


// void hyperbolic_graph::build_wS1_two_hidden_variables(int_t _nb_vertices, dbl_t _gamma_kappa, dbl_t _kappa_zero, dbl_t _kappa_coff, dbl_t _mu, dbl_t _nu, dbl_t _alpha, dbl_t _beta, std::mt19937& _engine)
// {
//   // Indicates the information on the graph.
//   type_of_graph = "weighted_S1_two_hidden_variables_strongly_correlated";
//   nb_vertices  = _nb_vertices;
//   gamma_kappa  = _gamma_kappa;
//   kappa_zero   = _kappa_zero;
//   kappa_coff   = _kappa_coff;
//   mu = _mu;
//   nu = _nu;
//   alpha = _alpha;
//   beta = _beta;
//   // Computes the radius of the hyperbolic space (density equal to 1).
//   R = nb_vertices / (2 * Pi);
//   // Creates the graph and its vertices.
//   the_graph.resize( nb_vertices );

//   // Sets the "characteristics" of the vertices.
//   dbl_t tmp_kappa;
//   // dbl_t kappa_coff = kappa_zero*std::pow(nb_vertices,1./(gamma_kappa-1));
//   for(int_t n(0); n<nb_vertices; ++n)
//   {
//     // Sets the radial position of vertex "n" (on the circle of radius R).
//     the_graph[n].set_radial_pos( R );
//     // Sets the angular position of vertex "n" (uniformly distributed on the circle).
//     the_graph[n].set_angular_pos( 2*Pi*uniform_01(_engine) );
//     // Sets the number of non-geometrical hidden variabless.
//     the_graph[n].set_nb_nongeo_hidden_var( 2 );
//     // Sets the value of the non-geometrical hidden variables.
//     // tmp_kappa = gen_cont_powerlaw_var(gamma_kappa, kappa_zero, _engine);
//     tmp_kappa = gen_cont_powerlaw_var_with_hard_cutoff(gamma_kappa, kappa_zero, kappa_coff, _engine);
//     the_graph[n].set_nongeo_hidden_var( 0, tmp_kappa );
//     the_graph[n].set_nongeo_hidden_var( 1, std::pow(tmp_kappa,alpha) );
//   }

//   // Sets the connections between the vertices.
//   // Temporary variables.
//   dbl_t t1, t2, k1, k2, l1, l2, dtheta, chi, w, w_c, r;
//   for(int_t n1(0); n1<nb_vertices; ++n1)
//   {
//     // Gets the angular position of the first vertex.
//     t1 = the_graph[n1].get_angular_pos();
//     // Gets the value of the non-geometrical hidden variables of the first vertex.
//     k1 = the_graph[n1].get_nongeo_hidden_var( 0 );
//     l1 = the_graph[n1].get_nongeo_hidden_var( 1 );

//     for(int_t n2(n1+1); n2<nb_vertices; ++n2)
//     {
//       // Gets the angular position of the second vertex.
//       t2 = the_graph[n2].get_angular_pos();
//       // Gets the value of the non-geometrical hidden variables of the second vertex.
//       k2 = the_graph[n2].get_nongeo_hidden_var( 0 );
//       l2 = the_graph[n2].get_nongeo_hidden_var( 1 );
      
//       // Computes the distance between the two vertices.
//       dtheta = Pi - std::fabs( Pi - std::fabs( t1-t2 ) );
//       // Computes the "chi" and "phi" factors.
//       chi = (nb_vertices * dtheta) / (2 * Pi * mu * k1 * k2);
//       w_c = (2 * Pi * nu * l1 * l2) / (nb_vertices * dtheta);
//       // Computes the probability of connection.
//       r = 1. / (std::pow(chi,beta) + 1);
//  // std::cout<<n1<<"  "<<n2<<"  "<<dtheta<<"  "<<chi<<"  "<<w_c<<"  "<<r;
//       // Creates the edge, if any.
//       if( uniform_01(_engine) < r )
//       {
//         // Computes the weight if the edge.
//         w = gen_cont_expo_var(w_c, _engine);
//  // std::cout<<"  "<<w<<std::endl;
//         // Creates the edge
//         the_graph[n1].neighbour_insert(n2,w);
//         the_graph[n2].neighbour_insert(n1,w);
//       }
//  // else std::cout<<std::endl;
//     }
//   }
//   // Computes properties.
//   find_highest_degree_value();
//   find_highest_strength_value();
//   compute_disparity();
//   compute_average_degree();
//   compute_degree_distribution();
// }


// void hyperbolic_graph::build_S1(int_t _nb_vertices, dbl_t _gamma, dbl_t _kappa_zero, dbl_t _mu, dbl_t _alpha, std::mt19937& _engine)
// {
//   // Indicates the information on the graph.
//   type_of_graph = "S1_Serrano_PRL_2008";
//   nb_vertices = _nb_vertices;
//   gamma_kappa = _gamma;
//   kappa_zero = _kappa_zero;
//   mu = _mu;
//   alpha = _alpha;
//   // Computes the radius of the hyperbolic space (density equal to 1).
//   R = nb_vertices / (2 * Pi);
//   // Creates the graph and its vertices.
//   the_graph.resize( nb_vertices );

//   // Sets the "characteristics" of the vertices.
//   for(int_t n(0); n<nb_vertices; ++n)
//   {
//     // Sets the radial position of vertex "n" (on the circle of radius R).
//     the_graph[n].set_radial_pos( R );
//     // Sets the angular position of vertex "n" (uniformly distributed on the circle).
//     the_graph[n].set_angular_pos( 2*Pi*uniform_01(_engine) );
//     // Sets the number of non-geometrical hidden variabless.
//     the_graph[n].set_nb_nongeo_hidden_var( 1 );
//     // Sets the value of the non-geometrical hidden variable.
//     the_graph[n].set_nongeo_hidden_var( 0, kappa_zero * std::pow(1-uniform_01(_engine),-1./(gamma_kappa-1)) );
//   }

//   // Sets the connections between the vertices.

//   // Temporary variables.
//   dbl_t t1, t2, k1, k2, dtheta, chi, r;
  
//   for(int_t n1(0); n1<nb_vertices; ++n1)
//   {
//     // Gets the angular position of the first vertex.
//     t1 = the_graph[n1].get_angular_pos();
//     // Gets the value of the non-geometrical hidden variable of the first vertex.
//     k1 = the_graph[n1].get_nongeo_hidden_var( 0 );

//     for(int_t n2(n1+1); n2<nb_vertices; ++n2)
//     {
//       // Gets the angular position of the second vertex.
//       t2 = the_graph[n2].get_angular_pos();
//       // Gets the value of the non-geometrical hidden variable of the second vertex.
//       k2 = the_graph[n2].get_nongeo_hidden_var( 0 );
      
//       // Computes the distance between the two vertices.
//       dtheta = Pi - std::fabs( Pi - std::fabs( t1-t2 ) );
//       // Computes the "chi" factor.
//       chi = (nb_vertices * dtheta) / (2 * Pi * mu * k1 * k2);
//       // Computes the probability of connection.
//       r = std::pow(1+chi,-alpha);
//       // Creates the edge, if any
//       if( uniform_01(_engine) < r )
//       {
//         the_graph[n1].neighbour_insert(n2,1);
//         the_graph[n2].neighbour_insert(n1,1);
//       }
//     }
//   }
// }


// hyperbolic_graph::dbl_t hyperbolic_graph::gen_cont_powerlaw_var(dbl_t _gamma, dbl_t _kappa_zero, std::mt19937& _engine)
// {
//   return _kappa_zero * std::pow(1-uniform_01(_engine),-1./(_gamma-1));
// }


// hyperbolic_graph::dbl_t hyperbolic_graph::gen_cont_powerlaw_var_with_hard_cutoff(dbl_t _gamma, dbl_t _kappa_zero, dbl_t _kappa_max, std::mt19937& _engine)
// {
//   return _kappa_zero * std::pow(1-( uniform_01(_engine)*(1-std::pow(_kappa_max/_kappa_zero,(1.-_gamma)))),-1./(_gamma-1));
// }


// hyperbolic_graph::dbl_t hyperbolic_graph::gen_cont_expo_var(dbl_t _w_c, std::mt19937& _engine)
// {
//   return -_w_c * std::log(1-uniform_01(_engine));
// }


// void hyperbolic_graph::build_S1_BE(int_t _nb_vertices, dbl_t _gamma, dbl_t _kappa_zero, dbl_t _mu, dbl_t _alpha, dbl_t _beta, std::mt19937& _engine)
// {
//   // Indicates the information on the graph.
//   type_of_graph = "S1_BE";
//   nb_vertices = _nb_vertices;
//   gamma_kappa = _gamma;
//   kappa_zero = _kappa_zero;
//   mu = _mu;
//   alpha = _alpha;
//   beta = _beta;
//   // Computes the radius of the hyperbolic space (density equal to 1).
//   R = nb_vertices / (2 * Pi);
//   // Creates the graph and its vertices.
//   the_graph.resize( nb_vertices );

//   // Sets the "characteristics" of the vertices.
//   for(int_t n(0); n<nb_vertices; ++n)
//   {
//     // Sets the radial position of vertex "n" (on the circle of radius R).
//     the_graph[n].set_radial_pos( R );
//     // Sets the angular position of vertex "n" (uniformly distributed on the circle).
//     the_graph[n].set_angular_pos( 2*Pi*uniform_01(_engine) );
//     // Sets the number of non-geometrical hidden variabless.
//     the_graph[n].set_nb_nongeo_hidden_var( 1 );
//     // Sets the value of the non-geometrical hidden variable.
//     the_graph[n].set_nongeo_hidden_var( 0, kappa_zero * std::pow(1-uniform_01(_engine),-1./(gamma_kappa-1)) );
//   }

//   // Sets the connections between the vertices.

//   // Temporary variables.
//   int_t w;
//   dbl_t t1, t2, k1, k2, dtheta, chi, f_of_chi;
  
//   for(int_t n1(0); n1<nb_vertices; ++n1)
//   {
//     // Gets the angular position of the first vertex.
//     t1 = the_graph[n1].get_angular_pos();
//     // Gets the value of the non-geometrical hidden variable of the first vertex.
//     k1 = the_graph[n1].get_nongeo_hidden_var( 0 );

//     for(int_t n2(n1+1); n2<nb_vertices; ++n2)
//     {
//       // Gets the angular position of the second vertex.
//       t2 = the_graph[n2].get_angular_pos();
//       // Gets the value of the non-geometrical hidden variable of the second vertex.
//       k2 = the_graph[n2].get_nongeo_hidden_var( 0 );
      
//       // Computes the distance between the two vertices.
//       dtheta = Pi - std::fabs( Pi - std::fabs( t1-t2 ) );
//       // Computes the "chi" factor.
//       chi = (nb_vertices * dtheta) / (2 * Pi * mu * k1 * k2);
//       // Computes "f(chi)"
//       // f_of_chi = 0.999*std::exp( -chi );
//       f_of_chi = std::exp(-alpha-beta*chi);
//       // Computes the weight of the edge
//       w = std::floor( std::log(1-uniform_01(_engine)) / std::log(f_of_chi) );
//       // Creates the edge, if any
//       if( w>0 )
//       {
//         the_graph[n1].neighbour_insert(n2,w);
//         the_graph[n2].neighbour_insert(n1,w);
//       }
//     }
//   }
// }


// void hyperbolic_graph::export_graph(std::string _name)
// {
//   //
//   export_vertices_properties(_name);
//   //
//   export_edge_list(_name);
//   //
//   export_graph_properties(_name);
// }


void hyperbolic_graph::export_vertices_properties(std::string _name, std::string type_ios_base = "out")
{
  // filename and stream
  std::ofstream output_file;
  std::string filename = _name + "_vertices_properties.dat";

  // Writes the properties of each vertex into the file.
  if( type_ios_base == "out" )
    output_file.open(filename.c_str(), std::ios_base::out);
  else if( type_ios_base == "app" )
    output_file.open(filename.c_str(), std::ios_base::app);
  output_file.precision(8);
  for(int_t n(0); n<nb_vertices; ++n)
  {
    if( geometry == "S1" )
    {
      output_file<<std::fixed<<the_graph[n].get_metric_space_position(0)<<"  ";
      output_file<<std::fixed<<the_graph[n].get_metric_space_position(1)<<"  ";
      output_file<<std::fixed<<the_graph[n].get_hidden_variables(0)     <<"  ";
      output_file<<std::fixed<<the_graph[n].get_hidden_variables(1)     <<"  ";
    }
    if( geometry == "S2" )
    {
      output_file<<std::fixed<<the_graph[n].get_metric_space_position(0)<<"  ";
      output_file<<std::fixed<<the_graph[n].get_metric_space_position(1)<<"  ";
      output_file<<std::fixed<<the_graph[n].get_metric_space_position(2)<<"  ";
      output_file<<std::fixed<<the_graph[n].get_hidden_variables(0)     <<"  ";
      output_file<<std::fixed<<the_graph[n].get_hidden_variables(1)     <<"  ";
    }
    output_file<<std::fixed<<the_graph[n].get_degree()<<"  ";
    output_file<<std::fixed<<the_graph[n].get_strength()<<"  ";
    output_file<<std::fixed<<the_graph[n].get_disparity()<<"  ";
    output_file<<std::fixed<<the_graph[n].get_binary_average_degree_of_neighbours()<<"  ";
    output_file<<std::fixed<<the_graph[n].get_weighted_average_degree_of_neighbours()<<"  ";
    output_file<<std::fixed<<the_graph[n].get_nonstructural_weighted_average_degree_of_neighbours()<<"  ";
    output_file<<std::fixed<<the_graph[n].get_binary_clustering_coefficient()<<"  ";
    std::vector<double> wci = the_graph[n].get_weighted_clustering_coefficients();
    for(int i(0); i<wci.size(); ++i)
      output_file<<std::fixed<<wci[i]<<"  ";
    output_file<<std::fixed<<the_graph[n].get_nonstructural_weighted_clustering_coefficient();
    output_file<<std::endl;
  }
  output_file.close();
}


void hyperbolic_graph::export_edge_list(std::string _name, std::string type_ios_base = "out")
{
  // filename and stream
  std::ofstream output_file;
  std::string filename = _name + ".edge";

  // Writes each edges in the format "n1 n2 w". Each edge appear once.
  if( type_ios_base == "out" )
    output_file.open(filename.c_str(), std::ios_base::out);
  else if( type_ios_base == "app" )
    output_file.open(filename.c_str(), std::ios_base::app);
  hyperbolic_vertex::iterator it, end;
  unsigned int n2;
  for(unsigned int n1(0); n1<nb_vertices; ++n1)
  {
    it  = the_graph[n1].neighbour_begin();
    end = the_graph[n1].neighbour_end();
    for(; it!=end; ++it)
    {
      n2 = it->first;
      if(n1<=n2)
        output_file<<n1<<"  "<<n2<<"  "<<it->second<<std::endl;
    }
  }
  output_file.close();
}


void hyperbolic_graph::export_graph_properties(std::string _name)
{

  // Gets the current date/time.
  time_t theTime = time(NULL);
  struct tm *aTime = gmtime(&theTime);
  int year    = aTime->tm_year + 1900;
  int month   = aTime->tm_mon + 1;
  int day     = aTime->tm_mday;
  int hours   = aTime->tm_hour;
  int minutes = aTime->tm_min;

  // Filename and stream.
  std::ofstream output_file;
  std::string filename = _name + "_graph_properties.dat";

  // Opens the stream.
  output_file.open(filename.c_str(), std::ios_base::out);

  // Writes properties common to every models.
  output_file << "==================================================================================="  << std::endl;
  output_file << "type of graph:  "          << type_of_graph                                           << std::endl;
  output_file << "filename:       "          << _name                                                   << std::endl;
  output_file << "created:        "          << year << "/";
  if(month < 10)
    output_file << "0";
  output_file << month << "/";
  if(day < 10)
    output_file << "0";
  output_file << day << " " << hours << ":";
  if(minutes < 10)
    output_file << "0";
  output_file << minutes << " UTC"                                                                      << std::endl;
  output_file << "==================================================================================="  << std::endl;
  output_file << "Input parameters"                                                                     << std::endl;
  output_file << "number of vertices:     "     << nb_vertices                                          << std::endl;
  output_file << "geometry:               "     << geometry                                             << std::endl;
  output_file << "delta:                  "     << delta                                                << std::endl;
  output_file << "alpha:                  "     << alpha                                                << std::endl;
  if(pdf_kappa_type == "pdf_powerlaw_hardcutoff")
  {
    output_file << "PDF kappa:              power law with hard cut-off"                                << std::endl;
    output_file << "  - gamma:              "   << pdf_kappa_param[0]                                   << std::endl;
    output_file << "  - kappa min.:         "   << pdf_kappa_param[1]                                   << std::endl;
    output_file << "  - kappa max.:         "   << pdf_kappa_param[2]                                   << std::endl;
  }
  if(pdf_kappa_type == "pdf_powerlaw_expocutoff")
  {
    output_file << "PDF kappa:              power law with expo cut-off"                                << std::endl;
    output_file << "  - gamma:              "   << pdf_kappa_param[0]                                   << std::endl;
    output_file << "  - kappa min.:         "   << pdf_kappa_param[1]                                   << std::endl;
    output_file << "  - cut-off:            "   << pdf_kappa_param[2]                                   << std::endl;
  }
  if(pdf_kappa_type == "pdf_exponential")
  {
    output_file << "PDF kappa:              exponential"                                                << std::endl;
    output_file << "  - scale parameter:    "   << pdf_kappa_param[0]                                   << std::endl;
  }
  if(pdf_sigma_type == "deterministic_scaling")
  {
    output_file << "PDF sigma:              deterministic scaling"                                      << std::endl;
    output_file << "  - eta:                "   << pdf_sigma_param[0]                                   << std::endl;
    output_file << "  - prop. constant:     "   << pdf_sigma_param[1]                                   << std::endl;
  }
  if(pdf_sigma_type == "deterministic_scaling_noised_gamma")
  {
    output_file << "PDF sigma:              gamma distribution with average scaling deterministically"  << std::endl;
    output_file << "  - eta:                "   << pdf_sigma_param[0]                                   << std::endl;
    output_file << "  - prop. constant:     "   << pdf_sigma_param[1]                                   << std::endl;
    output_file << "  - scale parameter:    "   << pdf_sigma_param[2]                                   << std::endl;
  }
  if(prob_connection_type == "prob_FermiDirac")
  {
    output_file << "Prob. of connection:    Fermi-Dirac"                                                << std::endl;
    output_file << "  - beta:               "   << prob_connection_param[0]                             << std::endl;
  }
  if(pdf_weights_type == "pdf_exponential")
  {
    output_file << "PDF weights:            exponential"                                                << std::endl;
    output_file << "  - scale parameter:    "   << pdf_weights_param[0]                                 << std::endl;
  }
  if(pdf_weights_type == "pdf_exponential_lowerbounded")
  {
    output_file << "PDF weights:            bounded exponential"                                        << std::endl;
    output_file << "  - scale parameter:    "   << pdf_weights_param[0]                                 << std::endl;
    output_file << "  - lower bound:        "   << pdf_weights_param[1]                                 << std::endl;
  }
  if(pdf_weights_type == "pdf_exponential_bounded")
  {
    output_file << "PDF weights:            bounded exponential"                                        << std::endl;
    output_file << "  - scale parameter:    "   << pdf_weights_param[0]                                 << std::endl;
    output_file << "  - lower bound:        "   << pdf_weights_param[1]                                 << std::endl;
    output_file << "  - upper bound:        "   << pdf_weights_param[2]                                 << std::endl;
  }
  if(pdf_weights_type == "pdf_gamma")
  {
    output_file << "PDF weights:            gamma"                                                      << std::endl;
    output_file << "  - shape parameter:    "   << pdf_weights_param[0]                                 << std::endl;
    output_file << "  - scale parameter:    "   << pdf_weights_param[1]                                 << std::endl;
  }
  if(pdf_weights_type == "pdf_delta")
  {
    output_file << "PDF weights:            delta"                                                      << std::endl;
  }
  output_file << "==================================================================================="  << std::endl;
  output_file << "Theoretical values"                                                                   << std::endl;
  output_file << "mean kappa:         "              << mean_kappa                                      << std::endl;
  output_file << "mean sigma:         "              << mean_sigma                                      << std::endl;
  output_file << "mu:                 "              << mu                                              << std::endl;
  output_file << "nu:                 "              << nu                                              << std::endl;
  output_file << "==================================================================================="  << std::endl;
  output_file << "Observables"                                                                          << std::endl;
  output_file << "minimum non-zero degree:         " << k_min                                           << std::endl;
  output_file << "maximum degree:                  " << k_max                                           << std::endl;
  output_file << "average degree:                  " << k_avg                                           << std::endl;
  output_file << "number of zero-degree vertices:  " << nb_vertices_zerodegree                          << std::endl;
  output_file << "minimum non-zero strength:       " << s_min                                           << std::endl;
  output_file << "maximum strength:                " << s_max                                           << std::endl;
  output_file << "average strength:                " << s_avg                                           << std::endl;
  output_file << "2nd moment strength:             " << s_2mt                                           << std::endl;
  output_file << "2eta-1 moment strength:          " << s_2etaminus1                                    << std::endl;
  output_file << "variance strength:               " << s_var                                           << std::endl;
  output_file << "minimum non-zero weight:         " << w_min                                           << std::endl;
  output_file << "maximum weight:                  " << w_max                                           << std::endl;
  output_file << "average weight:                  " << w_avg                                           << std::endl;
  output_file << "minimum kappa:                   " << kappa_min                                       << std::endl;
  output_file << "maximum kappa:                   " << kappa_max                                       << std::endl;
  output_file << "average kappa:                   " << kappa_avg                                       << std::endl;
  output_file << "minimum sigma:                   " << sigma_min                                       << std::endl;
  output_file << "maximum sigma:                   " << sigma_max                                       << std::endl;
  output_file << "average sigma:                   " << sigma_avg                                       << std::endl;

  // Closes the stream.
  output_file.close();
}


void hyperbolic_graph::export_extended_edge_list(std::string _name)
{
  // filename and stream
  std::ofstream output1_file, output2_file;
  std::string filename1 = _name + "_prob_connection.dat";
  std::string filename2 = _name + "_pdf_weights.dat";

  // Open the stream.
  output1_file.open(filename1.c_str(), std::ios_base::out);
  output2_file.open(filename2.c_str(), std::ios_base::out);
  // Distance between nodes.
  double distance;
  // Makes the calculations and write the results into the file.
  hyperbolic_vertex::iterator it, end;
  for(unsigned int n(0); n<nb_vertices; ++n)
  {
    // if( the_graph[n].get_degree() > 0 )
    // {
      // Gets the iterators to browse the neighbours of vertex "n".
      it  = the_graph[n].neighbour_begin();
      end = the_graph[n].neighbour_end();
      for(unsigned int v(0); v<nb_vertices; ++v)
      {

        if(v == it->first)
        {

          if(v>n)
          {

            // Computes the distance between the nodes.
            if(geometry == "S1")
              distance = distance_S1(the_graph[n].get_metric_space_position(0),the_graph[n].get_metric_space_position(1),the_graph[v].get_metric_space_position(1));
            if(geometry == "S2")
              distance = distance_S2(the_graph[n].get_metric_space_position(0),the_graph[n].get_metric_space_position(1),the_graph[n].get_metric_space_position(2),the_graph[v].get_metric_space_position(1),the_graph[v].get_metric_space_position(2));

            // *** Connection probability.
            // Vertex 1: id and degree.
            output1_file << n << "  " << the_graph[n].get_degree() << "  ";
            // Vertex 2: id and degree.
            output1_file << v << "  " << the_graph[v].get_degree() << "  ";
            // Distance between the two vertices.
            output1_file << distance << "  ";
            // Indicates that there exists an edge between the two vertices.
            output1_file << 1 << "  ";
            // Writes the hidden variables
            output1_file << the_graph[n].get_hidden_variables(0) << "  ";
            output1_file << the_graph[v].get_hidden_variables(0) << std::endl;

            // *** Weights density.
            // Vertex 1: id and strength.
            output2_file << n << "  " << the_graph[n].get_degree() << "  " << the_graph[n].get_strength() << "  ";
            // Vertex 2: id and strength.
            output2_file << v << "  " << the_graph[v].get_degree() << "  " << the_graph[v].get_strength() << "  ";
            // Distance between the two vertices.
            output2_file << distance << "  ";
            // Weight of the edge between the two vertices.
            output2_file << it->second << "  ";
            // Writes the hidden variables
            output2_file << the_graph[n].get_hidden_variables(0) << "  ";
            output2_file << the_graph[v].get_hidden_variables(0) << "  ";
            output2_file << the_graph[n].get_hidden_variables(1) << "  ";
            output2_file << the_graph[v].get_hidden_variables(1) << std::endl;
          }
          
          ++it;
        }
        else
        {
          if(v>n)
          {

            // Computes the distance between the nodes.
            if(geometry == "S1")
              distance = distance_S1(the_graph[n].get_metric_space_position(0),the_graph[n].get_metric_space_position(1),the_graph[v].get_metric_space_position(1));
            if(geometry == "S2")
              distance = distance_S2(the_graph[n].get_metric_space_position(0),the_graph[n].get_metric_space_position(1),the_graph[n].get_metric_space_position(2),the_graph[v].get_metric_space_position(1),the_graph[v].get_metric_space_position(2));

            // *** Connection probability.
            // Vertex 1: id and degree.
            output1_file << n << "  " << the_graph[n].get_degree() << "  ";
            // Vertex 2: id and degree.
            output1_file << v << "  " << the_graph[v].get_degree() << "  ";
            // Distance between the two vertices.
            output1_file << distance << "  ";
            // Indicates that there does not exist an edge between the two vertices.
            output1_file << 0 << "  ";
            // Writes the hidden variables
            output1_file << the_graph[n].get_hidden_variables(0) << "  ";
            output1_file << the_graph[v].get_hidden_variables(0) << std::endl;
          }
        }
      }
    // }
  }
  // Closes the streams.
  output1_file.close();
  output2_file.close();
}



#endif // HYPERBOLIC_GRAPH_HPP_INCLUDED