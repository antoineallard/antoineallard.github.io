// ================================================================================================
//
// author:  Antoine Allard
// email:   antoine.allard.1@gmail.com 
// www:     antoineallard.info
//
// last updated: Mar. 31th, 2016
//
// To compile: g++ -O3 -std=c++1y src/extract_graph_properties.cpp -o extract_graph_properties
//
// ================================================================================================


// Standard Template Library
#include <cstdlib>       // std::terminate, std::atoi
#include <fstream>       // std::ofstream
#include <iostream>      // std::cerr
#include <limits>        // std::numeric_limits
#include <string>        // std::string
#include <tuple>         // std::tie
#include <utility>       // std::pair, std::make_pair
#include <vector>        // std::vector
// not BGL
#include "notbgl.hpp"


int main(int argc, char *argv[])
{
  // ==============================================================================================
  // *** Initializes the graph object.
  typedef boost::adjacency_list<boost::listS,
                                boost::vecS,
                                boost::undirectedS,
                                notbgl::MinimalWeightedVertexProp,
                                boost::property<boost::edge_weight_t, double> > graph_t;
  graph_t g;

  // ==============================================================================================
  // *** Loads the graph from its edgelist.
  // Basename of the graph.
  std::string name = argv[1];
  std::string ext = "";
  if(argc > 2)
    ext = argv[2];
  name = "networks/" + name + "/original_graph/" + name + ext;
  // Loads the graph from its edgelist.
  notbgl::load_weighted_edgelist(name + ".edge", g);
  

  // ==============================================================================================
  // *** Saves information about the graph.
  // Saves a copy of the edgelist.
  // notbgl::save_weighted_edgelist(name + ".edge2", g);
  // Writes the degree sequence.
  // notbgl::save_degree_sequence(name + "_degree_seq.dat", g);
  // notbgl::save_strength_sequence(name + "_strength_seq.dat", g);
  auto triangles = notbgl::survey_triangles(g);
  auto clustering = notbgl::get_local_clustering_coefficient(triangles, g);
  // notbgl::save_local_clustering_coefficents_sequence(name + "_local_clust_coeff_seq.dat", clustering, g);
  auto disparity = notbgl::disparity(g);
  notbgl::save_vertices_properties(name + "_vertices_prop.dat", g, clustering, disparity);





  // // ==============================================================================================
  // // *** Loads the position of the vertices.
  // // Number of dimensions.
  // unsigned int nb_dim = 3;
  // if(argc == 3)
  // {
  //   nb_dim = std::atoi(argv[2]);
  // }
  // // Loads the position of the vertices.
  // auto Vertex2Position = notbgl::load_positions(name + ".coord", g, Name2Vertex, nb_dim);

  // // ==============================================================================================
  // // *** Defines objects related to the graph object.
  // // Number of vertices.
  // auto nb_vertices(boost::num_vertices(g));
  // // External property object related to the weight of edges.
  // boost::property_map<graph_t,
  //                     boost::edge_weight_t>::type edge_weight = get(boost::edge_weight, g);
  // // Iterator objects related to edges.
  // boost::graph_traits<graph_t>::edge_iterator e, e_end;


  // // ==============================================================================================
  // // *** Topological length of every shortest paths.

  // // Sets the weight of edges to the topological distance between neighbors (i.e., to 1).
  // for(std::tie(e, e_end) = boost::edges(g); e != e_end; ++e)
  // {
  //   edge_weight[*e] = 1;
  // }

  // // Computes the length of every shortest paths.
  // boost::multi_array<double,2> topo_length_shortest_path(boost::extents[nb_vertices][nb_vertices]);
  // boost::johnson_all_pairs_shortest_paths(g, topo_length_shortest_path);

  // // Compiles the distribution of the topological length of existing shortest paths.
  // std::vector<unsigned int> dist_topo_length_shortest_paths(nb_vertices, 0);
  // for(unsigned int i(0); i<nb_vertices; ++i)
  // {
  //   for(unsigned int j(i); j<nb_vertices; ++j)
  //   {
  //     if(topo_length_shortest_path[i][j] < nb_vertices) // excludes non-existing paths
  //     {
  //       dist_topo_length_shortest_paths[topo_length_shortest_path[i][j]] += 1;
  //     }
  //   }
  // }

  // // File stream for the distribution of the topological length of the shortest paths.
  // std::ofstream dist_topo_length_shortest_paths_file(name + "_sptldist.dat", std::ios_base::out);
  // if( !dist_topo_length_shortest_paths_file.is_open() )
  // {
  //   std::cerr << "Could not open file: " << name << "_sptldist.dat" << std::endl;
  //   std::terminate();
  // }

  // // Writes the distribution into the file.
  // unsigned int l = 0;
  // for(auto d : dist_topo_length_shortest_paths)
  // {
  //   if(d > 0)
  //   {
  //     dist_topo_length_shortest_paths_file << l << " " << d << std::endl;
  //   }
  //   ++l;
  // }

  // // Clears the distribution of the topological length of the shortest paths.
  // dist_topo_length_shortest_paths.clear();

  // // Closes the stream.
  // dist_topo_length_shortest_paths_file.close();


  // // ==============================================================================================
  // // *** Geometrical length of every shortest paths.

  // // Sets the weight of edges to the geometrical distance between neighbors.
  // for(std::tie(e, e_end) = boost::edges(g); e != e_end; ++e)
  // {
  //   auto v1 = boost::source(*e, g);
  //   auto v2 = boost::target(*e, g);
  //   edge_weight[*e] = notbgl::euclidean_distance(Vertex2Position[v1], Vertex2Position[v2]);;
  // }

  // // Computes the geometrical length of every shortest paths.
  // boost::multi_array<double,2> geo_length_shortest_path(boost::extents[nb_vertices][nb_vertices]);
  // boost::johnson_all_pairs_shortest_paths(g, geo_length_shortest_path);

  // // File stream for the sequence of the geometric length of the shortest paths.
  // std::ofstream seq_geo_length_shortest_paths_file(name + "_spglseq.dat", std::ios_base::out);
  // if( !seq_geo_length_shortest_paths_file.is_open() )
  // {
  //   std::cerr << "Could not open file: " << name << "_spglseq.dat" << std::endl;
  //   std::terminate();
  // }

  // // Writes the sequence into the file.
  // for(unsigned int i(0); i<nb_vertices; ++i)
  // {
  //   for(unsigned int j(i+1); j<nb_vertices; ++j)  // excludes paths to itself
  //   {
  //     if(geo_length_shortest_path[i][j] < nb_vertices)  // excludes non-existing paths
  //     {
  //       seq_geo_length_shortest_paths_file << geo_length_shortest_path[i][j] << std::endl;
  //     }
  //   }
  // }

  // // Closes the stream.
  // seq_geo_length_shortest_paths_file.close();


  // // ==============================================================================================
  // // *** Greedy paths between all ordered pair of vertices.

  // // File stream for the sequence of the geometric length of the greedy paths.
  // std::ofstream seq_geo_length_greedy_paths_file(name + "_gpglseq.dat", std::ios_base::out);
  // if( !seq_geo_length_greedy_paths_file.is_open() )
  // {
  //   std::cerr << "Could not open file: " << name << "_gpglseq.dat" << std::endl;
  //   std::terminate();
  // }

  // // File stream for the sequence of the geometric stretch of the greedy paths.
  // std::ofstream seq_geo_stretch_greedy_paths_file(name + "_gpgsseq.dat", std::ios_base::out);
  // if( !seq_geo_stretch_greedy_paths_file.is_open() )
  // {
  //   std::cerr << "Could not open file: " << name << "_gpgsseq.dat" << std::endl;
  //   std::terminate();
  // }

  // // File stream for the sequence of the topological stretch of the greedy paths.
  // std::ofstream seq_topo_stretch_greedy_paths_file(name + "_gptsseq.dat", std::ios_base::out);
  // if( !seq_topo_stretch_greedy_paths_file.is_open() )
  // {
  //   std::cerr << "Could not open file: " << name << "_gptsseq.dat" << std::endl;
  //   std::terminate();
  // }

  // // File stream for the distribution of the topological length of the greedy paths.
  // std::ofstream dist_topo_length_greedy_paths_file(name + "_gptldist.dat", std::ios_base::out);
  // if( !dist_topo_length_greedy_paths_file.is_open() )
  // {
  //   std::cerr << "Could not open file: " << name << "_gptldist.dat" << std::endl;
  //   std::terminate();
  // }

  // // 1) Computes the greedy paths between each ordered pair of vertices.
  // // 2) Compiles the distribution of the topological length of existing greedy paths.
  // // 3) Writes the sequence of the geometric length of the greedy paths into the file.
  // // 4) Writes the sequence of the geometric stretch of the greedy paths into the file.
  // // 5) Writes the sequence of the topological stretch of the greedy paths into the file.
  // std::vector<unsigned int> dist_topo_length_greedy_paths(nb_vertices, 0);
  // unsigned int id1, id2;
  // for(auto v1 : Name2Vertex)
  // {
  //   for(auto v2 : Name2Vertex)
  //   {
  //     // Computes the greedy paths between each ordered pair of vertices.
  //     auto distance = greedy_pathfinder(v1.second, v2.second, g, Vertex2Position);
  //     if(distance.second < nb_vertices)  // excludes non-existing paths
  //     {
  //       // Compiles the distribution of the topological length of existing greedy paths.
  //       dist_topo_length_greedy_paths[distance.second] += 1;
  //       if(distance.second > 0)  // excludes paths to itself
  //       {
  //         // Gets the IDs of the vertices.
  //         id1 = g[v1.second].id;
  //         id2 = g[v2.second].id;
  //         // Writes the sequence of the geometric length of the greedy paths into the file.
  //         seq_geo_length_greedy_paths_file << distance.first << std::endl;
  //         // Writes the sequence of the geometric stretch of the greedy paths into the file.
  //         seq_geo_stretch_greedy_paths_file << distance.first / geo_length_shortest_path[id1][id2]
  //                                           << std::endl;
  //         // Writes the sequence of the topological stretch of the greedy paths into the file.
  //         seq_topo_stretch_greedy_paths_file << distance.second / topo_length_shortest_path[id1][id2]
  //                                            << std::endl;
  //       }
  //     }
  //   }
  // }

  // // 6) Writes the distribution of the topological length of the greedy paths into the file.
  // unsigned int m = 0;
  // for(auto d : dist_topo_length_greedy_paths)
  // {
  //   if(d > 0)
  //   {
  //     dist_topo_length_greedy_paths_file << m << " " << d << std::endl;
  //   }
  //   ++m;
  // }

  // // Closes the streams.
  // seq_geo_length_greedy_paths_file.close();
  // seq_geo_stretch_greedy_paths_file.close();
  // seq_topo_stretch_greedy_paths_file.close();
  // dist_topo_length_greedy_paths_file.close();


  // ==============================================================================================
  // Exits the program successfully.
  return EXIT_SUCCESS;
}