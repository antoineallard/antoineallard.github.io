// ================================================================================================
//
// author:  Antoine Allard
// email:   antoine.allard.1@gmail.com 
// www:     antoineallard.info
//
// last updated: Mar. 3rd, 2015
//
// To compile: g++ -O3 -std=c++11 generate_synthetic_graph.cpp -lgsl -lgslcblas
//
// ================================================================================================


#include <ctime>
#include <fstream>
#include "hyperbolic_graph.hpp"

int main(int argc, char* argv[])
{

  // ==============================================================================================
  // *** Number of nodes.
  unsigned int nb_vertices = std::atoi(argv[1]);
  // *** The type of metric space used.
  std::string geometry = "S1";
  // *** Coupling between the weights and the metric distance.
  double alpha = std::atof(argv[2]);
  // *** Density of the vertices in the metric space.
  double delta = 1.0;
  // *** The pdf used for the hidden variable kappa, and its parameters.
  std::string pdf_kappa_type = "pdf_powerlaw_hardcutoff";                   // power-law between a lower and an upper bound
  double gamma          = std::atof(argv[3]);                               // exponent
  double kappa_min      = std::atof(argv[4]);                               // lower bound
  double kappa_max      = std::atof(argv[5]);                               // upper bound
  std::vector<double> pdf_kappa_param = {gamma, kappa_min, kappa_max};
  // *** The pdf used for the hidden variable sigma, and its parameters.
  std::string pdf_sigma_type = "deterministic_scaling";         // scaling of the form: sigma = kappa^eta
  double eta               = std::atof(argv[6]);
  double prop_constant     = std::atof(argv[7]);
  std::vector<double> pdf_sigma_param = {eta, prop_constant};
  // *** The function used for the connection probability, and its parameters.
  std::string prob_connection_type = "prob_FermiDirac";
  double beta = std::atof(argv[8]);
  std::vector<double> prob_connection_param = {beta};
  // *** The pdf used for the weights, and its parameters.
  std::string pdf_weights_type = "pdf_gamma";
  double weights_gamma_scale = std::atof(argv[9]);
  std::vector<double> pdf_weights_param = {1./weights_gamma_scale, weights_gamma_scale};


  // ==============================================================================================
  // Simulations.

  // Reads the kappa sequence.
  std::string kappa_sequence_filename  = "networks/";
  kappa_sequence_filename += argv[10];
  kappa_sequence_filename += "/original_graph/";
  kappa_sequence_filename += argv[10];
  kappa_sequence_filename += "_degree_sequence.dat";
  std::ifstream kappa_sequence_file(kappa_sequence_filename);
  std::string tmp_kappa;
  std::vector<double> kappa_sequence(nb_vertices);
  unsigned int cnt = 0;
  while( !kappa_sequence_file.eof() )
  {
    kappa_sequence_file >> tmp_kappa >> std::ws;
    kappa_sequence[cnt] = std::stof(tmp_kappa);
    ++cnt;
  }
  kappa_sequence_file.close();
  // Reads the strength sequence.
  std::string sigma_sequence_filename  = "networks/";
  sigma_sequence_filename += argv[10];
  sigma_sequence_filename += "/original_graph/";
  sigma_sequence_filename += argv[10];
  sigma_sequence_filename += "_strength_seq.dat";
  std::ifstream sigma_sequence_file(sigma_sequence_filename);
  std::string tmp_sigma;
  std::vector<double> sigma_sequence(nb_vertices);
  cnt = 0;
  while( !sigma_sequence_file.eof() )
  {
    sigma_sequence_file >> tmp_sigma >> std::ws;
    sigma_sequence[cnt] = std::stof(tmp_sigma);
    ++cnt;
  }
  sigma_sequence_file.close();
  // *** Initializes the random number generator.
  // std::mt19937 engine(std::time(NULL));
  std::mt19937 engine(std::atoi(argv[12]));

  // *** Creates a graph.
  hyperbolic_graph graph;
  // graph.make_graph_fixed_kappa_sequence(nb_vertices, geometry, delta, alpha, pdf_kappa_type, pdf_kappa_param, kappa_sequence, pdf_sigma_type, pdf_sigma_param, prob_connection_type, prob_connection_param, pdf_weights_type, pdf_weights_param, engine);
  graph.make_graph_fixed_kappa_sigma_sequences(nb_vertices, geometry, delta, alpha, pdf_kappa_type, pdf_kappa_param, kappa_sequence, pdf_sigma_type, pdf_sigma_param, sigma_sequence, prob_connection_type, prob_connection_param, pdf_weights_type, pdf_weights_param, engine);
  // *** Computes graph's properties.
  graph.analyse_graph("complete");

  // *** Exports the graph into a file.
  std::string tiv_filename = "networks/";
  tiv_filename += argv[10];
  tiv_filename += "/tiv/tiv_networks/";
  tiv_filename += argv[10];
  tiv_filename += argv[11];
  graph.export_graph_properties(tiv_filename);
  graph.export_vertices_properties(tiv_filename);
  graph.export_edge_list(tiv_filename);
  graph.export_triangles(tiv_filename);


  // ==============================================================================================
  // Exits the program successfully.
  return 0;

}
