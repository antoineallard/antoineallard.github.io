// ================================================================================================
//
// author:  Antoine Allard
// email:   antoine.allard.1@gmail.com 
// www:     antoineallard.info
//
// last updated: Mar. 3rd, 2015
//
// To compile: g++ -O3 -std=c++11 generate_synthetic_graph.cpp -lgsl -lgslcblas
//
// ================================================================================================


#include <ctime>
#include <fstream>
#include "hyperbolic_graph.hpp"

int main(int argc, char* argv[])
{

  // ==============================================================================================
  // *** Root of the name of the output file.
  std::string name = argv[1];
  // *** Number of nodes.
  unsigned int nb_vertices = std::atoi(argv[2]);
  // *** The type of metric space used.
  std::string geometry = "S1";
  // *** Coupling between the weights and the metric distance.
  double alpha = std::atof(argv[3]);
  // *** Density of the vertices in the metric space.
  double delta = 1.0;
  // *** The pdf used for the hidden variable kappa, and its parameters.
  std::string pdf_kappa_type = "pdf_powerlaw_hardcutoff";                   // power-law between a lower and an upper bound
  double gamma          = std::atof(argv[4]);                               // exponent
  double kappa_min      = std::atof(argv[5]);                               // lower bound
  double kappa_max      = std::atof(argv[6]);                               // upper bound
  std::vector<double> pdf_kappa_param = {gamma, kappa_min, kappa_max};
  // *** The pdf used for the hidden variable sigma, and its parameters.
  std::string pdf_sigma_type = "deterministic_scaling";         // scaling of the form: sigma = kappa^eta
  double eta               = std::atof(argv[7]);
  double prop_constant     = std::atof(argv[8]);
  std::vector<double> pdf_sigma_param = {eta, prop_constant};
  // *** The function used for the connection probability, and its parameters.
  std::string prob_connection_type = "prob_FermiDirac";
  double beta = std::atof(argv[9]);
  std::vector<double> prob_connection_param = {beta};
  // *** The pdf used for the weights, and its parameters.
  std::string pdf_weights_type = "pdf_gamma";
  double weights_gamma_scale = std::atof(argv[10]);
  std::vector<double> pdf_weights_param = {1./weights_gamma_scale, weights_gamma_scale};


  // ==============================================================================================
  // Simulations.
  // Reads the degree sequence.
  std::string kappa_sequence_filename  = "networks/";
  kappa_sequence_filename += name;
  kappa_sequence_filename += "/original_graph/";
  kappa_sequence_filename += name;
  kappa_sequence_filename += "_degree_seq.dat";
  std::ifstream kappa_sequence_file(kappa_sequence_filename);
  std::string tmp_kappa;
  std::vector<double> kappa_sequence(nb_vertices);
  unsigned int cnt = 0;
  while( !kappa_sequence_file.eof() )
  {
    kappa_sequence_file >> tmp_kappa >> std::ws;
    kappa_sequence[cnt] = std::stof(tmp_kappa);
    ++cnt;
  }
  kappa_sequence_file.close();
  // *** Initializes the random number generator.
  // std::mt19937 engine(std::time(NULL));
  std::mt19937 engine(std::atoi(argv[11]));

  // *** Creates a graph.
  hyperbolic_graph graph;
  graph.make_graph_fixed_kappa_sequence(nb_vertices, geometry, delta, alpha, pdf_kappa_type, pdf_kappa_param, kappa_sequence, pdf_sigma_type, pdf_sigma_param, prob_connection_type, prob_connection_param, pdf_weights_type, pdf_weights_param, engine);

  graph.export_edge_list("networks/" + name + "/original_graph/" + name + "_validation");
  // graph.export_triangles(tiv_filename);
  graph.export_graph_properties("networks/" + name + "/original_graph/" + name);
  graph.export_vertices_properties("networks/" + name + "/original_graph/" + name);

  // // *** Computes graph's properties.
  // graph.analyse_graph("light");

  // for(int n(0); n<nb_vertices; ++n)
  // {
  //   std::cout << graph(n)->get_hidden_variables(0) << std::endl;
  // }

  // *** Exports the graph into a file.
  // std::cout << graph.degree_zero_vertices << "  " << graph.k_avg << "  " << graph.kappa_avg << "  " << graph.s_avg << "  " << graph.s_var << "  " << graph.s_2mt << std::endl;
  // graph.export_edge_list(name);
  // graph.export_triangles(name);
  // graph.export_extended_edge_list(name);


  // ==============================================================================================
  // Exits the program successfully.
  return 0;

}
