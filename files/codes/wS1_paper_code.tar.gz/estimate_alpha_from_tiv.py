#!/usr/bin/python
# -*- coding: utf8 -*- 
# ========================================================================
# packages
#================================================
import numpy as np
import matplotlib.pyplot as plt
from random import randint
from scipy import stats
import os,sys


id_net = "-1"
if(len(sys.argv) > 1):
  id_net = str(sys.argv[1])


# # Parameters for each network.
# if(id_net == "iJO1366_max_deg_90_num_reacs"):
#   type_net = "real_avgk"
#   gamma  = 2.52
#   avgk   = 7.25
#   beta   = 2.0
#   N      = 1100
#   eta    = 1.1
#   a      = 1.0
#   sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60]
#   sample_gnoise = [0.0001, 1.00, 2.00, 3.00, 4.00, 5.00]
#   ka_zero = (gamma-2.0) * avgk / (gamma-1.0)
#   ka_max  = ka_zero * N**(1./(gamma-1.))
#   N0 = 0.0
#   avgs = 9.01818
#   vars = 287.409
#   noise_characterization_y_min = 2.5
#   noise_characterization_y_max = 4.5
#   epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5]
#   epsilons_sq = np.append(1.0001, np.arange(1.1,2.1,0.1))
#   # epsilons_sq = np.append(1.0001, np.arange(1.05,2.05,0.05))
#   alpha_tilde = np.arange(0.0,0.999999,0.05)
#   alpha_inf = np.array([5.751, 0.00])

# if(id_net == "wtw2013BB"):
#   type_net = "real_kappa"
#   gamma  = 2.42
#   ka_zero = 2.5
#   ka_max  = 800.0
#   beta   = 2.5
#   N      = 200.0
#   eta    = 1.62
#   a      = 3738.0
#   sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60]
#   sample_gnoise = [0.0001, 1.00, 2.00, 3.00, 4.00, 5.00]
#   N0 = 0.0
#   avgs = 127940.0
#   vars = 1.9037e+11
#   noise_characterization_y_min = 0
#   noise_characterization_y_max = 15
#   # epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5]
#   # epsilons_sq = np.append(1.0001, np.arange(1.1,2.0,0.1))
#   epsilons_sq = np.arange(1.5,1.8,0.01)
#   alpha_tilde = np.arange(0.0,0.999999,0.05)

# if(id_net == "wtw2013BB_take2"):
#   type_net = "real_kappa"
#   gamma  = 2.42
#   ka_zero = 2.0
#   ka_max  = 800.0
#   beta   = 2.5
#   N      = 200.0
#   eta    = 1.62
#   a      = 3738.0
#   sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
#   sample_gnoise = [0.0001, 1.00, 2.00, 3.00, 4.00, 5.00]
#   N0 = 0.0
#   avgs = 127940.0
#   vars = 1.9037e+11
#   noise_characterization_y_min = 0
#   noise_characterization_y_max = 15
#   # epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5]
#   # epsilons_sq = np.append(1.0001, np.arange(1.1,2.0,0.1))
#   epsilons_sq = np.arange(1.5,1.8,0.01)
#   alpha_tilde = np.arange(0.0,0.999999,0.05)

# if(id_net == "wtw2013BB_real_degree"):
#   type_net = "real"
#   gamma  = 2.42
#   ka_zero = 2.5
#   ka_max  = 800.0
#   beta   = 2.5
#   N      = 189.0
#   eta    = 1.62
#   a      = 3738.0
#   sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
#   sample_gnoise = [0.0001, 1.00, 2.00, 3.00, 4.00, 5.00]
#   N0 = 0.0
#   avgs = 127940.0
#   vars = 1.9037e+11
#   noise_characterization_y_min = 4
#   noise_characterization_y_max = 25
#   epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0, 3.1, 3.2, 3.3, 3.4, 3.5]
#   # epsilons_sq = np.append(1.0001, np.arange(1.1,2.0,0.1))
#   # epsilons_sq = np.arange(1.5,1.8,0.01)
#   alpha_tilde = np.arange(0.0,0.999999,0.05)
#   alpha_inf = np.array([11.5, 0.00])

# if(id_net == "wanusa2013PassengersBB"):
#   type_net = "real_kappa"
#   gamma   = 1.6
#   ka_zero = 0.45
#   ka_max  = 500
#   beta   = 1.4
#   N      = 1175
#   eta    = 1.72
#   a      = 10000.0
#   sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
#   sample_gnoise = [0.0001, 1.00, 2.00, 3.00, 4.00, 5.00]
#   N0 = 0.0
#   avgs = (1059.0/(1059.0-175.0))*1.21066e+06
#   vars = (1059.0/(1059.0-175.0))*3.28868e+13 - avgs**2
#   noise_characterization_y_min = 5
#   noise_characterization_y_max = 45
#   epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5]
#   alpha_tilde = np.arange(0.0,0.999999,0.05)
#   alpha_inf = np.array([7.01, 0.00])

# if(id_net == "cargoships"):
#     type_net = "real"
#     gamma = 2.4
#     ka_zero = 31.6745
#     ka_max = 641.45
#     beta = 2.03
#     N = 951.0
#     eta = 1.18
#     a = 7.60252
#     sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
#                     0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
#     sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
#     nb_sim = 100
#     N0 = 0
#     avgs = 19.111816879
#     vars = 19317.6757498
#     noise_characterization_y_min = 5
#     noise_characterization_y_max = 45
#     epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
#                    2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
#                    3.1, 3.2, 3.3, 3.4, 3.5]
#     alpha_tilde = np.arange(0.0, 0.999999, 0.05)

if(id_net == "iJO1366_max_deg_90_num_reacs"):
    type_net = "real"
    gamma = 2.52
    ka_zero = 2.82561
    ka_max = 172.628
    beta = 2.2
    # beta = 1.84046
    N = 1100.0
    eta = 1.09
    a = 1.09
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100
    N0 = 0
    avgs = 97.7093584732
    vars = 107081.250547
    noise_characterization_y_min = 5
    noise_characterization_y_max = 45
    epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
                   2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
                   3.1, 3.2, 3.3, 3.4, 3.5]
    alpha_tilde = np.arange(0.0, 0.999999, 0.05)
    alpha_inf = np.array([[101.0, 0], [10, 0]])

if(id_net == "wtw2013BB_real_degree"):
    type_net = "real"
    gamma = 2.42
    ka_zero = 2.47768
    ka_max = 135.056
    beta = 2.8
    # beta   = 2.19572
    N = 189.0
    eta = 1.63
    a = 3772.98782
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100
    N0 = 0
    avgs = 97.7093584732
    vars = 107081.250547
    noise_characterization_y_min = 5
    noise_characterization_y_max = 45
    epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
                   2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
                   3.1, 3.2, 3.3, 3.4, 3.5]
    alpha_tilde = np.arange(0.0, 0.999999, 0.05)
    alpha_inf = np.array([[101.0, 0], [10, 0]])

if(id_net == "wanusa2013PassengersBB"):
    type_net = "real"
    gamma = 1.75833
    ka_zero = 0.92166
    ka_max = 167
    beta = 1.5
    # beta = 1.39853
    N = 884
    eta = 1.72
    a = 10000.0
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100
    N0 = 0
    avgs = 97.7093584732
    vars = 107081.250547
    noise_characterization_y_min = 5
    noise_characterization_y_max = 45
    epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
                   2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
                   3.1, 3.2, 3.3, 3.4, 3.5]
    alpha_tilde = np.arange(0.0, 0.999999, 0.05)
    alpha_inf = np.array([[101.0, 0], [10, 0]])

if(id_net == "EColi"):
    type_net = "real"
    gamma = 2.64496
    ka_zero = 2.93006
    ka_max = 154.988
    beta = 2.2
    # beta = 1.94227
    N = 1010.0
    eta = 1.09
    a = 1.09
    tmp_alpha = 0.452
    tmp_gnoise = 1.3
    nb_sim = 100
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100
    N0 = 0
    avgs = 8.86534653465
    vars = 261.094739731
    noise_characterization_y_min = 0
    noise_characterization_y_max = 5
    epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
                   2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
                   3.1, 3.2, 3.3, 3.4, 3.5]
    alpha_tilde = np.arange(0.0, 0.999999, 0.05)

if(id_net == "cargoshipsBB"):
    type_net = "real"
    gamma = 2.03355
    ka_zero = 18.9064
    ka_max = 1306.18
    beta = 1.85
    N = 834.0
    eta = 1.05
    a = 82.96924
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65,
                    0.70, 0.71, 0.72, 0.73, 0.74, 0.75, 0.76, 0.77, 0.78, 0.79,
                    0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100
    N0 = 0
    avgs = 1019.03597122
    vars = 5682548.67017
    noise_characterization_y_min = 5
    noise_characterization_y_max = 45
    epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
                   2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
                   3.1, 3.2, 3.3, 3.4, 3.5]
    alpha_tilde = np.arange(0.0, 0.999999, 0.05)
    alpha_inf = np.array([[101.0, 0], [10, 0]])

if(id_net == "Human08"):
    type_net = "real_strength"
    gamma = 4.35187
    ka_zero = 27.9574
    ka_max = 101.868
    beta = 2.4
    # beta = 2.10932
    N = 989.0
    eta = 1.39
    a = 0.00277
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.56, 0.57, 0.58, 0.59,
                    0.60, 0.61, 0.62, 0.63, 0.64, 0.65, 0.66, 0.67, 0.68, 0.69,
                    0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100
    N0 = 0
    avgs = 0.439567879686
    vars = 0.0427966314905
    noise_characterization_y_min = 0
    noise_characterization_y_max = 4
    epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
                   2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
                   3.1, 3.2, 3.3, 3.4, 3.5]
    alpha_tilde = np.arange(0.0, 0.999999, 0.05)
    # alpha_inf = np.array([[72.0, 0], [10, 0]])

if(id_net == "Human12a"):
    type_net = "real"
    # type_net = "real_strength"
    gamma = 4.35187
    ka_zero = 16.344
    # ka_zero = 4.0
    # ka_zero = 27.9574
    ka_max = 101.868
    beta = 2.8
    # beta = 2.10932
    N = 501.0
    eta = 0.86
    a = 0.01456
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.56, 0.57, 0.58, 0.59,
                    0.60, 0.61, 0.62, 0.63, 0.64, 0.65, 0.66, 0.67, 0.68, 0.69,
                    0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    N0 = 0
    avgs = 0.229609491816
    vars = 0.0156470915363
    noise_characterization_y_min = 0
    noise_characterization_y_max = 4
    epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
                   2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
                   3.1, 3.2, 3.3, 3.4, 3.5]
    alpha_tilde = np.arange(0.0, 0.999999, 0.05)
    nb_sim = 250

if(id_net == "Human12b"):
    type_net = "real"
    # type_net = "real_strength"
    gamma = 3000
    ka_zero = 17.5893
    # ka_zero = -8976875564
    ka_max = 0.3
    beta = 2.8
    # beta = 2.10932
    N = 586.0
    eta = 1.09
    a = 0.06469
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.56, 0.57, 0.58, 0.59,
                    0.60, 0.61, 0.62, 0.63, 0.64, 0.65, 0.66, 0.67, 0.68, 0.69,
                    0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    N0 = 0
    avgs = 1.9455958686
    vars = 0.849688098598
    noise_characterization_y_min = 0
    noise_characterization_y_max = 4
    epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
                   2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
                   3.1, 3.2, 3.3, 3.4, 3.5]
    alpha_tilde = np.arange(0.0, 0.999999, 0.05)
    nb_sim = 250
    # alpha_inf = np.array([[1.0001, 0.05, 0.0, 1.0],
    #                       [1.0001, 0.10, 0.0, 1.0],
    #                       [1.0001, 0.15, 0.0, 1.0],
    #                       [1.0001, 0.20, 0.0, 1.0],
    #                       [1.0001, 0.25, 0.0, 1.0],
    #                       [1.0001, 0.30, 0.0, 1.0],
    #                       [1.2500, 0.05, 0.0, 1.0],
    #                       [1.2500, 0.10, 0.0, 1.0],
    #                       [1.2500, 0.15, 0.0, 1.0],
    #                       [1.2500, 0.20, 0.0, 1.0],
    #                       [1.2500, 0.25, 0.0, 1.0],
    #                       [1.2500, 0.30, 0.0, 1.0],
    #                       [1.5000, 0.05, 0.0, 1.0],
    #                       [1.5000, 0.10, 0.0, 1.0],
    #                       [1.5000, 0.15, 0.0, 1.0],
    #                       [1.5000, 0.20, 0.0, 1.0],
    #                       [1.5000, 0.25, 0.0, 1.0],
    #                       [1.5000, 0.30, 0.0, 1.0],
    #                       [1.7500, 0.05, 0.0, 1.0],
    #                       [1.7500, 0.10, 0.0, 1.0],
    #                       [1.7500, 0.15, 0.0, 1.0],
    #                       [1.7500, 0.20, 0.0, 1.0],
    #                       [1.7500, 0.25, 0.0, 1.0],
    #                       [1.7500, 0.30, 0.0, 1.0],
    #                       [2.0000, 0.10, 0.0, 1.0],
    #                       [2.0000, 0.15, 0.0, 1.0],
    #                       [2.0000, 0.20, 0.0, 1.0],
    #                       [2.0000, 0.25, 0.0, 1.0],
    #                       [2.0000, 0.30, 0.0, 1.0]])
    #                       # [1.0001, 0.35, 0.0, 1.0],
    #                       # [1.0001, 0.45, 0.0, 1.0],
    #                       # [1.0001, 0.55, 0.0, 1.0],
    #                       # [1.0001, 0.65, 0.0, 1.0],
    #                       # [1.0001, 0.75, 0.0, 1.0],
    #                       # [1.0001, 0.85, 0.0, 1.0],
    #                       # [1.0001, 0.95, 0.0, 1.0],
    #                       # [1.2500, 0.35, 0.0, 1.0],
    #                       # [1.2500, 0.45, 0.0, 1.0],
    #                       # [1.2500, 0.55, 0.0, 1.0],
    #                       # [1.2500, 0.65, 0.0, 1.0],
    #                       # [1.2500, 0.75, 0.0, 1.0],
    #                       # [1.2500, 0.85, 0.0, 1.0],
    #                       # [1.2500, 0.95, 0.0, 1.0],
    #                       # [1.5000, 0.35, 0.0, 1.0],
    #                       # [1.5000, 0.45, 0.0, 1.0],
    #                       # [1.5000, 0.55, 0.0, 1.0],
    #                       # [1.5000, 0.65, 0.0, 1.0],
    #                       # [1.5000, 0.75, 0.0, 1.0],
    #                       # [1.5000, 0.85, 0.0, 1.0],
    #                       # [1.5000, 0.95, 0.0, 1.0],
    #                       # [1.7500, 0.35, 0.0, 1.0],
    #                       # [1.7500, 0.45, 0.0, 1.0],
    #                       # [1.7500, 0.55, 0.0, 1.0],
    #                       # [1.7500, 0.65, 0.0, 1.0],
    #                       # [1.7500, 0.75, 0.0, 1.0],
    #                       # [1.7500, 0.85, 0.0, 1.0],
    #                       # [1.7500, 0.95, 0.0, 1.0],
    #                       # [2.0000, 0.35, 0.0, 1.0],
    #                       # [2.0000, 0.45, 0.0, 1.0],
    #                       # [2.0000, 0.55, 0.0, 1.0],
    #                       # [2.0000, 0.65, 0.0, 1.0],
    #                       # [2.0000, 0.75, 0.0, 1.0],
    #                       # [2.0000, 0.85, 0.0, 1.0],
    #                       # [2.0000, 0.95, 0.0, 1.0]])

if(id_net == "UScommoditiesBB"):
    type_net = "real"
    gamma = 2.45648
    ka_zero = 2.6272
    ka_max = 105.557
    beta = 1.30083
    N = 376.0
    eta = 1.22
    a = 3044.61822
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45,
                    0.50, 0.51, 0.52, 0.53, 0.54, 0.55, 0.56, 0.57, 0.58, 0.59,
                    0.60, 0.61, 0.62, 0.63, 0.64, 0.65, 0.66, 0.67, 0.68, 0.69,
                    0.70, 0.71, 0.72, 0.73, 0.74,
                    0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 1000
    N0 = 0
    avgs = 29824.606383
    vars = 5920371496.08
    noise_characterization_y_min = 0
    noise_characterization_y_max = 10
    epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
                   2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
                   3.1, 3.2, 3.3, 3.4, 3.5]
    alpha_tilde = np.arange(0.0, 0.999999, 0.05)
    # alpha_inf = np.array([[28.0, 0], [10, 0]])


if(id_net == "UScommuteBB"):
    type_net = "real"
    gamma = 3.31283
    ka_zero = 2.53842
    ka_max = 30.1702
    beta = 2.2
    # beta = 1.64327
    N = 3109.0
    eta = 2.02
    a = 719.10118
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 10
    N0 = 0
    avgs = 19582.2656803
    vars = 3826693904.13
    noise_characterization_y_min = 5
    noise_characterization_y_max = 45
    epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
                   2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
                   3.1, 3.2, 3.3, 3.4, 3.5]
    alpha_tilde = np.arange(0.0, 0.999999, 0.05)
    # alpha_inf = np.array([[19.0, 0], [10, 0]])

if(id_net == "TestGraph"):
    type_net = "real"
    gamma = 2.5
    ka_zero = 2.0
    ka_max = 500
    beta = 2.2
    # beta = 1.64327
    N = 1911.0
    eta = 1.6
    a = 200.0
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100
    N0 = 0
    avgs = 5507.64757749
    vars = 862068355.93
    noise_characterization_y_min = 5
    noise_characterization_y_max = 45
    epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
                   2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
                   3.1, 3.2, 3.3, 3.4, 3.5]
    alpha_tilde = np.arange(0.0, 0.999999, 0.05)

if(id_net == "TestGraph2"):
    type_net = "real"
    gamma = 2.5
    ka_zero = 2.0
    ka_max = 500
    beta = 2.2
    # beta = 1.64327
    N = 1897.0
    eta = 1.6
    a = 200.0
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100
    N0 = 0
    avgs = 6460.95130034
    vars = 1908523486.16
    noise_characterization_y_min = 5
    noise_characterization_y_max = 45
    epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
                   2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
                   3.1, 3.2, 3.3, 3.4, 3.5]
    alpha_tilde = np.arange(0.0, 0.999999, 0.05)

if(id_net == "TestGraph3"):
    type_net = "real"
    gamma = 2.5
    ka_zero = 2.0
    ka_max = 500
    beta = 2.2
    # beta = 1.64327
    N = 1908.0
    eta = 1.6
    a = 200.0
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100
    N0 = 0
    avgs = 5953.16232788
    vars = 1302829929.63
    noise_characterization_y_min = 5
    noise_characterization_y_max = 45
    epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
                   2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
                   3.1, 3.2, 3.3, 3.4, 3.5]
    alpha_tilde = np.arange(0.0, 0.999999, 0.05)

if(id_net == "TestGraph4"):
    type_net = "real"
    gamma = 2.5
    ka_zero = 2.0
    ka_max = 500
    beta = 2.2
    # beta = 1.64327
    N = 1900.0
    eta = 1.6
    a = 200.0
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100
    N0 = 0
    avgs = 5877.20656719
    vars = 1223147401.8
    noise_characterization_y_min = 5
    noise_characterization_y_max = 45
    epsilons_sq = [1.0001, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0,
                   2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0,
                   3.1, 3.2, 3.3, 3.4, 3.5]
    alpha_tilde = np.arange(0.0, 0.999999, 0.05)


# Builds the name of the network.
if(type_net == "real_avgk"):
  name = id_net
if(type_net == "real"):
  name = id_net
if(type_net == "real_strength"):
  name = id_net
if(type_net == "real_kappa"):
  name = id_net
if(type_net == "synthetic_avgk"):
  name  = id_net
  name += '_gamma'  + str(int(gamma))  + 'p' + str(gamma-int(gamma))[2:]
  name += '_avgk'   + str(int(avgk))   + 'p' + str(avgk-int(avgk))[2:]
  name += '_beta'   + str(int(beta))   + 'p' + str(beta-int(beta))[2:]
  name += '_N'      + str(int(N))
  name += '_eta'    + str(int(eta))    + 'p' + str(eta-int(eta))[2:]
  name += '_a'      + str(int(a))      + 'p' + str(a-int(a))[2:]
  name += '_alpha'  + str(int(alpha))  + 'p' + str(alpha-int(alpha))[2:]
  name += '_gnoise' + str(int(gnoise)) + 'p' + str(gnoise-int(gnoise))[2:]


# Creates the folders, if necessary.
if(not os.path.exists('networks/' + name + '/figs')):
  os.system('mkdir ' + 'networks/' + name + '/figs')
if(not os.path.exists('networks/' + name + '/tiv')):
  os.system('mkdir ' + 'networks/' + name + '/tiv')  
if(not os.path.exists('networks/' + name + '/tiv/noise_characterization_compiled_results')):
  os.system('mkdir ' + 'networks/' + name + '/tiv/noise_characterization_compiled_results')
if(not os.path.exists('networks/' + name + '/tiv/figs')):
  os.system('mkdir ' + 'networks/' + name + '/tiv/figs')
# if(not os.path.exists('networks/' + name + '/tiv/tiv_curves')):
#   os.system('mkdir ' + 'networks/' + name + '/tiv/tiv_curves')
if(not os.path.exists('networks/' + name + '/tiv/tiv_networks')):
  os.system('mkdir ' + 'networks/' + name + '/tiv/tiv_networks')


# =================================================================================================
# Compilation of results.
# =================================================================================================

# Compiles the cluster's results.
for tmp_gnoise in sample_gnoise:
  for tmp_alpha in sample_alpha:
    rough_results_filename  = 'networks/' + name + '/tiv/noise_characterization_rough_results/'
    rough_results_filename += name + '_noise_characterization_alpha' + str(int(tmp_alpha)) + 'p' + str(tmp_alpha-int(tmp_alpha))[2:] + '_gnoise' + str(int(tmp_gnoise)) + 'p' + str(tmp_gnoise-int(tmp_gnoise))[2:] + '_*.dat'
    compiled_results_filename  = 'networks/' + name + '/tiv/noise_characterization_compiled_results/'
    compiled_results_filename += name + '_noise_characterization_alpha' + str(int(tmp_alpha)) + 'p' + str(tmp_alpha-int(tmp_alpha))[2:] + '_gnoise' + str(int(tmp_gnoise)) + 'p' + str(tmp_gnoise-int(tmp_gnoise))[2:] + '.dat'
    print('cat ' + rough_results_filename + ' > ' + compiled_results_filename)
    os.system('cat ' + rough_results_filename + ' > ' + compiled_results_filename)

# Compiles the results.
file = open('networks/' + name + '/tiv/' + name + '_noise_characterization.dat', 'w')
for tmp_gnoise in sample_gnoise:
  file.write(str(tmp_gnoise))
  for tmp_alpha in sample_alpha:
    filename = 'networks/' + name + '/tiv/noise_characterization_compiled_results/' + name + '_noise_characterization_alpha' + str(int(tmp_alpha)) + 'p' + str(tmp_alpha-int(tmp_alpha))[2:] + '_gnoise' + str(int(tmp_gnoise)) + 'p' + str(tmp_gnoise-int(tmp_gnoise))[2:] + '.dat'
    if(os.path.exists(filename)):
      print(filename)
      data = np.array(np.loadtxt(filename))
      cv  = ((N-data[:,0])/N)*(data[:,4]/data[:,3]**2) - (data[:,0]/N)
      mean_cv = np.mean(cv) 
      err_up  = 2*np.sqrt( sum( ((cv-mean_cv)*(cv>mean_cv))**2 ) / ( sum( cv>mean_cv ) ) )
      err_dw  = 2*np.sqrt( sum( ((cv-mean_cv)*(cv<mean_cv))**2 ) / ( sum( cv<mean_cv ) ) )
      file.write('  ' + str(mean_cv) + '  ' + str(err_up) + '  ' + str(err_dw) )
  file.write('\n')    
file.close()


# =================================================================================================
# Fit the data and extrapolates the value of alpha from the data for given noise values.
# =================================================================================================

# Loads the data.
data = np.loadtxt('networks/' + name + '/tiv/' + name + '_noise_characterization.dat')
# Extracts the slope and intercept from the data.
fitted_data = np.zeros((len(sample_alpha),7))
for i in xrange(len(sample_alpha)):
  fitted_data[i,0] = sample_alpha[i]
  slope, intercept, r_value, p_value, std_err = stats.linregress(np.array(data[:,0] + np.ones(len(data[:,0]))), np.array(data[:,3*i+1]))
  fitted_data[i,1] = slope
  fitted_data[i,2] = intercept
  slope, intercept, r_value, p_value, std_err = stats.linregress(np.array(data[:,0] + np.ones(len(data[:,0]))), np.array(data[:,3*i+1])+np.array(data[:,3*i+2]))
  fitted_data[i,3] = slope
  fitted_data[i,4] = intercept
  slope, intercept, r_value, p_value, std_err = stats.linregress(np.array(data[:,0] + np.ones(len(data[:,0]))), np.array(data[:,3*i+1])-np.array(data[:,3*i+3]))
  fitted_data[i,5] = slope
  fitted_data[i,6] = intercept


# Saves the inferred alphas.
file = open('networks/' + name + '/tiv/' + name + '_noise_fitted.dat', 'w')
for i in np.arange(len(sample_alpha)):
  file.write(str(fitted_data[i,0]))
  for j in np.arange(6):
    file.write('  ' + str(fitted_data[i,j+1]))
  file.write('\n')
file.close()

# The value to match.
cv_real  = ((N-N0)/N) * (vars/avgs**2) - (N0/N)
# print cv_real
i = 0
print(sample_alpha[i], (cv_real-fitted_data[i, 2]) / fitted_data[i, 1] )

# Finds the values of alpha.
alpha_inf = np.zeros((len(epsilons_sq),4))
cv_errorbars = np.zeros((len(epsilons_sq),4))
for i in np.arange(len(epsilons_sq)):
  # i=10
  alpha_inf[i,0] = epsilons_sq[i]
  cv_errorbars[i,0] = epsilons_sq[i]

  cv_sampled = fitted_data[:,1]*epsilons_sq[i] + fitted_data[:,2]
  if(sum(cv_sampled<cv_real) == len(cv_sampled)):
    print('Warning: inferred value of alpha above the sampled data.')
    idx_alpha = len(cv_sampled) - 1
  elif(sum(cv_sampled>cv_real) == len(cv_sampled)):
    print('Warning: inferred value of alpha below the sampled data.')
    idx_alpha = 1
  else:
    idx_alpha = next(x[0] for x in enumerate(cv_sampled) if x[1] > cv_real)
  alpha_relative_location = (cv_real-cv_sampled[idx_alpha-1])/((cv_sampled[idx_alpha]-cv_sampled[idx_alpha-1]))
  # print(alpha_relative_location)
  alpha_inf[i,1] = (sample_alpha[idx_alpha]-sample_alpha[idx_alpha-1])*alpha_relative_location + sample_alpha[idx_alpha-1]
  if alpha_inf[i,1] < 0:
      alpha_inf[i,1] = 0
  cv_errorbars[i,1] = cv_real

  # Inferior error bar
  cv_sampled_err_up = fitted_data[:,3]*epsilons_sq[i] + fitted_data[:,4]
  if(sum(cv_sampled_err_up<cv_real) == len(cv_sampled_err_up)):
    # print('Warning: Lower bound on alpha above the sampled data.')
    idx_alpha_err_up_max = len(cv_sampled) - 1
  elif(sum(cv_sampled_err_up>cv_real) == len(cv_sampled_err_up)):
    # print('Warning: Lower bound on alpha below the sampled data.')
    idx_alpha_err_up_max = 1
  else:
    idx_alpha_err_up_max = next(x[0] for x in enumerate(cv_sampled_err_up) if x[1] > cv_real)
  idx_alpha_err_up_min = idx_alpha_err_up_max - 1
  alpha_err_up_relative_location = (cv_real-cv_sampled_err_up[idx_alpha_err_up_min])/((cv_sampled_err_up[idx_alpha_err_up_max]-cv_sampled_err_up[idx_alpha_err_up_min]))
  alpha_inf[i,3] = (sample_alpha[idx_alpha_err_up_max]-sample_alpha[idx_alpha_err_up_min])*alpha_err_up_relative_location + sample_alpha[idx_alpha_err_up_min]
  if( alpha_inf[i,3] < 0):
    alpha_inf[i,3] = 0
  cv_errorbars[i,3] = cv_real - ((cv_sampled_err_up[idx_alpha]-cv_sampled_err_up[idx_alpha-1])*alpha_relative_location + cv_sampled_err_up[idx_alpha-1])

  # Superior error bar
  cv_sampled_err_dw = fitted_data[:,5]*epsilons_sq[i] + fitted_data[:,6]
  # for j in np.arange(len(cv_sampled_err_dw)):
  #   if(cv_sampled_err_dw[j] > cv_real):

  if(sum(cv_sampled_err_dw<cv_real) == len(cv_sampled_err_dw)):
    # print('Warning: Lower bound on alpha above the sampled data.')
    idx_alpha_err_dw_max = len(cv_sampled) - 1
    if(sample_alpha[idx_alpha_err_dw_max]>=0.50):
      print('Warning: All sampled values of alpha can reproduce the noise. Setting the upper bound on inferred alpha to 1.0 since the largest sampled value of alpha is above 0.50.')
      alpha_inf[i,2] = 1.0
    else:
      print('Warning: All sampled values of alpha can reproduce the noise. Setting the upper bound on inferred alpha to the largest sampled value of alpha. More simulations needed.')
      alpha_inf[i,2] = sample_alpha[idx_alpha_err_dw_max]
  elif(sum(cv_sampled_err_dw>cv_real) == len(cv_sampled_err_dw)):
    # print('Warning: Lower bound on alpha below the sampled data.')
    idx_alpha_err_dw_max = 1
    idx_alpha_err_dw_min = 0
    alpha_err_dw_relative_location = (cv_real-cv_sampled_err_dw[idx_alpha_err_dw_min])/((cv_sampled_err_dw[idx_alpha_err_dw_max]-cv_sampled_err_dw[idx_alpha_err_dw_min]))
    alpha_inf[i,2] = (sample_alpha[idx_alpha_err_dw_max]-sample_alpha[idx_alpha_err_dw_min])*alpha_err_dw_relative_location + sample_alpha[idx_alpha_err_dw_min]
    if( np.fabs(alpha_inf[i,2]) > 1):
      alpha_inf[i,2] = 1
    cv_errorbars[i,2] = ((cv_sampled_err_dw[idx_alpha]-cv_sampled_err_dw[idx_alpha-1])*alpha_relative_location + cv_sampled_err_dw[idx_alpha-1]) - cv_real
  else:
    idx_alpha_err_dw_max = next(x[0] for x in enumerate(cv_sampled_err_dw) if x[1] > cv_real)
    idx_alpha_err_dw_min = idx_alpha_err_dw_max - 1
    # if( cv_sampled_err_dw[idx_alpha_err_dw_min] > cv_sampled_err_dw[idx_alpha_err_dw_max]):
    #   tmp = idx_alpha_err_dw_min
    #   idx_alpha_err_dw_min = idx_alpha_err_dw_max
    #   idx_alpha_err_dw_max = tmp
    alpha_err_dw_relative_location = (cv_real-cv_sampled_err_dw[idx_alpha_err_dw_min])/((cv_sampled_err_dw[idx_alpha_err_dw_max]-cv_sampled_err_dw[idx_alpha_err_dw_min]))
    alpha_inf[i,2] = (sample_alpha[idx_alpha_err_dw_max]-sample_alpha[idx_alpha_err_dw_min])*alpha_err_dw_relative_location + sample_alpha[idx_alpha_err_dw_min]
    if( np.fabs(alpha_inf[i,2]) > 1):
      alpha_inf[i,2] = 1
    cv_errorbars[i,2] = ((cv_sampled_err_dw[idx_alpha]-cv_sampled_err_dw[idx_alpha-1])*alpha_relative_location + cv_sampled_err_dw[idx_alpha-1]) - cv_real

  # cv_sampled_err_up = fitted_data[:,3]*epsilons_sq[i] + fitted_data[:,4]
  # cv_inf_err_up = (cv_sampled_err_up[idx_alpha]-cv_sampled_err_up[idx_alpha-1])*alpha_relative_location + cv_sampled_err_up[idx_alpha-1]
  # if(sum(cv_sampled<cv_inf_err_up) == len(cv_sampled)):
  #   # print('Warning: Upper bound on alpha above the sampled data.')
  #   idx_alpha_err_up = len(cv_sampled) - 1
  # elif(sum(cv_sampled>cv_inf_err_up) == len(cv_sampled)):
  #   # print('Warning: Upper bound on alpha below the sampled data.')
  #   idx_alpha_err_up = 1
  # else:
  #   idx_alpha_err_up = next(x[0] for x in enumerate(cv_sampled) if x[1] > cv_inf_err_up)
  # alpha_err_up_relative_location = (cv_inf_err_up-cv_sampled[idx_alpha_err_up-1])/((cv_sampled[idx_alpha_err_up]-cv_sampled[idx_alpha_err_up-1]))
  # alpha_inf[i,2] = (sample_alpha[idx_alpha_err_up]-sample_alpha[idx_alpha_err_up-1])*alpha_err_up_relative_location + sample_alpha[idx_alpha_err_up-1]  
  # if( alpha_inf[i,3] > 1):
  #   alpha_inf[i,3] = 1

  # cv_sampled_err_dw = fitted_data[:,5]*epsilons_sq[i] + fitted_data[:,6]
  # cv_inf_err_dw = (cv_sampled_err_dw[idx_alpha]-cv_sampled_err_dw[idx_alpha-1])*alpha_relative_location + cv_sampled_err_dw[idx_alpha-1]
  # # print(cv_inf_err_dw)
  # if(sum(cv_sampled<cv_inf_err_dw) == len(cv_sampled)):
  #   # print('Warning: Lower bound on alpha above the sampled data.')
  #   idx_alpha_err_dw = len(cv_sampled) - 1
  # elif(sum(cv_sampled>cv_inf_err_dw) == len(cv_sampled)):
  #   # print('Warning: Lower bound on alpha below the sampled data.')
  #   idx_alpha_err_dw = 1
  # else:
  #   idx_alpha_err_dw = next(x[0] for x in enumerate(cv_sampled) if x[1] > cv_inf_err_dw)
  # alpha_err_dw_relative_location = (cv_inf_err_dw-cv_sampled[idx_alpha_err_dw-1])/((cv_sampled[idx_alpha_err_dw]-cv_sampled[idx_alpha_err_dw-1]))
  # alpha_inf[i,3] = (sample_alpha[idx_alpha_err_dw]-sample_alpha[idx_alpha_err_dw-1])*alpha_err_dw_relative_location + sample_alpha[idx_alpha_err_dw-1]
  # if( alpha_inf[i,3] < 0):
  #   alpha_inf[i,3] = 0

# Saves the inferred alphas.
file = open('networks/' + name + '/tiv/' + name + '_inferred_alpha.dat', 'w')
for i in np.arange(len(epsilons_sq)):
  file.write(str(alpha_inf[i,0]))
  for j in np.arange(3):
    file.write('  ' + str(alpha_inf[i,j+1]))
  file.write('\n')
file.close()


# =================================================================================================
# Verification figure.
# =================================================================================================

# Plot parameters.
plt.rcParams['text.usetex'] = True
plt.rcParams['font.size'] = 32
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = 'Charter'
plt.rcParams['xtick.major.width'] = 2
plt.rcParams['xtick.major.size'] = 8
plt.rcParams['ytick.major.width'] = 2
plt.rcParams['ytick.major.size'] = 8
# Custom plot parameters.
# colors   = ['#80a339', '#af773e', '#ba2b83', '#3e76af', '#5c39a3', '#ee4939']
colors   = ['#0000ff', '#00ff00', '#ff0000', '#40e0d0', '#008b00', '#ee4939', '#ba2b83']
symbols  = ['o','s', '^', '*']
# The value to match.
cv_real  = ((N-N0)/N) * (vars/avgs**2) - (N0/N)
print(cv_real)
# Loads the inferred alphas.
sampled_data = np.loadtxt('networks/' + name + '/tiv/' + name + '_noise_characterization.dat')
# Creates the figure and axis objects.
fig, ax = plt.subplots(1,1,figsize=(12,8))
fig.subplots_adjust(bottom=0.15)
fig.subplots_adjust(bottom=0.12, left=0.12, top=0.95, right=0.85)
# Plots the data and the linear fit.
x_th = np.arange(1.0,10.0)
for i in xrange(len(sample_alpha)):
  ax.plot(sampled_data[:,0]+1, sampled_data[:,3*i+1], c=colors[i % len(colors)], ls='None', lw=3, marker=symbols[i % len(symbols)], ms=8, label=r'$\alpha=' + str(sample_alpha[i]) + '$')
  ax.plot(x_th, fitted_data[i,1]*x_th+fitted_data[i,2], c=colors[i % len(colors)], ls='--', lw=2, marker='None', ms=10)
  # ax.plot(x_th, fitted_data[i,3]*x_th+fitted_data[i,4], c=colors[i % len(colors)], ls='-', lw=1, marker=symbols[i % len(symbols)], ms=8)#, label=r'$\alpha=' + str(sample_alpha[i]) + '$')
  # ax.plot(x_th, fitted_data[i,5]*x_th+fitted_data[i,6], c=colors[i % len(colors)], ls='-', lw=1, marker=symbols[i % len(symbols)], ms=8)#, label=r'$\alpha=' + str(sample_alpha[i]) + '$')
# ax.errorbar(cv_errorbars[:,0], cv_errorbars[:,1], yerr=[cv_errorbars[:,3],cv_errorbars[:,2]], c=colors[i % len(colors)], ls='-', lw=3, marker='None', ms=10)
# # Shows two examples of the bounds based on the error bars.
# i=1
# ax.plot(x_th, fitted_data[i,3]*x_th+fitted_data[i,4], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.plot(x_th, fitted_data[i,5]*x_th+fitted_data[i,6], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.errorbar(sampled_data[:,0]+1, sampled_data[:,3*i+1], yerr=[sampled_data[:,3*i+3],sampled_data[:,3*i+2]], c=colors[i % len(colors)], ls='None', lw=1.5, marker=symbols[i % len(symbols)], ms=10)
# i=0
# ax.plot(x_th, fitted_data[i,3]*x_th+fitted_data[i,4], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.plot(x_th, fitted_data[i,5]*x_th+fitted_data[i,6], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.errorbar(sampled_data[:,0]+1, sampled_data[:,3*i+1], yerr=[sampled_data[:,3*i+3],sampled_data[:,3*i+2]], c=colors[i % len(colors)], ls='None', lw=3, marker=symbols[i % len(symbols)], ms=10)
# i=8
# ax.plot(x_th, fitted_data[i,3]*x_th+fitted_data[i,4], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.plot(x_th, fitted_data[i,5]*x_th+fitted_data[i,6], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.errorbar(sampled_data[:,0]+1, sampled_data[:,3*i+1], yerr=[sampled_data[:,3*i+3],sampled_data[:,3*i+2]], c=colors[i % len(colors)], ls='None', lw=3, marker=symbols[i % len(symbols)], ms=10)
# i=11
# ax.plot(x_th, fitted_data[i,3]*x_th+fitted_data[i,4], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.plot(x_th, fitted_data[i,5]*x_th+fitted_data[i,6], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.errorbar(sampled_data[:,0]+1, sampled_data[:,3*i+1], yerr=[sampled_data[:,3*i+3],sampled_data[:,3*i+2]], c=colors[i % len(colors)], ls='None', lw=3, marker=symbols[i % len(symbols)], ms=10)
# i=4
# ax.plot(x_th, fitted_data[i,3]*x_th+fitted_data[i,4], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.plot(x_th, fitted_data[i,5]*x_th+fitted_data[i,6], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.errorbar(sampled_data[:,0]+1, sampled_data[:,3*i+1], yerr=[sampled_data[:,3*i+3],sampled_data[:,3*i+2]], c=colors[i % len(colors)], ls='None', lw=1.5, marker=symbols[i % len(symbols)], ms=10)
# i=3
# ax.plot(x_th, fitted_data[i,3]*x_th+fitted_data[i,4], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.plot(x_th, fitted_data[i,5]*x_th+fitted_data[i,6], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.errorbar(sampled_data[:,0]+1, sampled_data[:,3*i+1], yerr=[sampled_data[:,3*i+3],sampled_data[:,3*i+2]], c=colors[i % len(colors)], ls='None', lw=3, marker=symbols[i % len(symbols)], ms=10)
# i=2
# ax.plot(x_th, fitted_data[i,3]*x_th+fitted_data[i,4], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.plot(x_th, fitted_data[i,5]*x_th+fitted_data[i,6], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.errorbar(sampled_data[:,0]+1, sampled_data[:,3*i+1], yerr=[sampled_data[:,3*i+3],sampled_data[:,3*i+2]], c=colors[i % len(colors)], ls='None', lw=3, marker=symbols[i % len(symbols)], ms=10)
# i=1
# ax.plot(x_th, fitted_data[i,3]*x_th+fitted_data[i,4], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.plot(x_th, fitted_data[i,5]*x_th+fitted_data[i,6], c=colors[i % len(colors)], ls='-', lw=1, marker='None', ms=10)
# ax.errorbar(sampled_data[:,0]+1, sampled_data[:,3*i+1], yerr=[sampled_data[:,3*i+3],sampled_data[:,3*i+2]], c=colors[i % len(colors)], ls='None', lw=3, marker=symbols[i % len(symbols)], ms=10)
# Plots the real cv value.
ax.plot(np.arange(0,100), cv_real*np.ones(100), c='k', ls='--', marker='None', label=r'Real')
# Axes label.
ax.set_xlabel(r'$\mathrm{E}[\epsilon^2]$',    labelpad=0)
ax.set_ylabel(r'$(\mathrm{CV}[s])^2$', labelpad=0)
# Bounds.
ax.set_xbound(0, 7)
ax.set_ybound(noise_characterization_y_min, noise_characterization_y_max)
# Legend.
lines, labels = ax.get_legend_handles_labels()
ax.legend(lines, labels, loc='upper left', shadow=False, fancybox=True, prop={'size':14}, frameon=True, numpoints=1, bbox_to_anchor=(1.0, 1.0))
# # Identifies the figure.
# text(0.5, 1.01, title, fontsize=24, horizontalalignment='center', verticalalignment='bottom', transform=ax.transAxes)
# Save to file.
fig.savefig('networks/' + name + '/tiv/figs/' + name + '_noise_characterization.pdf')


# # =================================================================================================
# # Figure alpha vs noise.
# # =================================================================================================

# # Plot parameters.
# plt.rcParams['text.usetex'] = True
# plt.rcParams['font.size'] = 32
# plt.rcParams['font.family'] = 'serif'
# plt.rcParams['font.serif'] = 'Charter'
# plt.rcParams['xtick.major.width'] = 2
# plt.rcParams['xtick.major.size'] = 8
# plt.rcParams['ytick.major.width'] = 2
# plt.rcParams['ytick.major.size'] = 8
# # Custom plot parameters.
# # colors   = ['#80a339', '#af773e', '#ba2b83', '#3e76af', '#5c39a3', '#ee4939']
# colors   = ['#0000ff', '#00ff00', '#ff0000', '#40e0d0', '#008b00', '#ee4939']
# symbols  = ['o','s', '^', '*']
# # Creates the figure and axis objects.
# fig, ax = plt.subplots(1,1,figsize=(12,8))
# fig.subplots_adjust(bottom=0.15)
# fig.subplots_adjust(bottom=0.12, left=0.12, top=0.95, right=0.8)
# # Loads the inferred alphas.
# alpha_inf = np.loadtxt('networks/' + name + '/tiv/' + name + '_inferred_alpha.dat')
# # Plots the data and the linear fit.
# ax.errorbar(alpha_inf[:,0], alpha_inf[:,1], yerr=[alpha_inf[:,1]-alpha_inf[:,3],alpha_inf[:,2]-alpha_inf[:,1]], c=colors[0], ls='None', lw=3, marker=symbols[0], ms=10, mec='None')
# # Axes label.
# ax.set_xlabel(r'$\mathrm{E}[\epsilon^2]$',    labelpad=0)
# ax.set_ylabel(r'$\alpha_{\mathrm{inf}}$', labelpad=0)
# # Bounds.
# ax.set_xbound(0,7)
# ax.set_ybound(0,1)
# # Legend.
# lines, labels = ax.get_legend_handles_labels()
# ax.legend(lines, labels, loc='upper left', shadow=False, fancybox=True, prop={'size':14}, frameon=True, numpoints=1, bbox_to_anchor=(1.0, 1.0))
# # # Identifies the figure.
# # text(0.5, 1.01, title, fontsize=24, horizontalalignment='center', verticalalignment='bottom', transform=ax.transAxes)
# # Save to file.
# fig.savefig('networks/' + name + '/tiv/figs/' + name + '_inferred_alpha.pdf')


# =================================================================================================
# Generates networks for TIV calculation
# =================================================================================================

# Compile the program.
if(type_net == 'real_avgk'):
  os.system('g++ -O3 -std=c++11 src/compute_tiv_real.cpp -o compute_tiv_' + name + ' -lgsl -lgslcblas')
if(type_net == 'real'):
  os.system('g++ -O3 -std=c++11 src/compute_tiv_real.cpp -o compute_tiv_' + name + ' -lgsl -lgslcblas')
if(type_net == 'real_strength'):
  os.system('g++ -O3 -std=c++11 src/compute_tiv_real_fixed_sigma.cpp -o compute_tiv_' + name + ' -lgsl -lgslcblas')
if(type_net == 'real_kappa'):
  os.system('g++ -O3 -std=c++11 src/compute_tiv_real_kappa.cpp -o compute_tiv_' + name + ' -lgsl -lgslcblas')
if(type_net == 'synthetic_avgk'):
  os.system('g++ -O3 -std=c++11 src/compute_tiv_synthetic_avgk.cpp -o compute_tiv_' + name + ' -lgsl -lgslcblas')


alpha_inf = np.loadtxt('networks/' + name + '/tiv/' + name + '_inferred_alpha.dat')

for i in np.arange(len(alpha_inf[:,0])):
  # for j in np.arange(1):
  for j in np.arange(3):
    # if(not os.path.exists('networks/' + name + '/tiv/tiv_networks/' + name + '_tiv_alpha' + str(int(tmp_alpha)) + 'p' + str(tmp_alpha-int(tmp_alpha))[2:] + '_gnoise' + str(int(tmp_gnoise)) + 'p' + str(tmp_gnoise-int(tmp_gnoise))[2:] + '_triangles.dat')):
    if(type_net == 'synthetic_avgk'):
      execution_line  = './compute_tiv_' + name + ' ' + str(int(N)) + ' ' + str(alpha_inf[i,1+j]) + ' ' + str(avgk) + ' ' + str(gamma) + ' ' + str(eta) + ' ' + str(a) + ' ' + str(beta) + ' ' + str(alpha_inf[i,0]-1.0) + ' '
    if(type_net == 'real_avgk'):
      execution_line  = './compute_tiv_' + name + ' ' + str(int(N)) + ' ' + str(alpha_inf[i,1+j]) + ' ' + str(gamma) + ' ' + str(ka_zero) + ' ' + str(ka_max) + ' ' + str(eta) + ' ' + str(a) + ' ' + str(beta) + ' ' + str(alpha_inf[i,0]-1.0) + ' '
    if(type_net == 'real'):
      execution_line  = './compute_tiv_' + name + ' ' + str(int(N)) + ' ' + str(alpha_inf[i,1+j]) + ' ' + str(gamma) + ' ' + str(ka_zero) + ' ' + str(ka_max) + ' ' + str(eta) + ' ' + str(a) + ' ' + str(beta) + ' ' + str(alpha_inf[i,0]-1.0) + ' '
    if(type_net == 'real_strength'):
      execution_line  = './compute_tiv_' + name + ' ' + str(int(N)) + ' ' + str(alpha_inf[i,1+j]) + ' ' + str(gamma) + ' ' + str(ka_zero) + ' ' + str(ka_max) + ' ' + str(eta) + ' ' + str(a) + ' ' + str(beta) + ' ' + str(alpha_inf[i,0]-1.0) + ' '
    if(type_net == 'real_kappa'):
      execution_line  = './compute_tiv_' + name + ' ' + str(int(N)) + ' ' + str(alpha_inf[i,1+j]) + ' ' + str(gamma) + ' ' + str(ka_zero) + ' ' + str(ka_max) + ' ' + str(eta) + ' ' + str(a) + ' ' + str(beta) + ' ' + str(alpha_inf[i,0]-1.0) + ' '
    tmp_alpha  = np.round(alpha_inf[i,1+j],decimals=3)
    tmp_gnoise = np.round(alpha_inf[i,0],decimals=3)
    execution_line += name + ' _tiv_alpha' + str(int(tmp_alpha)) + 'p' + str(tmp_alpha-int(tmp_alpha))[2:] + '_gnoise' + str(int(tmp_gnoise)) + 'p' + str(tmp_gnoise-int(tmp_gnoise))[2:]
    execution_line += ' ' + str(int(randint(1,1000000)))
    print(execution_line)
    os.system(execution_line)

# Removes the executable.iJO1366_max_deg_90_num_reacs_tiv_alpha0p0_gnoise3p9_triangles.dat
os.system('rm -f compute_tiv_' + name)


# =================================================================================================
# Computes the TIV curves for the original network.
# =================================================================================================

I_1 = (np.pi/beta) / np.sin(np.pi/beta)
noise_term = np.log(1.0)
tiv         = np.zeros(len(alpha_tilde))

# Loads the data.
filename  = 'networks/' + name + '/original_graph/' + name
VerticesProperties = np.loadtxt(filename + '_vertices_properties.dat')
Triangles          = np.loadtxt(filename + '_triangles.dat')

# Estimates mean_kappa and mean_sigma from the degree and the strength avoiding the degree-zero vertices.
if(type_net == "synthetic_avgk"):
  mean_kappa = np.sum(VerticesProperties[:,4]*(VerticesProperties[:,4]>0)) / np.sum(VerticesProperties[:,4]>0)
  mean_sigma = np.sum(VerticesProperties[:,5]*(VerticesProperties[:,4]>0)) / np.sum(VerticesProperties[:,4]>0)
if(type_net == "real_avgk"):
  mean_kappa = np.sum(VerticesProperties[:,0]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)
  mean_sigma = np.sum(VerticesProperties[:,1]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)
if(type_net == "real_strength"):
  mean_kappa = np.sum(VerticesProperties[:,0]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)
  mean_sigma = np.sum(VerticesProperties[:,1]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)
if(type_net == "real"):
  mean_kappa = np.sum(VerticesProperties[:,0]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)
  mean_sigma = np.sum(VerticesProperties[:,1]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)
if(type_net == "real_kappa"):
  mean_kappa = np.sum(VerticesProperties[:,0]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)
  mean_sigma = np.sum(VerticesProperties[:,1]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)

# Computes the constant term in the inequality.
constant_term = np.zeros(len(alpha_tilde))
for i in np.arange(len(alpha_tilde)):
  I_3 = (np.pi/beta) / np.sin(np.pi*(1.0-alpha_tilde[i])/beta)
  constant_term[i] = alpha_tilde[i] * np.log( (2 * mean_kappa * N * I_1) / (np.pi * ka_zero**2) ) + np.log(I_1/I_3) + np.log(mean_kappa/mean_sigma)

# For all triangles.
nb_triangles = Triangles.shape[0]
for t in np.arange(nb_triangles):

  # Sets the identities.
  n = Triangles[t,0]

  # Sets the weights.
  w1 = Triangles[t,3]
  w2 = Triangles[t,4]
  w3 = Triangles[t,5]

  # Sets the ratios (sigma/kappa)**2
  if(type_net == "synthetic_avgk"):
    l = ( a * VerticesProperties[n,4]**(eta-1.) )**2
  if(type_net == "real_avgk"):
    l = ( a * VerticesProperties[n,0]**(eta-1.) )**2
  if(type_net == "real"):
    l = ( a * VerticesProperties[n,0]**(eta-1.) )**2
  if(type_net == "real_strength"):
    # l = ( a * VerticesProperties[n,0]**(eta-1.) )**2
    l = ( VerticesProperties[n,1] / VerticesProperties[n,0])**2
  if(type_net == "real_kappa"):
    l = ( a * VerticesProperties[n,0]**(eta-1.) )**2

  # Computes the ratio of weights.
  ratio = np.log( ( l * w3 ) / ( w1 * w2 ) )

  # For all values of alpha.
  for i in np.arange(len(alpha_tilde)):

    # Determines if the triangle inequality is respected.
    if( ratio + constant_term[i] < noise_term ):
      tiv[i] += 1

for n in np.arange(len(alpha_tilde)):
  if(tiv[n] > 0):
    tiv[n] /= nb_triangles
  else:
    tiv[n] = 1e-8


# Saves the tiv curve into a file.
file = open('networks/' + name + '/original_graph/' + name + '_tiv.dat', 'w')
for i in np.arange(len(tiv)):
  file.write(str(alpha_tilde[i]) + '  ' + str(tiv[i]) + '\n')
file.close()



# =================================================================================================
# Plots the TIV curve for the original network.
# =================================================================================================

# Modification of plot parameters
plt.rcParams['text.usetex'] = True
plt.rcParams['font.size'] = 32
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = 'Charter'
plt.rcParams['xtick.major.width'] = 2
plt.rcParams['xtick.major.size'] = 8
plt.rcParams['ytick.major.width'] = 2
plt.rcParams['ytick.major.size'] = 8
# Other parameters.
colors   = ['#80a339', '#af773e', '#ba2b83', '#3e76af', '#5c39a3', '#ee4939']
symbols  = ['o','s', '^', '*']
# Creates the figure and axis objects.
fig, ax = plt.subplots(1,1,figsize=(12,8))
fig.subplots_adjust(bottom=0.12, left=0.07, top=0.95, right=0.8)
ax.plot(alpha_tilde, tiv, ls='-', lw=3, c='k', marker='s', ms=10, mec='None',label=r'Real')
ax.set_xlabel(r'\tilde{\alpha}')
ax.set_yscale('log')
ax.set_ylim([8e-4,1])
# Legend.
lines, labels = ax.get_legend_handles_labels()
ax.legend(lines, labels, loc='upper left', shadow=False, fancybox=True, prop={'size':14}, frameon=True, numpoints=1, bbox_to_anchor=(1.0, 1.0))
# Saves the figure and closes it.
fig.savefig('networks/' + name + '/figs/' + name + '_tiv.pdf')
plt.close('all')


# =================================================================================================
# Computes the TIV curves.
# =================================================================================================

I_1 = (np.pi/beta) / np.sin(np.pi/beta)
noise_term = np.log(1.0)
tiv         = np.zeros((3*len(alpha_inf[:,0]),len(alpha_tilde)))

for i in np.arange(len(alpha_inf[:,0])):
  # for j in np.arange(1):
  for j in np.arange(3):

    tmp_alpha  = np.round(alpha_inf[i,1+j],decimals=3)
    tmp_gnoise = np.round(alpha_inf[i,0],decimals=3)
    filename  = 'networks/' + name + '/tiv/tiv_networks/' + name
    filename += '_tiv_alpha' + str(int(tmp_alpha)) + 'p' + str(tmp_alpha-int(tmp_alpha))[2:] + '_gnoise' + str(int(tmp_gnoise)) + 'p' + str(tmp_gnoise-int(tmp_gnoise))[2:]

    # Loads the data.
    VerticesProperties = np.loadtxt(filename + '_vertices_properties.dat')
    Triangles          = np.loadtxt(filename + '_triangles.dat')

    mean_kappa = sum(VerticesProperties[:,2]) / len(VerticesProperties[:,2])
    mean_sigma = sum(VerticesProperties[:,3]) / len(VerticesProperties[:,3])

    # Computes the constant term in the inequality.
    constant_term = np.zeros(len(alpha_tilde))
    for n in np.arange(len(alpha_tilde)):
      I_3 = (np.pi/beta) / np.sin(np.pi*(1.0-alpha_tilde[n])/beta)
      constant_term[n] = alpha_tilde[n] * np.log( (2 * mean_kappa * N * I_1) / (np.pi * ka_zero**2) ) + np.log(I_1/I_3) + np.log(mean_kappa/mean_sigma)

    # For all triangles.
    nb_triangles = Triangles.shape[0]
    for t in np.arange(nb_triangles):

      # Sets the identities.
      n = Triangles[t,0]

      # Sets the weights.
      w1 = Triangles[t,3]
      w2 = Triangles[t,4]
      w3 = Triangles[t,5]

      # Sets the ratio (sigma/kappa)**2
      # l = ( a * VerticesProperties[n,2]**(eta-1.) )**2
      l = ( VerticesProperties[n,3] / VerticesProperties[n,2] )**2

      # Computes the ratio of weights.
      ratio = np.log( ( l * w3 ) / ( w1 * w2 ) )

      # For all values of alpha.
      for k in np.arange(len(alpha_tilde)):

        # Determines if the triangle inequality is respected.
        if( ratio + constant_term[k] < noise_term ):
          tiv[i*3+j,k] += 1

    for n in np.arange(len(alpha_tilde)):
      if(tiv[i*3+j,n] > 0):
        tiv[i*3+j,n] /= nb_triangles
      else:
        tiv[i*3+j,n] = 1e-8


    # # Saves the tiv curves.
    # tmp_alpha  = np.round(alpha_inf[i,1+j],decimals=3)
    # tmp_gnoise = np.round(alpha_inf[i,0],decimals=3)
    # filename  = 'networks/' + name + '/tiv/tiv_curves/' + name
    # filename += '_tiv_alpha' + str(int(tmp_alpha)) + 'p' + str(tmp_alpha-int(tmp_alpha))[2:] + '_gnoise' + str(int(tmp_gnoise)) + 'p' + str(tmp_gnoise-int(tmp_gnoise))[2:]
    # filename += '_tiv_curve.dat'
    # file = open(filename, 'w')
    # for n in np.arange(len(alpha_tilde)):
    #   file.write(str(alpha_tilde[n]) + '  ' + str(tiv[i*3+j,n]) + '\n')
    # file.close()

filename = 'networks/' + name + '/tiv/' + name + '_tiv_curves.dat'
file = open(filename, 'w')
for i in np.arange(len(alpha_inf[:,0])):
  for j in np.arange(3):
    for n in np.arange(len(alpha_tilde)):
      file.write(str(tiv[i*3+j,n]) + '  ')
    file.write('\n')
file.close()


# =================================================================================================
# Plots the TIV curves.
# =================================================================================================

# Modification of plot parameters
plt.rcParams['text.usetex'] = True
plt.rcParams['font.size'] = 32
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = 'Charter'
plt.rcParams['xtick.major.width'] = 2
plt.rcParams['xtick.major.size'] = 8
plt.rcParams['ytick.major.width'] = 2
plt.rcParams['ytick.major.size'] = 8

colors   = ['#0000ff', '#00ff00', '#ff0000', '#40e0d0', '#008b00', '#ee4939']
symbols  = ['o','s', '^', '*']

# Loads the inferred alphas and tiv curves
alpha_inf = np.loadtxt('networks/' + name + '/tiv/' + name + '_inferred_alpha.dat')
real_tiv  = np.loadtxt('networks/' + name + '/original_graph/' + name + '_tiv.dat')
tiv       = np.loadtxt('networks/' + name + '/tiv/' + name + '_tiv_curves.dat')

# Creates the figure and axis objects.
fig, ax = plt.subplots(1,1,figsize=(12,8))
fig.subplots_adjust(bottom=0.12, left=0.07, top=0.95, right=0.75)
for n in np.arange(len(alpha_inf[:,0])):
  ax.errorbar(alpha_tilde, tiv[3*n,:], yerr=[tiv[3*n,:]-tiv[3*n+2,:],tiv[3*n+1,:]-tiv[3*n,:]], ls='-', lw=1, c='k', marker=symbols[n%len(symbols)], mfc=colors[n%len(colors)], ms=10,label=r'$\mathrm{E}[\epsilon^2]=$ ' + str(np.round(alpha_inf[n,0],decimals=2)) + ', ' + r'$\alpha=$ ' + str(np.round(alpha_inf[n,1],decimals=3)))
ax.plot(real_tiv[:,0], real_tiv[:,1], ls='-', lw=1, c='k', marker='<', ms=10, mfc='k',label=r'$\mathrm{Real}$')
ax.set_xlabel(r'\tilde{\alpha}')
ax.set_yscale('log')
ax.set_ylim([8e-4,1])
# Legend.
lines, labels = ax.get_legend_handles_labels()
ax.legend(lines, labels, loc='upper left', shadow=False, fancybox=True, prop={'size':6}, frameon=True, numpoints=1, bbox_to_anchor=(1.0, 1.0))
fig.savefig('networks/' + name + '/tiv/figs/' + name + '_tiv.pdf')


# =================================================================================================
# Quantifies the difference between the TIV curves using the chi-squared statistics.
# =================================================================================================

# Loads the inferred alphas and tiv curves
alpha_inf = np.loadtxt('networks/' + name + '/tiv/' + name + '_inferred_alpha.dat')
real_tiv  = np.loadtxt('networks/' + name + '/original_graph/' + name + '_tiv.dat')
tiv       = np.loadtxt('networks/' + name + '/tiv/' + name + '_tiv_curves.dat')

chi_squared = np.zeros(len(alpha_inf[:,0]))

for n in np.arange(len(alpha_inf[:,0])):
  chi_squared[n] = 0
  for i in np.arange(len(alpha_tilde)):
    if(tiv[n*3,i] > 1e-8):
      sigma = np.max(np.array([np.abs(tiv[n*3,i]-tiv[n*3+1,i]),np.abs(tiv[n*3,i]-tiv[n*3+2,i]),np.abs(tiv[n*3+1,i]-tiv[n*3+2,i])]))
      chi_squared[n] += (real_tiv[i,1]-tiv[n*3,i])**2 / sigma**2


# =================================================================================================
# Plots the chi-squared.
# =================================================================================================

# Modification of plot parameters
plt.rcParams['text.usetex'] = True
plt.rcParams['font.size'] = 32
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = 'Charter'
plt.rcParams['xtick.major.width'] = 2
plt.rcParams['xtick.major.size'] = 8
plt.rcParams['ytick.major.width'] = 2
plt.rcParams['ytick.major.size'] = 8

colors   = ['#80a339', '#af773e', '#ba2b83', '#3e76af', '#5c39a3', '#ee4939']
symbols  = ['o','s', '^', '*']

# Creates the figure and axis objects.
fig, ax = plt.subplots(2,1,figsize=(12,8), sharex=True)
fig.subplots_adjust(bottom=0.12, left=0.10, top=0.95, right=0.95)
ax[0].errorbar(alpha_inf[:,0], alpha_inf[:,1], yerr=[alpha_inf[:,1]-alpha_inf[:,3],alpha_inf[:,2]-alpha_inf[:,1]], c='k', ls='-', lw=1, marker='o', ms=10, mfc='k')
ax[0].set_ylabel(r'$\alpha_{\mathrm{inf}}$', labelpad=0)
ax[0].set_xbound(0.5,3.5)
# ax[0].set_ybound(np.floor(np.min(alpha_inf[:,3]*100.))/100.,np.ceil(np.max(alpha_inf[:,2]*100.))/100.)
ax[1].plot(alpha_inf[:,0], chi_squared, ls='-', lw=1, c='k', marker='o', ms=10, mec='None')
ax[1].set_xlabel(r'$\mathrm{E}[\epsilon^2]$',    labelpad=0)
ax[1].set_ylabel(r'$\chi^2$')
ax[1].set_yscale('log')
ax[1].set_xbound(np.min(alpha_inf[:,0])-0.5,np.max(alpha_inf[:,0])+0.5)
# Saves the figure.
fig.savefig('networks/' + name + '/tiv/figs/' + name + '_estimate_alpha.pdf')


# =================================================================================================
# Extracts the best tiv curve.
# =================================================================================================

idx = 3 * np.where(chi_squared == chi_squared.min())[0][0]
print(epsilons_sq[idx/3], alpha_inf[idx/3, 0], alpha_inf[idx/3, 1])
filename = 'networks/' + name + '/tiv/' + name + '_tiv_best_match.dat'
file = open(filename, 'w')
for i in np.arange(len(alpha_tilde)):
    file.write(str(alpha_tilde[i]) + ' ' + str(tiv[idx, i]))
    file.write('\n')
file.close()


# # =================================================================================================
# # Computes the TIV curves for the original network.
# # =================================================================================================

# ext = "-1"
# if(len(sys.argv) > 2):
#   ext = str(sys.argv[2])

# I_1 = (np.pi/beta) / np.sin(np.pi/beta)
# noise_term = np.log(1.0)
# tiv         = np.zeros(len(alpha_tilde))

# # Loads the data.
# filename  = 'networks/' + name + '/original_graph/' + name + "_" + ext
# VerticesProperties = np.loadtxt(filename + '_vertices_properties.dat')
# Triangles          = np.loadtxt(filename + '_triangles.dat')

# # Estimates mean_kappa and mean_sigma from the degree and the strength avoiding the degree-zero vertices.
# if(type_net == "synthetic_avgk"):
#   mean_kappa = np.sum(VerticesProperties[:,4]*(VerticesProperties[:,4]>0)) / np.sum(VerticesProperties[:,4]>0)
#   mean_sigma = np.sum(VerticesProperties[:,5]*(VerticesProperties[:,4]>0)) / np.sum(VerticesProperties[:,4]>0)
# if(type_net == "real_avgk"):
#   mean_kappa = np.sum(VerticesProperties[:,0]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)
#   mean_sigma = np.sum(VerticesProperties[:,1]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)
# if(type_net == "real_strength"):
#   mean_kappa = np.sum(VerticesProperties[:,0]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)
#   mean_sigma = np.sum(VerticesProperties[:,1]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)
# if(type_net == "real"):
#   mean_kappa = np.sum(VerticesProperties[:,0]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)
#   mean_sigma = np.sum(VerticesProperties[:,1]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)
# if(type_net == "real_kappa"):
#   mean_kappa = np.sum(VerticesProperties[:,0]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)
#   mean_sigma = np.sum(VerticesProperties[:,1]*(VerticesProperties[:,0]>0)) / np.sum(VerticesProperties[:,0]>0)

# # Computes the constant term in the inequality.
# constant_term = np.zeros(len(alpha_tilde))
# for i in np.arange(len(alpha_tilde)):
#   I_3 = (np.pi/beta) / np.sin(np.pi*(1.0-alpha_tilde[i])/beta)
#   constant_term[i] = alpha_tilde[i] * np.log( (2 * mean_kappa * N * I_1) / (np.pi * ka_zero**2) ) + np.log(I_1/I_3) + np.log(mean_kappa/mean_sigma)

# # For all triangles.
# nb_triangles = Triangles.shape[0]
# for t in np.arange(nb_triangles):

#   # Sets the identities.
#   n = Triangles[t,0]

#   # Sets the weights.
#   w1 = Triangles[t,3]
#   w2 = Triangles[t,4]
#   w3 = Triangles[t,5]

#   # Sets the ratios (sigma/kappa)**2
#   if(type_net == "synthetic_avgk"):
#     l = ( a * VerticesProperties[n,4]**(eta-1.) )**2
#   if(type_net == "real_avgk"):
#     l = ( a * VerticesProperties[n,0]**(eta-1.) )**2
#   if(type_net == "real"):
#     l = ( a * VerticesProperties[n,0]**(eta-1.) )**2
#   if(type_net == "real_strength"):
#     # l = ( a * VerticesProperties[n,0]**(eta-1.) )**2
#     l = ( VerticesProperties[n,1] / VerticesProperties[n,0])**2
#   if(type_net == "real_kappa"):
#     l = ( a * VerticesProperties[n,0]**(eta-1.) )**2

#   # Computes the ratio of weights.
#   ratio = np.log( ( l * w3 ) / ( w1 * w2 ) )

#   # For all values of alpha.
#   for i in np.arange(len(alpha_tilde)):

#     # Determines if the triangle inequality is respected.
#     if( ratio + constant_term[i] < noise_term ):
#       tiv[i] += 1

# for n in np.arange(len(alpha_tilde)):
#   if(tiv[n] > 0):
#     tiv[n] /= nb_triangles
#   else:
#     tiv[n] = 1e-8


# # Saves the tiv curve into a file.
# file = open('networks/' + name + '/original_graph/' + name + '_' + ext + '_tiv.dat', 'w')
# for i in np.arange(len(tiv)):
#   file.write(str(alpha_tilde[i]) + '  ' + str(tiv[i]) + '\n')
# file.close()

