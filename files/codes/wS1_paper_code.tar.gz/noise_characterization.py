#!/usr/bin/python
# -*- coding: utf8 -*- 
# ========================================================================
# packages
from numpy import arange
from random import randint
import os
import sys


id_net = "-1"
if(len(sys.argv) > 1):
    id_net = str(sys.argv[1])
id_code = "1"
if(len(sys.argv) > 2):
    id_code = str(sys.argv[2])


# Parameters for each network.
# if(id_net == "iJO1366_max_deg_90_num_reacs"):
#   type_net = "real_avgk"
#   gamma  = 2.52
#   avgk   = 7.25
#   beta   = 2.0
#   N      = 1100
#   eta    = 1.1
#   a      = 1.0
#   sample_alpha = [0.25, 0.40, 0.50, 0.55, 0.60]
#   # sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60]
#   sample_gnoise = [0.0001, 1.00, 2.00, 3.00, 4.00, 5.00]

# if(id_net == "wtw2013BB_real_degree"):
#   type_net = "real"
#   gamma  = 2.42
#   ka_zero = 2.5
#   ka_max  = 800.0
#   beta   = 2.5
#   N      = 189.0
#   eta    = 1.62
#   a      = 3738.0
#   sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
#   sample_gnoise = [0.0001, 1.00, 2.00, 3.00, 4.00, 5.00]

# if(id_net == "wanusa2013PassengersBB"):
#   type_net = "real_kappa"
#   gamma   = 1.6
#   ka_zero = 0.45
#   ka_max  = 500
#   beta   = 1.4
#   N      = 1175
#   eta    = 1.72
#   a      = 10000.0
#   sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
#   # sample_alpha = [0.40]#, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
#   sample_gnoise = [0.0001, 1.00, 2.00, 3.00, 4.00, 5.00]

if(id_net == "iJO1366_max_deg_90_num_reacs"):
    type_net = "real"
    gamma = 2.52
    ka_zero = 2.82561
    ka_max = 172.628
    beta = 2.2
    # beta = 1.84046
    N = 1100.0
    eta = 1.09
    a = 1.09
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100

if(id_net == "wtw2013BB_real_degree"):
    type_net = "real"
    gamma = 2.42
    ka_zero = 2.47768
    ka_max = 135.056
    beta = 2.8
    # beta   = 2.19572
    N = 189.0
    eta = 1.63
    a = 3772.98782
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100

if(id_net == "wanusa2013PassengersBB"):
    type_net = "real"
    gamma = 1.75833
    ka_zero = 0.92166
    ka_max = 167
    beta = 1.5
    # beta = 1.39853
    N = 884
    eta = 1.72
    a = 10000.0
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100

if(id_net == "EColi"):
    type_net = "real"
    gamma = 2.64496
    ka_zero = 2.93006
    ka_max = 154.988
    beta = 2.2
    # beta = 1.94227
    N = 1010.0
    eta = 1.09
    a = 1.09
    tmp_alpha = 0.452
    tmp_gnoise = 1.3
    nb_sim = 100
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100

if(id_net == "cargoships"):
    type_net = "real"
    gamma = 2.4
    ka_zero = 31.6745
    ka_max = 641.45
    beta = 2.03
    N = 951.0
    eta = 1.18
    a = 7.60252
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100

if(id_net == "cargoshipsBB"):
    type_net = "real"
    gamma = 2.03355
    ka_zero = 18.9064
    ka_max = 1306.18
    beta = 1.85
    N = 834.0
    eta = 1.05
    a = 82.96924
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65,
                    0.70, 0.71, 0.72, 0.73, 0.74, 0.75, 0.76, 0.77, 0.78, 0.79,
                    0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100

if(id_net == "Human08"):
    type_net = "real_strength"
    gamma = 4.35187
    ka_zero = 27.9574
    ka_max = 101.868
    beta = 2.4
    # beta = 2.10932
    N = 989.0
    eta = 1.39
    a = 0.00277
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.56, 0.57, 0.58, 0.59,
                    0.60, 0.61, 0.62, 0.63, 0.64, 0.65, 0.66, 0.67, 0.68, 0.69,
                    0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100

if(id_net == "Human12a"):
    type_net = "real"
    # type_net = "real_strength"
    gamma = 4.35187
    ka_zero = 27.9574
    ka_max = 101.868
    beta = 2.8
    # beta = 2.10932
    N = 501.0
    eta = 0.86
    a = 0.01456
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.56, 0.57, 0.58, 0.59,
                    0.60, 0.61, 0.62, 0.63, 0.64, 0.65, 0.66, 0.67, 0.68, 0.69,
                    0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 250

if(id_net == "Human12b"):
    type_net = "real"
    # type_net = "real_strength"
    gamma = 3000
    ka_zero = 6.0
    ka_max = 0.3
    beta = 2.8
    # beta = 2.10932
    N = 586.0
    eta = 1.09
    a = 0.06469
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.56, 0.57, 0.58, 0.59,
                    0.60, 0.61, 0.62, 0.63, 0.64, 0.65, 0.66, 0.67, 0.68, 0.69,
                    0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 250

if(id_net == "UScommoditiesBB"):
    type_net = "real"
    gamma = 2.45648
    ka_zero = 2.6272
    ka_max = 105.557
    beta = 1.30083
    N = 376.0
    eta = 1.22
    a = 3044.61822
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45,
                    0.50, 0.51, 0.52, 0.53, 0.54, 0.55, 0.56, 0.57, 0.58, 0.59,
                    0.60, 0.61, 0.62, 0.63, 0.64, 0.65, 0.66, 0.67, 0.68, 0.69,
                    0.70, 0.71, 0.72, 0.73, 0.74,
                    0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 500

if(id_net == "UScommuteBB"):
    type_net = "real"
    gamma = 3.31283
    ka_zero = 2.53842
    ka_max = 30.1702
    beta = 2.2
    # beta = 1.64327
    N = 3109.0
    eta = 2.02
    a = 719.10118
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 10

if(id_net == "TestGraph"):
    type_net = "real"
    gamma = 2.5
    ka_zero = 2.0
    ka_max = 500
    beta = 2.2
    # beta = 1.64327
    N = 2000.0
    eta = 1.6
    a = 200.0
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100

if(id_net == "TestGraph2"):
    type_net = "real"
    gamma = 2.5
    ka_zero = 2.0
    ka_max = 500
    beta = 2.2
    # beta = 1.64327
    N = 2000.0
    eta = 1.6
    a = 200.0
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100

if(id_net == "TestGraph3"):
    type_net = "real"
    gamma = 2.5
    ka_zero = 2.0
    ka_max = 500
    beta = 2.2
    # beta = 1.64327
    N = 2000.0
    eta = 1.6
    a = 200.0
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100

if(id_net == "TestGraph4"):
    type_net = "real"
    gamma = 2.5
    ka_zero = 2.0
    ka_max = 500
    beta = 2.2
    # beta = 1.64327
    N = 2000.0
    eta = 1.6
    a = 200.0
    sample_alpha = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,
                    0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]
    sample_gnoise = [0.0001, 1.00, 3.00, 5.00]
    nb_sim = 100

# Builds the name of the network.
if(type_net == "real_avgk"):
  name = id_net
if(type_net == "real_kappa"):
  name = id_net
if(type_net == "real"):
  name = id_net
if(type_net == "real_strength"):
  name = id_net

# Creates the folders, if necessary.
if(not os.path.exists('networks/')):
  os.system('mkdir ' + 'networks/')
if(not os.path.exists('networks/' + name)):
  os.system('mkdir ' + 'networks/' + name)
if(not os.path.exists('networks/' + name + '/tiv')):
  os.system('mkdir ' + 'networks/' + name + '/tiv')
if(not os.path.exists('networks/' + name + '/tiv/noise_characterization_rough_results')):
  os.system('mkdir ' + 'networks/' + name + '/tiv/noise_characterization_rough_results')

# Compile the program.
if(type_net == "real_kappa"):
  os.system('g++ -O3 -std=c++11 src/noise_characterization_real_kappa.cpp -o noise_characterization_' + id_net + '_' + id_code)
if(type_net == "real_avgk"):
  os.system('g++ -O3 -std=c++11 src/noise_characterization_real_avgk.cpp -o noise_characterization_' + id_net + '_' + id_code)
if(type_net == "real"):
  os.system('g++ -O3 -std=c++11 src/noise_characterization_real.cpp -o noise_characterization_' + id_net + '_' + id_code)
if(type_net == "real_strength"):
  os.system('g++ -O3 -std=c++11 src/noise_characterization_real_fixed_sigma.cpp -o noise_characterization_' + id_net + '_' + id_code)


# # Run the simulations.
# for i in arange(5):
#   for tmp_alpha in sample_alpha:
#     for tmp_gnoise in sample_gnoise:
#       execution_line = './noise_characterization_' + id_net + '_' + id_code + ' ' + name
#       execution_line += ' ' + str(int(N))
#       execution_line += ' ' + str(tmp_alpha)
#       execution_line += ' ' + str(avgk)
#       execution_line += ' ' + str(gamma)
#       execution_line += ' ' + str(eta)
#       execution_line += ' ' + str(a)
#       execution_line += ' ' + str(beta)
#       execution_line += ' ' + str(tmp_gnoise)
#       execution_line += ' ' + str(int(randint(1,1000000)))
#       execution_line += ' >> '
#       execution_line += 'networks/' + name + '/tiv/noise_characterization_rough_results/' + name + '_noise_characterization'
#       execution_line += '_alpha'  + str(int(tmp_alpha))  + 'p' + str(tmp_alpha-int(tmp_alpha))[2:]
#       execution_line += '_gnoise' + str(int(tmp_gnoise)) + 'p' + str(tmp_gnoise-int(tmp_gnoise))[2:]
#       execution_line += '_' + id_code + '.dat'
#       # print(execution_line)
#       os.system(execution_line)

# Run the simulations.
for i in arange(nb_sim):
  for tmp_alpha in sample_alpha:
    for tmp_gnoise in sample_gnoise:
      execution_line = './noise_characterization_' + id_net + '_' + id_code + ' ' + name
      execution_line += ' ' + str(int(N))
      execution_line += ' ' + str(tmp_alpha)
      execution_line += ' ' + str(gamma)
      execution_line += ' ' + str(ka_zero)
      execution_line += ' ' + str(ka_max)
      execution_line += ' ' + str(eta)
      execution_line += ' ' + str(a)
      execution_line += ' ' + str(beta)
      execution_line += ' ' + str(tmp_gnoise)
      execution_line += ' ' + str(int(randint(1, 1000000)))
      execution_line += ' >> '
      execution_line += 'networks/' + name + '/tiv/noise_characterization_rough_results/' + name + '_noise_characterization'
      execution_line += '_alpha'  + str(int(tmp_alpha))  + 'p' + str(tmp_alpha-int(tmp_alpha))[2:]
      execution_line += '_gnoise' + str(int(tmp_gnoise)) + 'p' + str(tmp_gnoise-int(tmp_gnoise))[2:]
      execution_line += '_' + id_code + '.dat'
      # print(execution_line)
      os.system(execution_line)

# # Removes the executable.
os.system('rm -f noise_characterization_' + id_net + '_' + id_code)
