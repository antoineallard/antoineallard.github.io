#!/usr/bin/python
# -*- coding: utf8 -*-
# ========================================================================
# packages
from numpy import arange
import os
import sys
import time

model_script_filename = "model_script.sh"


# id_net = "-1"
# if(len(sys.argv) > 1):
#     id_net = str(sys.argv[1])
#     name = id_net
first_task = "0"
if(len(sys.argv) > 1):
    first_task = str(sys.argv[1])
nb_tasks = "10"
if(len(sys.argv) > 2):
    nb_tasks = str(sys.argv[2])


# # Parameters for each network.
# if(id_net == "iJO1366_max_deg_90_num_reacs"):
#     type_net = "real_avgk"


# # Builds the name of the network.
# if(type_net == "real_avgk"):
#     name = id_net

for i in arange(int(nb_tasks)):

    # for name in ['TestGraph', 'TestGraph2', 'TestGraph3', 'TestGraph4']:
    # for name in ['wtw2013BB_real_degree', 'wanusa2013PassengersBB',
    #              'iJO1366_max_deg_90_num_reacs']:
    # for name in ['Human08', 'cargoshipsBB', 'UScommoditiesBB',
    #              'UScommuteBB', 'UScommuteBB', 'UScommuteBB',
    #              'UScommuteBB', 'UScommuteBB', 'UScommuteBB']:
    # for name in ['UScommuteBB']:
    for name in ['Human12a', 'Human12b']:

        id_net = name

        # Creates the folders, if necessary.
        if(not os.path.exists('networks/')):
            os.system('mkdir ' + 'networks/')
        if(not os.path.exists('networks/' + name)):
            os.system('mkdir ' + 'networks/' + name)
        if(not os.path.exists('networks/' + name + '/tiv')):
            os.system('mkdir ' + 'networks/' + name + '/tiv')
        if(not os.path.exists('networks/' + name +
                              '/tiv/noise_characterization_rough_results')):
            os.system('mkdir ' + 'networks/' + name +
                      '/tiv/noise_characterization_rough_results')

        # Copies the model_script.sh
        out_filename = "model_script_" + id_net + \
                       "_" + str(int(first_task) + i) + ".sh"
        os.system('cp ' + model_script_filename + ' ' + out_filename)

        # Writes the last lines of the script file.
        file = open(out_filename, 'a')
        file.write('echo "Running ' + id_net + ' ' +
                   str(int(first_task) + i) + '"\n')
        file.write('mkdir ' + '$TMPDIR/networks/' + name + '\n')
        file.write('mkdir ' + '$TMPDIR/networks/' + name + '/original_graph\n')
        file.write('cp ' + 'networks/' + name +
                   '/original_graph/* $TMPDIR/networks/' + name +
                   '/original_graph\n')
        file.write('# Change to the execution directory\n')
        file.write('cd $TMPDIR/\n')
        file.write('# And run the exe\n')
        file.write('source /usr/local/gcc5.2/env.sh\n')
        file.write('python noise_characterization.py ' + id_net + ' ' +
                   str(int(first_task) + i) + '\n')
        file.write('# Finally, we copy back all important output' +
                   ' to the working directory\n')
        source = 'networks/' + name + '/tiv/noise_characterization_rough_results/*'
        destin = 'networks/' + name + '/tiv/noise_characterization_rough_results'
        file.write('scp ' + source + ' nodo00:$SGE_O_WORKDIR/' + destin + '\n')
        file.write('echo "Completed ' + id_net + ' ' +
                   str(int(first_task) + i) + '"\n')
        file.close()

        print("qsub " + out_filename)
        os.system("qsub " + out_filename)
        os.system('rm ' + out_filename)
        time.sleep(0.5)
