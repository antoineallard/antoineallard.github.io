/*
 *
 *  This code extracts the degree, k-shell and onion layer of every vertices in a graph.
 *
 *  Author:  Antoine Allard
 *  WWW:     antoineallard.info
 *  Date:    March 2019
 *
 *
 *  References: Multi-scale structure and topological anomaly detection via a new network statistic: The onion decomposition
 *              L. Hébert-Dufresne, J. A. Grochow, and A. Allard
 *              Scientific Reports 6, 31708 (2016)
 *              http://doi.org/10.1038/srep31708
 *
 *              Percolation and the effective structure of complex networks
 *              A. Allard and L. Hébert-Dufresne
 *              Physical Review X 9, 011023 (2019)
 *              http://doi.org/10.1103/PhysRevX.9.011023
 *
 *
 *  Compilation using gcc: g++ -O3 extract_onion_decomposition.cpp -o extract_onion_decomposition
 *
 *  Usage example: ./extract_onion_decomposition example04.edge
 *
 *  Input: The graph is specified with a file containing its edgelist (one edge per line). The
 *         edgelist file consists in a simple text file with the following convention:
 *
 *         # lines beginning with "#" are ignored (comments).
 *         # vertices' name must be separated by at least one white space.
 *         # there may be white space at the beginning of a line.
 *         [name of vertex1]  [name of vertex2]  [remaining information will be ignored]
 *         [name of vertex2]  [name of vertex3]  [remaining information will be ignored]
 *         [name of vertex4]  [name of vertex5]  [remaining information will be ignored]
 *         # comments can be inserted between edges
 *         [name of vertex5]  [name of vertex6]  [remaining information will be ignored]
 *         [name of vertex7]  [name of vertex6]  [remaining information will be ignored]
 *         ...
 *
 *         The vertices's name will be imported as std::string and can therefore be
 *         virtually anything as long as they do not include white spaces (i.e., there is
 *         not need for the vertices to be identified by contiguous integers).
 *
 *         IMPORTANT: this class only considers simple undirected graphs without self-loops. Any
 *                    multiple edges (e.g., reciprocal edges in an originally directed graph) or
 *                    self-loops will be ignored.
 *
 *  Output: See lines 97-107.
 *
 *  Copyright (C) 2019 Antoine Allard
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 */


// Standard Template Library
#include <string>
// AEGIS package
#include "undirected_graph_t.hpp"


int main(int argc, char** argv)
{
  // Filename of the edgelist.
  std::string edgelist_filename = argv[1];

  // Name of the output file.
  std::string output_filename;
  size_t lastdot = edgelist_filename.find_last_of(".");
  if(lastdot == std::string::npos)
  {
    output_filename = edgelist_filename;
  }
  output_filename = edgelist_filename.substr(0, lastdot);
  output_filename += "_od.dat";

  // Reads the graph from file.
  undirected_graph_t the_graph(edgelist_filename);

  // Extracts the degree of vertices. Provides the property keyword "degrees".
  the_graph.degrees();
  // Extracts the onion decomposition (keywords "kcore" and "od_layer").
  the_graph.onion_decomposition();

  // The properties are specified by a vector containing their associated keywords.
  std::string p[] = {"degrees", "kcore", "od_layer"};
  std::vector<std::string> props(p, p+3);

  // A first column is added to identify each vertex (one vertex by row). By default, the names
  //   used to identify the vertices in the original edgelist are used (option vID_name).
  //   Otherwise, the internal ID (contiguous integer from 0 to nb_vertices-1) can be used by
  //   passing the option vID_num to the function, or the first column can be omitted by passing
  //   the option vID_none.
  // Each property appears in its own column, which have an identifying header (default). The
  //   header may be omitted by passing the parameter header_false (as opposed to header_true).
  //   printed if no header vector is provided.
  // The width of each column can also be specified (default is 15).
  // The header, the width, and the vertex ID parameters can be individually omitted or specified in
  //   any order.
  the_graph.save_vertices_properties(output_filename, props, undirected_graph_t::vID_name, undirected_graph_t::header_true, 15);

  // Exits the program successfully.
  return 0;
}
